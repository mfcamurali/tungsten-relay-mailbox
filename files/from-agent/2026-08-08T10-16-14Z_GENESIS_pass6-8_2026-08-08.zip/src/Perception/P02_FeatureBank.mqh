//+----------------------------------------------------------------------+
//| P02 · FeatureBank                                                    |
//| GENESIS · PERCEPTION system · organ 02                               |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                   |
//+----------------------------------------------------------------------+
//| Purpose (GENESIS_MASTER_SPEC.md O2):                                 |
//|   Provide only features with proven out-of-sample separation. Every  |
//|   feature exposes live OOS AUC; AUC<0.52 -> auto-retired. A degrading|
//|   feature is retired mid-run, not trusted; no feature is assumed     |
//|   discriminative.                                                    |
//| Invariant enforced: INV-01 (no hardcoded win rate anywhere).         |
//|                                                                      |
//| Intent, extracted from the precedent (read directly, not copied):    |
//| g_RegimeIC[9][6] + MeasureRegimeIC() (~line 4466) already measure a  |
//| per-regime, per-component information coefficient for the 6 CEUS     |
//| components (MTF/momentum/volume/volatility/session/pattern) --       |
//| exactly the "does this feature actually separate outcomes" question  |
//| O2 owns, just via IC (a correlation-style statistic) rather than AUC.|
//| The precedent measures this, tracks it per regime, even pools it     |
//| across mirror regimes when divergence looks like noise -- but never  |
//| RETIRES a component: every one of the 6 always feeds the live score, |
//| regardless of how weak its own measured IC is. Ironically, the       |
//| precedent's own WARRANT#61 (CalculateRecentWinRate hardcoded 65.0    |
//| fallback feeding a live EV gate, ignoring the real calibrated        |
//| winProbability sitting right there) is INV-01's own named origin --  |
//| a literal, fabricated win-rate number silently outranking a real,    |
//| computed one.                                                        |
//|                                                                      |
//| What changed, and why (Law 1: intent kept, structure discarded):     |
//|   O2 generalises "measure a feature's discriminative power" (kept)   |
//|   into a real rank-based AUC (Mann-Whitney U / rank-sum, a standard, |
//|   literature statistic, not invented here) computed ONLY over        |
//|   caller-supplied OOS samples -- there is no in-sample scoring path  |
//|   anywhere in this organ's API, so "OOS only" is structural, not a   |
//|   convention a caller could accidentally violate. AND it adds what   |
//|   the precedent never had: an explicit retirement gate               |
//|   (P02_IsUsable), so a feature whose measured separation has decayed |
//|   below a real threshold stops feeding Cognition instead of always   |
//|   contributing regardless of its own evidence.                       |
//+----------------------------------------------------------------------+
#property strict
#include "..\GENESIS_Constants.mqh"

#define P02_RETIRE_AUC_THRESHOLD 0.52   // P02.K0001 -- named per GENESIS_MASTER_SPEC.md's own literal figure; barely-better-than-coin-flip (0.50) is not good enough to trust
#define P02_MIN_N_FOR_AUC   GENESIS_DIAGNOSTIC_POWER_FLOOR   // P02.K0002 -- power floor; matches this project's established diagnostic-floor convention (R01/precedent's LE_DIAG_MIN_N) -- INV-07: aliases the one shared concept, not a second literal 30

//--- P02.S#### one out-of-sample observation: a feature reading paired
//--- with its eventual binary outcome (e.g. "did this signal's trade win").
//--- There is deliberately no "in-sample" variant of this type anywhere
//--- in the organ -- OOS-only is enforced by the API surface, not by a
//--- caller's discipline.
struct P02_OOSSample {
    double value;
    bool   outcomePositive;
};

//--- P02.V#### the organ's per-feature verdict
struct P02_FeatureStatus {
    double auc;           // EMPTY_VALUE if not yet computed (n<P02_MIN_N_FOR_AUC)
    int    n;
    bool   aucComputed;
    bool   retired;        // true iff this feature must not feed Cognition right now
};

//+---------------------------------------------------------------------+
//| P02.F0001 -- rank-based (Mann-Whitney U) AUC over OOS samples only. |
//| AUC = (sumRanksOfPositives - nPos*(nPos+1)/2) / (nPos*nNeg), the    |
//| standard equivalence between the rank-sum statistic and the         |
//| probability a random positive outranks a random negative. Ties are  |
//| given the average of the ranks they span (the standard correction --|
//| an un-corrected tie-break would bias AUC toward whichever class     |
//| happens to sort first among equal values).                          |
//| Returns EMPTY_VALUE if either class is empty (AUC is undefined with |
//| no negative or no positive class -- never fabricated as 0.5 or 1.0) |
//| or n<P02_MIN_N_FOR_AUC (insufficient power -- same "not computed is |
//| never representable as computed" discipline as R01/R03).            |
//+---------------------------------------------------------------------+
double P02_ComputeAUC(const P02_OOSSample &samples[]) {
    int n = ArraySize(samples);
    if(n < P02_MIN_N_FOR_AUC) return EMPTY_VALUE;

    // Selection-sort an index array by value ascending -- MQL4's ArraySort
    // only sorts flat numeric arrays, not struct arrays, so ranks are
    // built explicitly here. O(n^2) is deliberate and acceptable: this is
    // a periodic rolling-window evaluation, not a per-tick hot path.
    int idx[]; ArrayResize(idx, n);
    for(int i = 0; i < n; i++) idx[i] = i;
    for(int i = 0; i < n - 1; i++) {
        int minIdx = i;
        for(int j = i + 1; j < n; j++) if(samples[idx[j]].value < samples[idx[minIdx]].value) minIdx = j;
        if(minIdx != i) { int t = idx[i]; idx[i] = idx[minIdx]; idx[minIdx] = t; }
    }

    // Assign ranks (1-based), averaging across tied runs of equal value.
    double rank[]; ArrayResize(rank, n);
    int i = 0;
    while(i < n) {
        int j = i;
        while(j + 1 < n && samples[idx[j + 1]].value == samples[idx[i]].value) j++;
        double avgRank = (i + 1 + j + 1) / 2.0;   // ranks i+1..j+1 (1-based), averaged
        for(int k = i; k <= j; k++) rank[k] = avgRank;
        i = j + 1;
    }

    int nPos = 0, nNeg = 0;
    double sumRanksPos = 0.0;
    for(int r = 0; r < n; r++) {
        if(samples[idx[r]].outcomePositive) { nPos++; sumRanksPos += rank[r]; }
        else                                 { nNeg++; }
    }
    if(nPos == 0 || nNeg == 0) return EMPTY_VALUE;   // undefined -- one class entirely absent, never fabricated

    return (sumRanksPos - nPos * (nPos + 1) / 2.0) / (nPos * nNeg);
}

//+----------------------------------------------------------------------+
//| P02.F0002 -- the organ's one entry point. Evaluates a feature's      |
//| current OOS window and returns whether it should still be trusted.   |
//| retired=true whenever aucComputed AND auc<threshold; an UNCOMPUTED   |
//| feature (insufficient OOS sample) is treated as NOT retired=false    |
//| but also NOT usable (see P02_IsUsable) -- fails closed either way, so|
//| a feature is never assumed discriminative before it has evidence.    |
//+----------------------------------------------------------------------+
P02_FeatureStatus P02_Evaluate(const P02_OOSSample &samples[]) {
    P02_FeatureStatus st;
    st.n = ArraySize(samples);
    st.auc = P02_ComputeAUC(samples);
    st.aucComputed = (st.auc != EMPTY_VALUE);
    st.retired = st.aucComputed && (st.auc < P02_RETIRE_AUC_THRESHOLD);
    return st;
}

//+----------------------------------------------------------------------+
//| P02.F0003 -- the ONE sanctioned gate a consumer (Cognition) checks   |
//| before using a feature's current reading. Usable requires a real,    |
//| computed AUC that clears the threshold -- an unevaluated feature is  |
//| exactly as unusable as a retired one, closing the gap the precedent's|
//| own components never had (every one of the 6 always fed the score,   |
//| regardless of measured IC).                                          |
//+----------------------------------------------------------------------+
bool P02_IsUsable(const P02_FeatureStatus &st) {
    return st.aucComputed && !st.retired;
}

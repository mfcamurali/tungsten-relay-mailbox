//+----------------------------------------------------------------------+
//| P01 · RegimeState                                                    |
//| GENESIS · PERCEPTION system · organ 01                               |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                   |
//+----------------------------------------------------------------------+
//| Purpose (GENESIS_MASTER_SPEC.md O1):                                 |
//|   Own the 9-regime taxonomy; emit soft-membership + confidence.      |
//|   Returns p[9] summing to 1 with calibrated confidence, deterministic|
//|   for a given bar. Ambiguous regime -> max-entropy vector, never a   |
//|   guess. Stale data -> REFUSE.                                       |
//| Invariant enforced: INV-20 (one regime classifier, one taxonomy).    |
//|                                                                      |
//| Intent, extracted from the precedent (read directly, not copied):    |
//| TUNGSTEN_10.28_A7.5_QUANT_SLS(114).mq4, "Layer 12: Bayesian Regime   |
//| Belief" (~line 33670-33742): a real, working 9-regime soft-membership|
//| distribution (regimeBelief[9], beliefEntropy, beliefConviction,      |
//| dominantBeliefRegime) computed via log-likelihood-style evidence     |
//| updates against a persistent prior. A dated comment there (marked    |
//| "9.39") records the precedent's own real historical bug and fix: this|
//| belief used to reset to a uniform prior on EVERY call and update from|
//| only the current tick's instantaneous evidence -- not a Bayesian     |
//| update at all, since it never persisted the previous posterior, so a |
//| single noisy bar could snap the belief state. It was fixed in the    |
//| precedent by carrying the prior forward via a static, mutable global |
//| (g_PriorBelief[9]) with a same-bar re-entry guard (_newBeliefBar).   |
//|                                                                      |
//| What changed, and why (Law 1: intent kept, structure discarded):     |
//|   The precedent's fix works, but its mechanism (hidden static state  |
//|   + a same-bar guard baked into the classifier itself) is exactly    |
//|   what makes "deterministic for a given bar" hard to prove or test --|
//|   the function's output depends on how many times it happened to be  |
//|   called before, not just on its declared inputs. P01_UpdateBelief   |
//|   below is a PURE function: given an explicit prior belief and this  |
//|   bar's likelihood ratios, it always returns the identical posterior.|
//|   State persistence (carrying today's posterior forward as tomorrow's|
//|   prior) moves OUT of this organ and into whichever caller owns      |
//|   cross-bar state (O6 EvidenceLedger's territory, INV-11) -- P01     |
//|   itself never mutates a static, so "deterministic for a given bar"  |
//|   holds by construction, not by a same-bar re-entry guard a caller   |
//|   could accidentally bypass.                                         |
//|                                                                      |
//|   The regime-specific evidence heuristics themselves (which raw      |
//|   ADX/Hurst/RSI/structure reads translate into each of the 9 regimes'|
//|   likelihood ratios) are real domain intent worth preserving, but    |
//|   they are a FEATURE-COMPUTATION concern (O2 FeatureBank's contract: |
//|   "provide only features with proven OOS separation"), not this      |
//|   organ's. P01 takes likelihood ratios as an input and owns the      |
//|   taxonomy MECHANICS (update, entropy, confidence, dominant regime,  |
//|   staleness) -- keeping O1 the single place per INV-20 that a soft-  |
//|   membership vector is ever produced, while the evidence-to-         |
//|   likelihood mapping stays swappable/testable independently in O2.   |
//+----------------------------------------------------------------------+
#property strict

#define P01_REGIME_COUNT 9   // P01.K0001 -- the one taxonomy width; every [9]-shaped array in GENESIS traces to this

//--- P01.S#### state -- a soft-membership distribution over the 9 regimes
struct P01_BeliefVector {
    double p[P01_REGIME_COUNT];
};

//--- P01.V#### the organ's single decisive output
struct P01_Verdict {
    P01_BeliefVector belief;
    double           entropy;      // Shannon entropy, bits (0=certain, log2(9)=~3.17=max uncertainty)
    double           confidence;   // 1 - entropy/maxEntropy: 0=lost, 1=certain
    int              dominant;     // argmax(belief.p)
    double           dominantProb; // belief.p[dominant]
    bool             refused;      // true iff this verdict must not be trusted/acted on (stale input)
};

//+---------------------------------------------------------------------+
//| P01.F0001 -- a maximally uncertain (uniform) belief vector. This is |
//| both the correct output for a genuinely ambiguous regime read (never|
//| a guess) and the safe default for a refused/stale verdict.          |
//+---------------------------------------------------------------------+
P01_BeliefVector P01_UniformBelief() {
    P01_BeliefVector b;
    ArrayInitialize(b.p, 0.0);
    for(int i = 0; i < P01_REGIME_COUNT; i++) b.p[i] = 1.0 / P01_REGIME_COUNT;
    return b;
}

//+---------------------------------------------------------------------+
//| P01.F0002 -- pure Bayesian-style update. blend the prior toward     |
//| uniform by (1-decay) (a forgetting factor so genuine regime change  |
//| still gets through -- full memory would make the belief un-adaptive,|
//| per the precedent's own "9.39" comment), multiply by this bar's     |
//| per-regime likelihood ratios, then normalise to sum=1.              |
//| PURE: no static state, no hidden memory -- same inputs always       |
//| produce the same output ("deterministic for a given bar").          |
//+---------------------------------------------------------------------+
P01_BeliefVector P01_UpdateBelief(const P01_BeliefVector &prior, const double &likelihoodRatios[], double decay) {
    P01_BeliefVector b;
    ArrayInitialize(b.p, 0.0);
    double decayClamped = MathMax(0.0, MathMin(1.0, decay));
    double sum = 0.0;
    for(int i = 0; i < P01_REGIME_COUNT; i++) {
        double blended = decayClamped * prior.p[i] + (1.0 - decayClamped) * (1.0 / P01_REGIME_COUNT);
        double lr = (i < ArraySize(likelihoodRatios)) ? MathMax(0.0, likelihoodRatios[i]) : 1.0;
        b.p[i] = blended * lr;
        sum += b.p[i];
    }
    if(sum > 1e-12) { for(int i = 0; i < P01_REGIME_COUNT; i++) b.p[i] /= sum; }
    else            { b = P01_UniformBelief(); }   // every likelihood collapsed to zero -- honestly uncertain, not a divide-by-zero artifact
    return b;
}

//+----------------------------------------------------------+
//| P01.F0003 -- Shannon entropy of a belief vector, in bits.|
//+----------------------------------------------------------+
double P01_Entropy(const P01_BeliefVector &b) {
    double h = 0.0;
    for(int i = 0; i < P01_REGIME_COUNT; i++)
        if(b.p[i] > 1e-4) h -= b.p[i] * MathLog(b.p[i]) / MathLog(2.0);
    return h;
}

//+------------------------------------------------------------------+
//| P01.F0004 -- confidence derived from entropy: 1.0 at zero entropy|
//| (certain), 0.0 at max entropy (log2(9), fully uniform/uncertain).|
//+------------------------------------------------------------------+
double P01_Confidence(const P01_BeliefVector &b) {
    double maxH = MathLog((double)P01_REGIME_COUNT) / MathLog(2.0);
    if(maxH <= 1e-12) return 0.0;
    return MathMax(0.0, 1.0 - P01_Entropy(b) / maxH);
}

//+-----------------------------------------+
//| P01.F0005 -- argmax and its probability.|
//+-----------------------------------------+
void P01_Dominant(const P01_BeliefVector &b, int &outRegime, double &outProb) {
    outRegime = 0; outProb = b.p[0];
    for(int i = 1; i < P01_REGIME_COUNT; i++)
        if(b.p[i] > outProb) { outProb = b.p[i]; outRegime = i; }
}

//+----------------------------------------------------------------------+
//| P01.F0006 -- the organ's one entry point. freshBar must be true only |
//| when the caller has genuinely new evidence for this bar (owned by the|
//| caller's own state machine, per this organ's "pure function" design  |
//| above) -- if false, the verdict is REFUSED: belief is uniform,       |
//| refused=true, and the caller must not act on it. This is the         |
//| structural form of "stale data -> REFUSE": refusal is a first-class, |
//| checkable field, never silently indistinguishable from a genuinely   |
//| low-confidence (ambiguous) read.                                     |
//+----------------------------------------------------------------------+
P01_Verdict P01_Classify(const P01_BeliefVector &prior, const double &likelihoodRatios[], double decay, bool freshBar) {
    P01_Verdict v;
    if(!freshBar) {
        v.belief   = P01_UniformBelief();
        v.entropy  = P01_Entropy(v.belief);
        v.confidence = P01_Confidence(v.belief);
        P01_Dominant(v.belief, v.dominant, v.dominantProb);
        v.refused = true;
        return v;
    }
    v.belief   = P01_UpdateBelief(prior, likelihoodRatios, decay);
    v.entropy  = P01_Entropy(v.belief);
    v.confidence = P01_Confidence(v.belief);
    P01_Dominant(v.belief, v.dominant, v.dominantProb);
    v.refused = false;
    return v;
}

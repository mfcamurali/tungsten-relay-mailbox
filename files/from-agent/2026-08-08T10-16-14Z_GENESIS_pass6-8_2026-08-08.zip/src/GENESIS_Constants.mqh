//+-----------------------------------------------------------------------+
//| GENESIS_Constants -- the INV-07 shared-concept registry               |
//| GENESIS · cross-cutting, depended on by all five systems, depends on  |
//| nothing -- a leaf include, safe from every organ regardless of build  |
//| order (Substrate/Perception/Cognition/Action/Conscience can all       |
//| include this without creating a cross-system dependency).             |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.2.0-dev                    |
//+-----------------------------------------------------------------------+
//| Purpose: INV-07 ("no duplicate threshold floors") requires exactly    |
//| one named constant per CONCEPT, not merely one name per organ. Pass_1 |
//| and pass_2 built each organ against its own contract independently    |
//| and, correctly per-organ, matched this project's own established real |
//| floors (LE_DIAG_MIN_N=30, Prohibition #5's n>=500) -- but did so by   |
//| each organ writing its OWN literal #define, exactly the shape of the  |
//| precedent's real WARRANT#119 defect (two independently-edited floors, |
//| 50.0 and 18.0, for one concept, that could silently drift apart).     |
//| A smelt-pass audit of every #define in src/ found two real instances  |
//| of this today, honestly reported as thin rather than left alone:      |
//|                                                                       |
//|  1. DIAGNOSTIC POWER FLOOR (n>=30, "enough to read, not yet enough to |
//|     trust for sizing"): independently redefined as R01_MIN_N_PER_-    |
//|     SUBWINDOW, G01_MIN_OOS_TRADES, and P02_MIN_N_FOR_AUC -- three     |
//|     literal 30s across three organs, each correct today, each free to |
//|     drift tomorrow.                                                   |
//|  2. TRADING WEIGHT FLOOR (n>=500, "enough to affect a live decision"):|
//|     independently redefined as A03_FULL_CONFIDENCE_N and R04_MIN_-    |
//|     TRAINING_SAMPLES_FOR_TRUST -- two literal 500s across two organs. |
//|                                                                       |
//| Fix (Law 1 applied to GENESIS's own code, not just the precedent's):  |
//| both concepts now have exactly one definition, here. Every consuming  |
//| organ's own K-numbered constant becomes a literal alias of the shared |
//| one (e.g. `#define G01_MIN_OOS_TRADES GENESIS_DIAGNOSTIC_POWER_FLOOR`)|
//| -- the organ-local name stays, for local readability, but there is    |
//| only one VALUE anywhere in the codebase for each concept; changing it |
//| here changes it everywhere, by construction, not by five people       |
//| remembering to stay in sync.                                          |
//+-----------------------------------------------------------------------+
#ifndef GENESIS_CONSTANTS_MQH
#define GENESIS_CONSTANTS_MQH
#property strict

//--- GENESIS.K0001 -- DIAGNOSTIC POWER FLOOR. Below this sample size, a
//--- read is not evidence either way -- it is UNKNOWN, not merely "weak".
//--- Origin: precedent's LE_DIAG_MIN_N. Consumed today by R01
//--- (per-subwindow stationarity read), G01 (OOS trade count before
//--- arming is even evaluated), P02 (AUC's own minimum n).
#define GENESIS_DIAGNOSTIC_POWER_FLOOR 30

//--- GENESIS.K0002 -- TRADING WEIGHT FLOOR. Below this sample size, a
//--- read may exist and even be correct, but must not be trusted to
//--- influence a LIVE decision (position size, deployment, or a neural
//--- prediction) -- a strictly higher bar than the diagnostic floor above.
//--- Origin: precedent's Prohibition #5. Consumed today by A03 (full
//--- graduated-deployment confidence point) and R04 (neural net
//--- trustworthy-for-live gate).
#define GENESIS_TRADING_WEIGHT_FLOOR 500.0

//--- GENESIS.K0003 -- ~95% two-sided normal critical value. Standard
//--- literature constant, not invented anywhere in GENESIS. Added pass_3,
//--- 2nd smelt pass: GENESIS_Types.mqh's own GENESIS_RATE_CI_Z was written
//--- as an independent literal 1.96 alongside C01_EdgeAdjudicator.mqh's
//--- pre-existing C01_CI_Z (also 1.96, also "the standard 95% z-critical
//--- value") -- the exact INV-07 duplicate-concept pattern this project
//--- keeps re-finding, this time self-inflicted in the same pass that was
//--- auditing for it. Both now alias this one definition.
#define GENESIS_CI_Z_95 1.96

#endif // GENESIS_CONSTANTS_MQH

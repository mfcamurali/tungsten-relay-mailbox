//+-----------------------------------------------------------------------+
//| C02 · OverfitImmune                                                   |
//| GENESIS · COGNITION system · organ 02                                 |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                    |
//+-----------------------------------------------------------------------+
//| Purpose (GENESIS_MASTER_SPEC.md O5):                                  |
//|   One unified trust score from WF-gap, resample, CSCV. trust in [0,1];|
//|   trust<tau -> reject to equal weights. Any single guard failing      |
//|   lowers trust; no candidate bypasses all three.                      |
//| Invariant enforced: INV-14 (walk-forward, never one split).           |
//|                                                                       |
//| Intent, extracted from the precedent (read directly, not copied):     |
//| three real, separately-shipped guards, each added because the ones    |
//| before it weren't structurally sufficient on their own:               |
//|  - WF-gap: WARRANT#50's fit-check (train-vs-holdout gap; this         |
//|    project's live runs have shown gaps from -14pp to -37pp).          |
//|  - Resample-check: WARRANT#92's strided re-test of the same           |
//|    candidate on a different sample stride.                            |
//|  - PBO-CSCV: WARRANT#79's real Bailey-Lopez de Prado combinatorial    |
//|    symmetric cross-validation, C(8,4)=70 balanced splits.             |
//| In the precedent these three live as three SEPARATE checks, bolted on |
//| in sequence over about a week of real live-run evidence, each one     |
//| independently gating (or not gating) the same underlying weight       |
//| search -- there was never one place a candidate's overall             |
//| trustworthiness could be read as a single number.                     |
//|                                                                       |
//| What changed, and why (Law 1: intent kept, structure discarded):      |
//|   trust = MIN(gapTrust, resampleTrust, pboTrust), not an average.     |
//|   A minimum is the only composition under which "any single guard     |
//|   failing lowers trust" and "no candidate bypasses all three" both    |
//|   hold structurally -- an average lets two healthy guards dilute one  |
//|   failing one; a minimum cannot be diluted by anything.               |
//+-----------------------------------------------------------------------+
#property strict

#define C02_MAX_ACCEPTABLE_GAP_PP  8.0   // C02.K0001 -- walk-forward train-vs-holdout gap ceiling, percentage points
#define C02_TRUST_THRESHOLD        0.5   // C02.K0002 -- tau; also the natural PBO>0.5 boundary once composed as trustFromPBO=1-pbo

//--- C02.V#### the organ's single decisive output, with sub-scores
//--- exposed for audit -- "no candidate bypasses all three" is only
//--- checkable if a caller/log can see which guard actually failed.
struct C02_TrustResult {
    double trust;
    bool   rejected;
    double trustFromGap;
    double trustFromResample;
    double trustFromPBO;
    string reason;   // non-empty iff rejected
};

//+----------------------------------------------------------------------+
//| C02.F0001 -- walk-forward gap guard. A hard gate at the named ceiling|
//| (8pp, matching this organ's own acceptance contract literally) rather|
//| than a smoothed curve -- the contract's own test treats "gap>8pp" as |
//| a discrete failure condition, so a hard gate is the honest           |
//| implementation of what was actually specified, not an oversimplified |
//| one.                                                                 |
//+----------------------------------------------------------------------+
double C02_GapTrust(double gapPP) {
    return (MathAbs(gapPP) <= C02_MAX_ACCEPTABLE_GAP_PP) ? 1.0 : 0.0;
}

//+----------------------------------------------------------------------+
//| C02.F0002 -- resample-check guard. Divergence is a caller-supplied   |
//| boolean (the strided re-test either agrees with the main candidate or|
//| it doesn't) -- this organ does not re-derive the resample itself,    |
//| same "own the composition, not the underlying measurement" boundary  |
//| C01 keeps with P02/P03.                                              |
//+----------------------------------------------------------------------+
double C02_ResampleTrust(bool resampleDivergent) {
    return resampleDivergent ? 0.0 : 1.0;
}

//+--------------------------------------------------------------------+
//| C02.F0003 -- PBO guard. Continuous, not a hard gate: trustFromPBO =|
//| 1-pbo is a direct, standard mapping of "probability of backtest    |
//| overfitting" onto "how much to trust this candidate" -- and it     |
//| reproduces the contract's own "PBO>0.5 -> trust<tau" test exactly, |
//| since tau==0.5 too (1-0.5=0.5, the boundary case).                 |
//+--------------------------------------------------------------------+
double C02_PBOTrust(double pbo) {
    return MathMax(0.0, MathMin(1.0, 1.0 - pbo));
}

//+---------------------------------------------------------------------+
//| C02.F0004 -- the organ's one entry point. Composes all three guards |
//| via MIN (see header for why), thresholds at C02_TRUST_THRESHOLD, and|
//| names which guard(s) actually failed when rejecting.                |
//+---------------------------------------------------------------------+
C02_TrustResult C02_Evaluate(double gapPP, bool resampleDivergent, double pbo) {
    C02_TrustResult r;
    r.trustFromGap      = C02_GapTrust(gapPP);
    r.trustFromResample = C02_ResampleTrust(resampleDivergent);
    r.trustFromPBO      = C02_PBOTrust(pbo);
    r.trust = MathMin(r.trustFromGap, MathMin(r.trustFromResample, r.trustFromPBO));
    r.rejected = (r.trust < C02_TRUST_THRESHOLD);

    if(!r.rejected) { r.reason = ""; return r; }
    string failed = "";
    if(r.trustFromGap < C02_TRUST_THRESHOLD)      { if(StringLen(failed)>0) failed += ", "; failed += StringFormat("WF-gap %.1fpp exceeds %.1fpp", gapPP, C02_MAX_ACCEPTABLE_GAP_PP); }
    if(r.trustFromResample < C02_TRUST_THRESHOLD) { if(StringLen(failed)>0) failed += ", "; failed += "resample diverges from the main candidate"; }
    if(r.trustFromPBO < C02_TRUST_THRESHOLD)      { if(StringLen(failed)>0) failed += ", "; failed += StringFormat("PBO %.2f exceeds %.2f", pbo, 1.0 - C02_TRUST_THRESHOLD); }
    r.reason = "Rejected to equal weights \xB7 " + failed;
    return r;
}

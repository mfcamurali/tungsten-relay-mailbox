//+---------------------------------------------------------------------+
//| C03 · EvidenceLedger                                                |
//| GENESIS · COGNITION system · organ 03                               |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                  |
//+---------------------------------------------------------------------+
//| Purpose (GENESIS_MASTER_SPEC.md O6):                                |
//|   Persist per-regime edge evidence across restarts. Append-only,    |
//|   versioned, provenance-tagged; survives restart. Never resets;     |
//|   corruption caught by a schema/content hash.                       |
//| Invariants enforced: INV-11 (evidence persists across restarts),    |
//|                       INV-02 (every stored field is read back),     |
//|                       INV-03 (added pass_5 -- see C03_WinLossTally  |
//|                       near the bottom of this file: the real,       |
//|                       persisted accumulator a live GENESIS_Rate is  |
//|                       honestly built from).                         |
//|                                                                     |
//| Intent, extracted from the precedent (read directly, not copied):   |
//| WARRANT#116 (2026-08-05, flagged CRITICAL in this project's own     |
//| history) is INV-02's exact origin: SaveSystemState wrote            |
//| g_CorrelationsLearned but LoadSystemState never read it back --     |
//| every field persisted AFTER it in the file silently shifted 4 bytes |
//| on every instant-restart load, the root cause of a live run once    |
//| showing a "595048703%" win rate. Found only by a full mechanical    |
//| write-count-vs-read-count audit of every persistence pathway in the |
//| file -- the precedent's SAVE and LOAD were always two SEPARATE      |
//| functions (SaveSystemState / LoadSystemState, and the same pattern  |
//| repeats per-subsystem: LE_WriteCell/LE_ReadCell, PDB_WriteArmedTail/|
//| PDB_ReadArmedTail, Forge_WriteChampionTail/Forge_ReadChampionTail --|
//| every one of them a hand-maintained PAIR that can silently drift    |
//| apart, exactly as the g_CorrelationsLearned field did.              |
//|                                                                     |
//| What changed, and why (Law 1: intent kept, structure discarded):    |
//|   C03_SerializeEntry is ONE function, not a pair. It takes a        |
//|   writeMode flag and touches each field exactly once, in the SAME   |
//|   physical lines of code for both directions -- adding a field to   |
//|   the write path without the read path (or vice versa) is no longer |
//|   an available mistake, because there is only one function body to  |
//|   edit. A checksum (computed by the same pure function used both at |
//|   save time and at load-verification time) catches any corruption of|
//|   the file itself beyond field-order drift.                         |
//+---------------------------------------------------------------------+
#property strict
#include "..\GENESIS_Types.mqh"

#define C03_SCHEMA_VERSION 1          // C03.K0001
#define C03_MAGIC     0x45474C31      // C03.K0002 -- 'EGL1' (Evidence-ledGer v1), a format marker
#define C03_TALLY_SCHEMA_VERSION 1    // C03.K0003
#define C03_TALLY_MAGIC 0x57544C31    // C03.K0004 -- 'WTL1' (Win-Tally-Ledger v1)

//--- C03.S#### one persisted, provenance-tagged evidence record.
struct C03_Entry {
    int      regime;
    double   edge;
    double   ciLow;
    double   ciHigh;
    int      windowsUsed;
    datetime provenance;
};

struct C03_LoadResult {
    bool   ok;
    int    entriesLoaded;
    string error;
};

//+---------------------------------------------------------------------+
//| C03.F0001 -- THE single serializer. Same function, same field order,|
//| for both directions -- this is what makes INV-02 structural rather  |
//| than a discipline two hand-maintained functions have to remember to |
//| keep in sync.                                                       |
//+---------------------------------------------------------------------+
void C03_SerializeEntry(int handle, bool writeMode, C03_Entry &e) {
    if(writeMode) {
        FileWriteInteger(handle, e.regime);
        FileWriteDouble(handle, e.edge);
        FileWriteDouble(handle, e.ciLow);
        FileWriteDouble(handle, e.ciHigh);
        FileWriteInteger(handle, e.windowsUsed);
        FileWriteInteger(handle, (int)e.provenance);
    } else {
        e.regime      = FileReadInteger(handle);
        e.edge        = FileReadDouble(handle);
        e.ciLow       = FileReadDouble(handle);
        e.ciHigh      = FileReadDouble(handle);
        e.windowsUsed = FileReadInteger(handle);
        e.provenance  = (datetime)FileReadInteger(handle);
    }
}

//+-----------------------------------------------------------------------+
//| C03.F0002 -- pure checksum over an entry list, used identically at    |
//| save time (to write it) and at load time (to verify it) -- another    |
//| single-source-of-truth function rather than a hand-duplicated pair.   |
//| Not a cryptographic hash (MQL4 offers no such primitive natively);    |
//| a deterministic, order-sensitive sum is sufficient to catch accidental|
//| corruption/tampering, which is what this organ's contract asks for.   |
//+-----------------------------------------------------------------------+
double C03_Checksum(const C03_Entry &entries[]) {
    double sum = 0.0;
    int n = ArraySize(entries);
    for(int i = 0; i < n; i++) {
        // Position (i) is folded in so a REORDERING of entries changes the
        // checksum too, not just a value change -- "monotonic"/order-
        // preserving corruption is caught, not just field tampering.
        sum += (i + 1) * (entries[i].regime * 7919.0 + entries[i].edge * 104729.0
              + entries[i].ciLow * 15485863.0 + entries[i].ciHigh * 32452843.0
              + entries[i].windowsUsed * 2038074743.0 + (double)entries[i].provenance);
    }
    return sum;
}

//+---------------------------------------------------------------------+
//| C03.F0003 -- append-only save. Always writes the FULL entry list    |
//| (the caller owns appending in memory via C03_Append before calling  |
//| this -- "append-only" is a promise about the LEDGER's history, not a|
//| claim that this function does a partial-file append itself, which   |
//| would make checksum verification unreliable). Schema version and    |
//| magic marker are written first so a future format change can be     |
//| detected before any field is misread.                               |
//+---------------------------------------------------------------------+
bool C03_SaveLedger(string filename, const C03_Entry &entries[]) {
    int h = FileOpen(filename, FILE_BIN | FILE_WRITE);
    if(h == INVALID_HANDLE) return false;
    FileWriteInteger(h, C03_MAGIC);
    FileWriteInteger(h, C03_SCHEMA_VERSION);
    int n = ArraySize(entries);
    FileWriteInteger(h, n);
    for(int i = 0; i < n; i++) { C03_Entry e = entries[i]; C03_SerializeEntry(h, true, e); }
    FileWriteDouble(h, C03_Checksum(entries));
    FileClose(h);
    return true;
}

//+---------------------------------------------------------------------+
//| C03.F0004 -- load with full verification. Refuses (ok=false) on a   |
//| missing file, a magic/schema mismatch, OR a checksum mismatch -- any|
//| one of these means the content cannot be trusted, and this organ    |
//| NEVER partially trusts a ledger; it is either accepted whole or     |
//| refused whole (same "fail closed, never half-trust" discipline as   |
//| every other GENESIS organ built so far).                            |
//+---------------------------------------------------------------------+
C03_LoadResult C03_LoadLedger(string filename, C03_Entry &outEntries[]) {
    C03_LoadResult r; r.ok = false; r.entriesLoaded = 0; r.error = "";
    ArrayResize(outEntries, 0);

    if(!FileIsExist(filename)) { r.error = "File not found"; return r; }
    int h = FileOpen(filename, FILE_BIN | FILE_READ);
    if(h == INVALID_HANDLE) { r.error = "Could not open file"; return r; }

    int magic = FileReadInteger(h);
    if(magic != C03_MAGIC) { FileClose(h); r.error = "Not a GENESIS evidence ledger \xB7 magic marker mismatch"; return r; }
    int version = FileReadInteger(h);
    if(version != C03_SCHEMA_VERSION) { FileClose(h); r.error = StringFormat("Schema version mismatch \xB7 file=%d, expected=%d", version, C03_SCHEMA_VERSION); return r; }

    int n = FileReadInteger(h);
    if(n < 0 || n > 1000000) { FileClose(h); r.error = "Implausible entry count \xB7 refusing to trust"; return r; }   // sanity bound, same spirit as the precedent's own implausible-timestamp guard (WARRANT#95)

    C03_Entry loaded[]; ArrayResize(loaded, n);
    for(int i = 0; i < n; i++) {
        if(FileIsEnding(h)) { FileClose(h); r.error = StringFormat("File ended early \xB7 expected %d entries, found %d", n, i); return r; }
        C03_SerializeEntry(h, false, loaded[i]);
    }
    if(FileIsEnding(h)) { FileClose(h); r.error = "File ended before the checksum could be read"; return r; }
    double storedChecksum = FileReadDouble(h);
    FileClose(h);

    double recomputed = C03_Checksum(loaded);
    if(MathAbs(recomputed - storedChecksum) > 1e-6) {
        r.error = "Ledger content does not match what was saved \xB7 checksum mismatch (corrupted or tampered)";
        return r;   // ok stays false; outEntries stays empty -- never partially load a failed-checksum file
    }

    ArrayResize(outEntries, n);
    for(int i = 0; i < n; i++) outEntries[i] = loaded[i];
    r.ok = true; r.entriesLoaded = n;
    return r;
}

//+--------------------------------------------------------------------+
//| C03.F0005 -- append one entry to an in-memory ledger (pure: returns|
//| a grown copy, never mutates the caller's array out from under it). |
//+--------------------------------------------------------------------+
void C03_Append(C03_Entry &entries[], const C03_Entry &newEntry) {
    int n = ArraySize(entries);
    ArrayResize(entries, n + 1);
    entries[n] = newEntry;
}

//+-----------------------------------------------------------------------+
//| C03.S#### / F0006-F0009 -- the real win/loss tally (added pass_5,      |
//| closes the honest gap pass_4 flagged: "no organ yet actually CALLS     |
//| GENESIS_ComputeRate against real accumulated win/loss counts"). This   |
//| is deliberately a SEPARATE, small persisted record from C03_Entry --   |
//| a win rate (wins/trades) and an edge (mean ATR-normalised return) are  |
//| different concepts (the precedent kept g_Risk.recentWinRate and its    |
//| edge-tracking machinery separate too); conflating them into one struct |
//| would be the same "two mechanisms serving one intent" violation Law 2  |
//| forbids, just inverted -- one struct trying to serve two intents.      |
//|                                                                        |
//| C03_RecordOutcome -> C03_TallyToRate -> GENESIS_ComputeRate is the     |
//| real, live path from an actual observed trade outcome to a structurally|
//| honest GENESIS_Rate, closing INV-03's last open gap: GENESIS_Types.mqh |
//| existed and was tested, and G01_ArmController could CONSUME a rate,    |
//| but nothing actually PRODUCED one from real accumulated counts until   |
//| this.                                                                  |
//+-----------------------------------------------------------------------+
struct C03_WinLossTally {
    int wins;
    int losses;
};

//+---------------------------------------------------------------------+
//| C03.F0006 -- record one real, observed trade outcome. This is the    |
//| ONLY place a win/loss count changes -- there is no second accumulator|
//| anywhere in GENESIS for this concept (INV-08).                       |
//+---------------------------------------------------------------------+
void C03_RecordOutcome(C03_WinLossTally &tally, bool won) {
    if(won) tally.wins++;
    else    tally.losses++;
}

//+-----------------------------------------------------------------------+
//| C03.F0007 -- the real wiring: converts an accumulated tally into a     |
//| GENESIS_Rate via GENESIS_ComputeRate, which always divides by the      |
//| tally's own real total (wins+losses) -- WARRANT#124's failure shape    |
//| structurally unreproducible here, same as every other GENESIS_Rate.    |
//+-----------------------------------------------------------------------+
GENESIS_Rate C03_TallyToRate(const C03_WinLossTally &tally) {
    return GENESIS_ComputeRate(tally.wins, tally.wins + tally.losses);
}

//+---------------------------------------------------------------------+
//| C03.F0008 -- persist the tally (INV-11: survives restart). Same      |
//| magic+schema-first discipline as C03_SaveLedger, a separate file      |
//| format because it is a separate concept (see header).                |
//+---------------------------------------------------------------------+
bool C03_SaveTally(string filename, const C03_WinLossTally &tally) {
    int h = FileOpen(filename, FILE_BIN | FILE_WRITE);
    if(h == INVALID_HANDLE) return false;
    FileWriteInteger(h, C03_TALLY_MAGIC);
    FileWriteInteger(h, C03_TALLY_SCHEMA_VERSION);
    FileWriteInteger(h, tally.wins);
    FileWriteInteger(h, tally.losses);
    FileClose(h);
    return true;
}

//+---------------------------------------------------------------------+
//| C03.F0009 -- load the tally with magic/schema verification. Fails    |
//| closed (returns false, tally untouched) on any mismatch -- same       |
//| "never half-trust" discipline as C03_LoadLedger.                     |
//+---------------------------------------------------------------------+
bool C03_LoadTally(string filename, C03_WinLossTally &outTally, string &error) {
    error = "";
    if(!FileIsExist(filename)) { error = "File not found"; return false; }
    int h = FileOpen(filename, FILE_BIN | FILE_READ);
    if(h == INVALID_HANDLE) { error = "Could not open file"; return false; }

    int magic = FileReadInteger(h);
    if(magic != C03_TALLY_MAGIC) { FileClose(h); error = "Not a GENESIS win/loss tally \xB7 magic marker mismatch"; return false; }
    int version = FileReadInteger(h);
    if(version != C03_TALLY_SCHEMA_VERSION) { FileClose(h); error = StringFormat("Schema version mismatch \xB7 file=%d, expected=%d", version, C03_TALLY_SCHEMA_VERSION); return false; }

    C03_WinLossTally t;
    t.wins   = FileReadInteger(h);
    t.losses = FileReadInteger(h);
    FileClose(h);

    if(t.wins < 0 || t.losses < 0) { error = "Implausible tally \xB7 negative count \xB7 refusing to trust"; return false; }

    outTally = t;
    return true;
}

//+----------------------------------------------------------------------+
//| R01 · SubstrateDiagnostic                                            |
//| GENESIS · SUBSTRATE system · organ 01                                |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                   |
//+----------------------------------------------------------------------+
//| Purpose (GENESIS_MASTER_SPEC.md O14):                                |
//|   Classify a window series' stationarity into                        |
//|   {STATIONARY, TIME-VARYING, UNKNOWN}, with flip count and |t|.      |
//| Invariants enforced: INV-15 (match search to substrate),             |
//|                       INV-18 ('no edge' is a first-class verdict).   |
//|                                                                      |
//| Intent, extracted from the precedent (read directly, not copied):    |
//| TUNGSTEN_10.28_A7.5_QUANT_SLS(114).mq4 --                            |
//|   LE_Classify() (~line 36256) computed a 4-state phase               |
//|   (POSITIVE/NEGATIVE/TRANSITIONING/UNKNOWN) from LE_SUBWINDOWS=5     |
//|   sequential sub-window means, with a +-0.02 ATR dead-zone against   |
//|   noise and a >=30-observation floor (LE_DIAG_MIN_N) per sub-window, |
//|   duplicated identically across three separate cell arrays           |
//|   (g_DOW_Cell, g_TripleCell, g_RegimeSubstrate).                     |
//|   LE_TStatDemeaned() (~line 36302) computed a t-stat of a cell's mean|
//|   against a training-window baseline (Gate 2 nuisance de-meaning).   |
//|   A separate inline SYNTHESIS block (~line 40092-40109) aggregated   |
//|   flips+|t| across the 9 regime cells into a MOSTLY-TIME-VARYING /   |
//|   MOSTLY-FLAT verdict -- but only ran AFTER Phase 3B had already     |
//|   regularized every regime to equal weights, i.e. after a linear     |
//|   search had already committed to a method that (per that same       |
//|   verdict) could not capture what it found. This is INV-15's own     |
//|   documented origin (W-log SYNTHESIS).                               |
//|                                                                      |
//| What changed, and why (Law 1: intent kept, structure discarded):     |
//|   - ONE series type/classifier instead of three duplicated cell      |
//|     arrays each re-deriving the same phase logic (Law 2: one organ,  |
//|     one intent -- two mechanisms serving one intent are one organ).  |
//|   - Runs BEFORE any search commits (O15 SearchDispatcher consumes    |
//|     this organ's verdict to choose method), not as an after-the-fact |
//|     explanation of an already-committed search.                      |
//|   - UNKNOWN (insufficient power) reports its t-stat as EMPTY_VALUE   |
//|     (MQL4's native "not computed" double sentinel), never 0.0 --     |
//|     the precedent's LE_TStat/LE_TStatDemeaned silently returned 0.0  |
//|     for n<floor, indistinguishable from a genuinely-measured zero    |
//|     t-stat. That silent ambiguity is exactly the class of failure    |
//|     INV-18 exists to make impossible: a verdict must never be        |
//|     confusable with "the answer was measured and happens to be zero."|
//+----------------------------------------------------------------------+
#property strict
#include "..\GENESIS_Constants.mqh"

//--- R01.K#### knobs -- named constants, each referenced everywhere it is
//--- used (INV-08: no duplicated magic numbers). Values match the
//--- precedent's own proven floors/thresholds (kept as benchmark, per
//--- Law 1) but are now GENESIS-owned, not inherited by reference.
#define R01_SUBWINDOWS            5     // R01.K0001 -- sequential sub-windows per series
#define R01_MIN_N_PER_SUBWINDOW  GENESIS_DIAGNOSTIC_POWER_FLOOR     // R01.K0002 -- diagnostic power floor (never a trading-weight floor) -- INV-07: aliases the one shared concept, not a second literal 30
#define R01_DEADZONE              0.02  // R01.K0003 -- ATR dead-zone; a mean inside this counts as no side
#define R01_TSTAT_THRESHOLD       3.0   // R01.K0004 -- |t| beyond this is treated as real sign-inversion evidence

//--- R01.V#### verdict enum -- the organ's one output type
enum R01_SubstrateClass {
    R01_UNKNOWN      = 0,   // insufficient power to classify -- NEVER assumed stationary (INV-18)
    R01_STATIONARY   = 1,   // consistent sign, no flips, |t| below threshold
    R01_TIME_VARYING = 2    // sign flip observed OR |t| beyond threshold -- a moving, non-stationary edge
};

//--- R01.S#### state -- the series accumulator. One generic type replaces
//--- the precedent's three duplicated cell arrays (g_DOW_Cell/g_TripleCell/
//--- g_RegimeSubstrate all used the identical LivingEdgeCell shape and
//--- LE_Classify logic) -- callers own however many instances they need
//--- (per-regime, per-day-of-week, per-session-cell, ...), the organ itself
//--- is agnostic to what a series represents.
struct R01_Series {
    int    n;
    double sumR;
    double sumR2;
    int    subN[R01_SUBWINDOWS];
    double subSumR[R01_SUBWINDOWS];
};

//--- R01.V#### the organ's single decisive output
struct R01_Verdict {
    R01_SubstrateClass classOut;
    int                flips;
    double             tstat;     // EMPTY_VALUE when classOut==R01_UNKNOWN -- never a fabricated 0.0
    int                nTotal;
};

//+---------------------------+
//| R01.F0001 -- zero a series|
//+---------------------------+
void R01_ZeroSeries(R01_Series &s) {
    s.n = 0; s.sumR = 0.0; s.sumR2 = 0.0;
    for(int w = 0; w < R01_SUBWINDOWS; w++) { s.subN[w] = 0; s.subSumR[w] = 0.0; }
}

//+------------------------------------------------------------------------+
//| R01.F0002 -- accumulate one observation into a series                  |
//| subIdx must be in [0, R01_SUBWINDOWS); caller owns how a window is     |
//| partitioned into sequential sub-windows (e.g. chronological quintiles).|
//+------------------------------------------------------------------------+
void R01_Accumulate(R01_Series &s, double r, int subIdx) {
    if(subIdx < 0 || subIdx >= R01_SUBWINDOWS) return;   // out-of-range write is silently refused, never clamped into a wrong bucket
    s.n++; s.sumR += r; s.sumR2 += r * r;
    s.subN[subIdx]++; s.subSumR[subIdx] += r;
}

//+-----------------------------------------------------------------------+
//| R01.F0003 -- de-meaned t-stat of the series' mean against a baseline. |
//| Variance is baseline-invariant (subtracting a constant shifts the mean|
//| but not the spread), so only the numerator changes vs a raw zero-mean |
//| t-stat -- same construction the precedent used for Gate 2 (nuisance   |
//| de-meaning: judge a series against the instrument's own drift this    |
//| window, never against a hardcoded zero).                              |
//| Returns EMPTY_VALUE (not 0.0) when n < R01_MIN_N_PER_SUBWINDOW --     |
//| "not computed" must never be representable as "computed and zero"     |
//| (INV-18).                                                             |
//+-----------------------------------------------------------------------+
double R01_TStat(const R01_Series &s, double baseline) {
    if(s.n < R01_MIN_N_PER_SUBWINDOW) return EMPTY_VALUE;
    double mean = s.sumR / s.n - baseline;
    double var  = MathMax(0.0, s.sumR2 / s.n - (s.sumR / s.n) * (s.sumR / s.n));
    double se   = MathSqrt(var / s.n);
    return (se > 1e-9) ? mean / se : EMPTY_VALUE;   // a genuinely zero-variance series can't be t-tested either -- also honestly "not computed", not a fabricated infinity or zero
}

//+--------------------------------------------------------------------+
//| R01.F0004 -- count sign flips across the series' sequential        |
//| sub-windows. A sub-window contributes a sign only with             |
//| >=R01_MIN_N_PER_SUBWINDOW observations; a mean inside the dead-zone|
//| counts as no side rather than manufacturing a flip from noise.     |
//+--------------------------------------------------------------------+
int R01_Flips(const R01_Series &s) {
    int lastSign = 0, flips = 0;
    for(int w = 0; w < R01_SUBWINDOWS; w++) {
        if(s.subN[w] < R01_MIN_N_PER_SUBWINDOW) continue;
        double m = s.subSumR[w] / s.subN[w];
        int sign = (m > R01_DEADZONE) ? 1 : (m < -R01_DEADZONE ? -1 : 0);
        if(sign != 0) {
            if(lastSign != 0 && sign != lastSign) flips++;
            lastSign = sign;
        }
    }
    return flips;
}

//+----------------------------------------------------------------------+
//| R01.F0005 -- the organ's one entry point. Classifies a series'       |
//| stationarity: UNKNOWN if underpowered, else TIME_VARYING if a sign   |
//| flip occurred or |t| clears the threshold, else STATIONARY.          |
//| This is the exact "flips>0 || |t|>3" test the precedent's SYNTHESIS  |
//| block used per-regime after the fact -- now the organ's own contract,|
//| runnable before any search commits (feeds O15 SearchDispatcher).     |
//+----------------------------------------------------------------------+
R01_Verdict R01_Classify(const R01_Series &s, double baseline) {
    R01_Verdict v;
    v.nTotal = s.n;
    if(s.n < R01_MIN_N_PER_SUBWINDOW) {
        v.classOut = R01_UNKNOWN;
        v.flips    = 0;
        v.tstat    = EMPTY_VALUE;
        return v;
    }
    v.flips = R01_Flips(s);
    v.tstat = R01_TStat(s, baseline);
    bool tstatStructured = (v.tstat != EMPTY_VALUE) && (MathAbs(v.tstat) > R01_TSTAT_THRESHOLD);
    v.classOut = (v.flips > 0 || tstatStructured) ? R01_TIME_VARYING : R01_STATIONARY;
    return v;
}

//+-----------------------------------------------------------------------+
//| R01.F0007 -- PROMETHEUS 3.5 (added pass_6): an explicit flip-          |
//| probability, turning the flip COUNT (F0004) into a [0,1] estimate a    |
//| caller can compose into confidence -- closes the charter's own spine   |
//| requirement, "every edge carries... a flip-probability, and [it]       |
//| gates deployment," which a raw count alone did not directly satisfy.   |
//| Denominator is possible TRANSITIONS between powered sub-windows        |
//| (poweredSubwindows-1), not R01_SUBWINDOWS itself -- an underpowered    |
//| sub-window contributes no transition either way, same "only powered    |
//| evidence counts" discipline R01_Flips already applies.                 |
//+-----------------------------------------------------------------------+
double R01_FlipProbability(const R01_Series &s) {
    int poweredSubwindows = 0;
    for(int w = 0; w < R01_SUBWINDOWS; w++) if(s.subN[w] >= R01_MIN_N_PER_SUBWINDOW) poweredSubwindows++;
    if(poweredSubwindows < 2) return 0.0;   // fewer than 2 powered sub-windows -- no transition is even measurable
    int flips = R01_Flips(s);
    int possibleTransitions = poweredSubwindows - 1;
    return MathMax(0.0, MathMin(1.0, (double)flips / (double)possibleTransitions));
}

//+-----------------------------------------------------------------------+
//| R01.F0008 -- PROMETHEUS 3.5: composes flip-probability INTO a base     |
//| confidence value -- never a second, separate multiplier downstream,    |
//| same "compose upstream, one confidence slot" discipline R03/A03        |
//| already establish for freshness/deployment (INV-12). A high flip-      |
//| probability shrinks trust toward zero; a never-flipped series leaves   |
//| confidence untouched.                                                  |
//+-----------------------------------------------------------------------+
double R01_ApplyFlipDiscount(double baseConfidence, double flipProbability) {
    double fp = MathMax(0.0, MathMin(1.0, flipProbability));
    return baseConfidence * (1.0 - fp);
}

//+------------------------------------------------------------------+
//| R01.F0006 -- human-readable name, for logging (feeds G03 Logger).|
//+------------------------------------------------------------------+
string R01_ClassName(R01_SubstrateClass c) {
    if(c == R01_STATIONARY)   return "STATIONARY";
    if(c == R01_TIME_VARYING) return "TIME-VARYING";
    return "UNKNOWN";
}

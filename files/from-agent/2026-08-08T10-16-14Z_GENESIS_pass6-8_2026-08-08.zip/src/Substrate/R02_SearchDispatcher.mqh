//+-----------------------------------------------------------------------+
//| R02 · SearchDispatcher                                                |
//| GENESIS · SUBSTRATE system · organ 02                                 |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                    |
//+-----------------------------------------------------------------------+
//| Purpose (GENESIS_MASTER_SPEC.md O15):                                 |
//|   Choose the search method per substrate class: STATIONARY->linear;   |
//|   TIME-VARYING->recency-weighted/curated-neural; deterministic,       |
//|   total mapping -- a mismatched method must be structurally           |
//|   impossible.                                                         |
//| Invariant enforced: INV-15 (match search to substrate).               |
//| Depends on: R01 SubstrateDiagnostic (consumes its R01_Verdict).       |
//|                                                                       |
//| Intent, extracted from the precedent: INV-15's own origin (W-log      |
//| SYNTHESIS) is that a fixed-window LINEAR search cannot capture        |
//| time-varying structure "by design" -- the precedent never had a       |
//| dispatch step at all; every regime went through the identical         |
//| 50,000-draw linear grid search (OptimizeComponentWeightsForRegime)    |
//| regardless of what its own substrate diagnosis would have said, had   |
//| one run before the search instead of after (see R01's own header).    |
//| O15 is the organ that makes "search the regime with the tool that     |
//| fits its own measured behaviour" a structural guarantee instead of a  |
//| gap discovered post-hoc.                                              |
//|                                                                       |
//| Scope, stated honestly: this organ ONLY chooses a method label. It    |
//| does not implement any search algorithm -- LINEAR and RECENCY_WEIGHTED|
//| search bodies belong to Cognition (O4 EdgeAdjudicator / O5            |
//| OverfitImmune territory), built later per the movement order.         |
//|                                                                       |
//| UPDATE: CURATED_NEURAL is now real. R04_CuratedNeuralNet.mqh          |
//| implements a genuine, working, two-hidden-layer feedforward network   |
//| (real forward pass + real backprop) -- built the same session Manuel  |
//| explicitly named it again with a clear head, satisfying the exact     |
//| precondition tungsten_forge_neural_bookmark (2026-08-06) set for      |
//| building it for real. R02_IsAvailable(R02_CURATED_NEURAL) is TRUE now |
//| -- the mechanism compiles and works (see R04's own acceptance test).  |
//| It is deliberately kept OUT of R02_Dispatch's default routing below:  |
//| "available" (the mechanism is real) and "trustworthy for THIS regime's|
//| live decision" (it has seen enough real training data) are different  |
//| questions -- R04_IsTrustworthy() gates the second one, requiring the  |
//| same n>=500 floor every other live-decision-affecting read in this    |
//| project requires. R02_DispatchWithNeuralOption() is the richer entry  |
//| point a caller uses once it can honestly answer "is the network       |
//| trustworthy right now" -- R02_Dispatch() itself stays the safe,       |
//| always-available default.                                             |
//+-----------------------------------------------------------------------+
#property strict

#include "R01_SubstrateDiagnostic.mqh"

//--- R02.V#### the method a candidate search space gets evaluated with
enum R02_SearchMethod {
    R02_LINEAR           = 0,   // fixed-window linear search -- only valid for a genuinely stationary substrate
    R02_RECENCY_WEIGHTED = 1,   // recency-weighted / rolling search -- tracks a moving edge
    R02_CURATED_NEURAL   = 2    // named by the spec; NOT YET IMPLEMENTED anywhere in GENESIS (see header) -- R02_IsAvailable() is false for this value until its own dedicated build lands
};

//+----------------------------------------------------------------------+
//| R02.F0001 -- is this method actually buildable/callable right now.   |
//| The dispatch table (F0002) must never route a live decision to a     |
//| method this returns false for -- that is what "mismatched method     |
//| impossible" means in an environment where one of the spec's own named|
//| methods doesn't exist yet.                                           |
//+----------------------------------------------------------------------+
bool R02_IsAvailable(R02_SearchMethod m) {
    if(m == R02_LINEAR)           return true;
    if(m == R02_RECENCY_WEIGHTED) return true;
    if(m == R02_CURATED_NEURAL)   return true;   // real as of R04_CuratedNeuralNet.mqh -- available != trustworthy-for-this-decision, see header
    return false;   // any future method not yet built
}

//+----------------------------------------------------------------------+
//| R02.F0002 -- the organ's one entry point. Total, deterministic       |
//| mapping over every R01_SubstrateClass value:                         |
//|   STATIONARY   -> LINEAR (the only class for which a fixed-window    |
//|                    search is a legitimate tool)                      |
//|   TIME_VARYING -> RECENCY_WEIGHTED (CURATED_NEURAL would be the      |
//|                    higher-fidelity choice per the spec, but is not   |
//|                    available -- see header; falling back to a lesser |
//|                    but REAL method beats silently no-op'ing to one   |
//|                    that doesn't exist)                               |
//|   UNKNOWN      -> RECENCY_WEIGHTED, not LINEAR. Deliberate: assuming |
//|                    stationarity under genuine uncertainty is exactly |
//|                    the failure Law 5 exists to prevent ("every       |
//|                    downstream organ is born expecting a moving       |
//|                    edge") -- an underpowered read must never default |
//|                    to the assumption that requires the LEAST evidence|
//|                    to justify.                                       |
//+----------------------------------------------------------------------+
R02_SearchMethod R02_Dispatch(const R01_Verdict &v) {
    R02_SearchMethod chosen;
    if(v.classOut == R01_STATIONARY) chosen = R02_LINEAR;
    else                              chosen = R02_RECENCY_WEIGHTED;   // covers both TIME_VARYING and UNKNOWN

    // Structural guarantee, not a defensive afterthought: whatever this
    // function returns must be dispatchable. If a future edit ever makes
    // the STATIONARY branch above point at an unavailable method, this
    // catches it here rather than at some distant call site.
    if(!R02_IsAvailable(chosen)) chosen = R02_RECENCY_WEIGHTED;
    return chosen;
}

//+----------------------------------------------------------------------+
//| R02.F0004 -- the richer entry point: a TIME_VARYING verdict routes to|
//| CURATED_NEURAL only when the caller can honestly assert the network  |
//| is trustworthy right now (neuralIsTrustworthy -- compute this via    |
//| R04_IsTrustworthy() before calling, this organ does not import R04 to|
//| keep the dependency direction one-way: R04 implements what R02 names,|
//| R02 never needs to know R04's internals). STATIONARY and UNKNOWN are |
//| untouched by this parameter -- the neural option only ever applies to|
//| the class it was actually built for.                                 |
//+----------------------------------------------------------------------+
R02_SearchMethod R02_DispatchWithNeuralOption(const R01_Verdict &v, bool neuralIsTrustworthy) {
    if(v.classOut == R01_TIME_VARYING && neuralIsTrustworthy && R02_IsAvailable(R02_CURATED_NEURAL))
        return R02_CURATED_NEURAL;
    return R02_Dispatch(v);
}

//+------------------------------------------------------------------+
//| R02.F0003 -- human-readable name, for logging (feeds G03 Logger).|
//+------------------------------------------------------------------+
string R02_MethodName(R02_SearchMethod m) {
    if(m == R02_LINEAR)           return "LINEAR";
    if(m == R02_RECENCY_WEIGHTED) return "RECENCY-WEIGHTED";
    if(m == R02_CURATED_NEURAL)   return "CURATED-NEURAL";
    return "UNRECOGNIZED-METHOD";
}

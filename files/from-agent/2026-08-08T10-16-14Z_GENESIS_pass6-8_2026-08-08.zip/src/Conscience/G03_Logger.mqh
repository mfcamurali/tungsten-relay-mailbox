//+----------------------------------------------------------------------+
//| G03 · Logger                                                         |
//| GENESIS · CONSCIENCE system · organ 03                               |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                   |
//+----------------------------------------------------------------------+
//| Purpose (GENESIS_MASTER_SPEC.md O12):                                |
//|   The one observability spine. Every verdict emits exactly one       |
//|   live-feed line; Print banned in decision code. A silent decision   |
//|   cannot exist.                                                      |
//| Invariant enforced: INV-06 (no Print-only decision path).            |
//|                                                                      |
//| Intent, extracted from the precedent (read directly, not copied):    |
//| WARRANT#130 (2026-08-06) is INV-06's own named origin, discovered the|
//| same session as the forge-neural bookmark: LE_Log() turned out to be |
//| a SECOND, entirely separate Print-only logging function, independent |
//| of the precedent's real feed-writing spine (TLog/TLog_Head, which    |
//| WARRANT#31 had already hardened to FileWrite+FileFlush after every   |
//| line) -- LE_Log silently ate the KEYS-3 decisive-experiment line all |
//| session because Print() alone doesn't survive an MT4 hang/kill the   |
//| way a flushed file line does (the exact failure WARRANT#31 fixed for |
//| TLog, but never for this second, parallel function). Two spines,     |
//| discovered by finding one had quietly drifted, is the precise shape  |
//| of the "duplicated truth" defect class this whole campaign fought    |
//| repeatedly (WARRANT#101/102) -- just applied to logging instead of a |
//| threshold constant.                                                  |
//|                                                                      |
//| What changed, and why (Law 1: intent kept, structure discarded):     |
//|   ONE function. G03_LogVerdict is the only sanctioned way to log a   |
//|   decision anywhere in GENESIS -- there is no second logging function|
//|   for any organ to accidentally reach for. It always does BOTH what  |
//|   TLog did well (Print for immediate visibility) AND what WARRANT#31 |
//|   had to retrofit onto TLog after a real hang cost it (FileWrite+    |
//|   FileFlush immediately, so content survives a kill even if Print's  |
//|   own buffer doesn't) -- from its very first line, not retrofitted   |
//|   after a second incident.                                           |
//|                                                                       |
//| Line design (added pass_5 -- "curate all logs to be more elegant, it  |
//| should feel like a product, not a beta idea"): studied Apple's        |
//| unified system log (Console.app -- a calm fixed timestamp column,     |
//| one clean subsystem field, no bracket-nesting, the message itself     |
//| never touched or truncated to make room for chrome) and Huawei's      |
//| device/AI-status readouts (a centred middle dot as the ONLY separator |
//| between segments, short precise field labels, confident sentence      |
//| case rather than SCREAMING prefixes). Neither uses "[...]" bracket    |
//| nesting or a raw "|" pipe -- both read as terminal/debug notation,    |
//| not a shipped product. The new template is one calm horizontal read:  |
//| timestamp, organ, message, divided by a single centred dot with       |
//| breathing space either side, nothing else. G03_LogVerdict never       |
//| rewrites the caller's message (only frames it) -- pass_5 separately   |
//| rewrote every organ's own reason/narrative/error string to the same   |
//| confident, sentence-case style this frame expects (see G01/G02/G04/   |
//| C01/C02/C03/C04/A02/P03's own headers).                               |
//+----------------------------------------------------------------------+
#property strict

#define G03_LOG_FILENAME "genesis_live_feed.log"   // G03.K0001
#define G03_FIELD_SEPARATOR "  \xB7  "               // G03.K0002 -- a single centred dot (U+00B7), Huawei-status-line style; never a bracket or a pipe (added pass_5, see header)

int g_G03_EmittedCount = 0;   // G03.S0001 -- lets a caller/test confirm exactly one line was emitted per call, not zero and not two

//+----------------------------------------------------------------------+
//| G03.F0001 -- the organ's one entry point. Every organ in GENESIS that|
//| needs to report a decision/verdict calls THIS function, never Print()|
//| directly -- see the grep-based audit note in GENESIS_LEDGER.json's   |
//| G03 entry confirming Print() appears nowhere else in src/ outside    |
//| this file.                                                           |
//+----------------------------------------------------------------------+
void G03_LogVerdict(string source, string message) {
    string stamp = TimeToString(TimeCurrent(), TIME_DATE | TIME_SECONDS);
    string line = stamp + G03_FIELD_SEPARATOR + source + G03_FIELD_SEPARATOR + message;
    Print(line);
    int h = FileOpen(G03_LOG_FILENAME, FILE_TXT | FILE_READ | FILE_WRITE);
    if(h != INVALID_HANDLE) {
        FileSeek(h, 0, SEEK_END);
        FileWrite(h, line);
        FileFlush(h);
        FileClose(h);
    }
    g_G03_EmittedCount++;
}

//+--------------------------------------------------------------------+
//| G03.F0002 -- for a test/caller to confirm how many lines this organ|
//| has emitted this session, without re-reading the file.             |
//+--------------------------------------------------------------------+
int G03_GetEmittedCount() {
    return g_G03_EmittedCount;
}

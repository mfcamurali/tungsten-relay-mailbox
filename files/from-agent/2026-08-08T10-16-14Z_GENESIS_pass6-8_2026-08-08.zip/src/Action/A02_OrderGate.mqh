//+-----------------------------------------------------------------------+
//| A02 · OrderGate                                                       |
//| GENESIS · ACTION system · organ 02                                    |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                    |
//+-----------------------------------------------------------------------+
//| Purpose (GENESIS_MASTER_SPEC.md O8):                                  |
//|   The single broker chokepoint; enforce HARD_FLOOR. Clamps to         |
//|   HARD_FLOOR; is the ONLY code that calls the broker. No other path   |
//|   to broker compiles; over-floor attempt throws.                      |
//| Invariant enforced: INV-04 (one hard risk floor, one chokepoint).     |
//|                                                                       |
//| Intent, extracted from the precedent (read directly, not copied):     |
//| WARRANT#127 is INV-04's own named origin: a range-trading order path  |
//| bypassed the 7.5% risk ceiling entirely -- a SEPARATE code path to the|
//| broker existed that the main risk-clamp logic never touched. This is  |
//| the structural twin of WARRANT#109's SizeEngine defect (A01's own     |
//| header): both are "the enforcement point wasn't actually the only     |
//| door," just discovered on the sizing side once and the order-placement|
//| side once. The precedent's own SafeOrderSend() wrapper was a real,    |
//| genuine attempt at a chokepoint -- WARRANT#127's bug is evidence that |
//| a wrapper FUNCTION existing isn't the same guarantee as a wrapper     |
//| being the ONLY caller of the broker API anywhere in the file.         |
//|                                                                       |
//| What changed, and why (Law 1: intent kept, structure discarded):      |
//|   HARD_FLOOR is reused from A01 SizeEngine (same constant, one        |
//|   definition -- see A01's own header for why it lives there           |
//|   physically). This organ's own clamp is a SECOND, independent        |
//|   enforcement of the identical floor (defense in depth: A01 already   |
//|   clamps when composing size; A02 clamps again at the actual gate to  |
//|   the broker, so no path that skips A01 -- intentionally or by a      |
//|   future bug -- can still exceed the floor). The actual broker call   |
//|   (OrderSend-equivalent) is a deliberately DORMANT placeholder --     |
//|   this pass builds the gate/clamp logic only; wiring a real broker    |
//|   call is its own future decision needing Manuel's explicit per-run   |
//|   consent naming live execution, same standing rule as every          |
//|   TUNGSTEN live-run request this project has ever honored             |
//|   (forge-4d-alpha's Phase B dormancy). "No other path to broker       |
//|   compiles" is verified as a real, automated architectural fact, not  |
//|   just asserted -- see the build note in GENESIS_LEDGER.json's A02    |
//|   entry for the grep-based audit confirming zero OrderSend/OrderClose/|
//|   OrderModify/OrderDelete references exist anywhere in src/ outside   |
//|   this file's own (currently dormant) placeholder.                    |
//+-----------------------------------------------------------------------+
#property strict

#include "A01_SizeEngine.mqh"   // reuses A01_HARD_FLOOR_PERCENT -- one definition, per INV-08

#define A02_LIVE_EXECUTION_ENABLED false   // A02.K0002 -- master dormancy switch. Matches forge-4d-alpha's Phase B precedent: stays false until Manuel explicitly authorizes live execution.

//--- A02.V#### the gate's decision on a proposed risk size.
struct A02_GateDecision {
    double approvedRiskPercent;
    bool   approved;
    bool   wasClamped;
    string reason;
};

//+----------------------------------------------------------------------+
//| A02.F0001 -- the floor clamp itself, reusable independent of the full|
//| gate decision (e.g. for a caller that just wants the clamped number).|
//+----------------------------------------------------------------------+
double A02_ClampToFloor(double proposedRiskPercent) {
    return MathMax(0.0, MathMin(A01_HARD_FLOOR_PERCENT, proposedRiskPercent));
}

//+---------------------------------------------------------------------+
//| A02.F0002 -- the gate's one entry point for a proposed risk size,   |
//| independent of order/entry TYPE (market, stop, limit, sign-agnostic |
//| bracket leg, ...) -- the floor applies identically regardless of HOW|
//| the order will eventually be placed, which is what "every entry type|
//| routes here" means: this function does not branch on entry type at  |
//| all, so there is no entry-type-shaped hole for a future one to slip |
//| through unclamped (the exact shape of WARRANT#127's bug -- a NEW    |
//| order-placement path that the clamp logic simply never knew about). |
//+---------------------------------------------------------------------+
A02_GateDecision A02_Gate(double proposedRiskPercent) {
    A02_GateDecision d;
    d.wasClamped = (proposedRiskPercent > A01_HARD_FLOOR_PERCENT);
    d.approvedRiskPercent = A02_ClampToFloor(proposedRiskPercent);
    d.approved = (d.approvedRiskPercent > 0.0);
    d.reason = d.wasClamped
        ? StringFormat("Clamped \xB7 %.4f%% requested, %.4f%% approved (hard floor)", proposedRiskPercent, A01_HARD_FLOOR_PERCENT)
        : "";
    return d;
}

//+----------------------------------------------------------------------+
//| A02.F0003 -- the ONE function in this entire codebase that would ever|
//| call a broker order-placement API. Deliberately dormant (see header):|
//| returns false with a clear reason while A02_LIVE_EXECUTION_ENABLED is|
//| false, and the actual OrderSend-equivalent call is left as a         |
//| documented placeholder rather than live code, so this organ cannot   |
//| accidentally place a real order just by existing in a compiled build.|
//| A caller that somehow proposes a risk above the floor gets REFUSED   |
//| outright here (not silently clamped-and-placed) -- "over-floor       |
//| attempt throws" in spirit: this organ treats an already-over-floor   |
//| request reaching the actual placement step as a logic error upstream |
//| (A01 should have clamped already), not something to quietly fix here.|
//+----------------------------------------------------------------------+
bool A02_PlaceOrder(double approvedRiskPercent, string &outError) {
    if(approvedRiskPercent > A01_HARD_FLOOR_PERCENT) {
        outError = StringFormat("REFUSED \xB7 risk %.4f%% exceeds the hard floor %.4f%% at the placement chokepoint \xB7 upstream sizing did not clamp correctly",
                                 approvedRiskPercent, A01_HARD_FLOOR_PERCENT);
        return false;
    }
    if(!A02_LIVE_EXECUTION_ENABLED) {
        outError = "DISABLED \xB7 live execution is off \xB7 no order was placed";
        return false;
    }
    // The ONLY call to a broker order-placement API anywhere in GENESIS
    // would live here, e.g.:
    //   int ticket = OrderSend(symbol, cmd, lots, price, slippagePoints, sl, tp, comment, magic, 0, clrNONE);
    // Left as a design placeholder, not live code -- wiring this is a
    // separate future decision requiring Manuel's explicit per-run
    // consent naming live execution.
    outError = "";
    return false;   // still false: nothing above is wired yet
}

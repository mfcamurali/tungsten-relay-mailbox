//+-----------------------------------------------------------------------+
//| A01 · SizeEngine                                                      |
//| GENESIS · ACTION system · organ 01                                    |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                    |
//+-----------------------------------------------------------------------+
//| Purpose (GENESIS_MASTER_SPEC.md O7):                                  |
//|   Compose position size; confidence exactly once.                     |
//|   size = kelly(edge) x confidence x dd_budget x (1/n_eff),            |
//|   then min(size, FLOOR).                                              |
//| Invariants enforced: INV-12 (confidence enters size exactly once),    |
//|                       INV-13 (correlated bets counted once),          |
//|                       INV-04 (one hard risk floor, one chokepoint).   |
//|                                                                       |
//| Intent, extracted from the precedent (read directly, not copied):     |
//| LE_ComputeCappedKellySize (~line 38122, WARRANT#44) is a real, sound  |
//| capped-fractional-Kelly formula: f = kappa*edge/variance, bounded     |
//| [0,cap] -- kept verbatim as this organ's kelly() sub-function, since  |
//| the math itself was never the problem. The problem WARRANT#109        |
//| (2026-08-02, forge-bestofboth) found and fixed: a SEPARATE confidence |
//| multiplier stack (regime/conviction/memory/predictive/validation/     |
//| awareness signals, bounded [0.50,2.50]) multiplied riskAmount AGAIN,  |
//| downstream of the already-Kelly-sized base risk, with neither stack   |
//| aware of the other -- worst case 7.5% x 2.5 = 18.75% realized risk    |
//| under legitimate in-range operation, silently exceeding the documented|
//| 7.5% ceiling. That is INV-12's own named origin, verbatim.            |
//| INV-13 (correlated bets counted once) traces to forge-bestofboth's own|
//| charter-v2 concept, not yet built anywhere in the precedent -- a      |
//| standard, citable effective-N-under-equicorrelation formula           |
//| (n_eff = N/(1+(N-1)*rho)) is used here, not invented.                 |
//|                                                                       |
//| What changed, and why (Law 1: intent kept, structure discarded):      |
//|   ONE function signature (A01_ComposeSize) with EXACTLY ONE           |
//|   confidence parameter, multiplied in EXACTLY ONE place in the        |
//|   formula -- there is no second parameter anywhere in this organ's    |
//|   API a caller could mistake for a second confidence signal to stack. |
//|   Whatever fed WARRANT#109's confidence-multiplier stack (regime/     |
//|   conviction/memory/predictive/validation/awareness) must be composed |
//|   INTO that one confidence value BEFORE calling this organ (same      |
//|   "compose upstream, never add a second factor here" discipline R03   |
//|   TimeAwareSizing's own header already establishes for freshness      |
//|   decay).                                                             |
//+-----------------------------------------------------------------------+
#property strict

//--- A01.K#### -- HARD_FLOOR is conceptually O8 OrderGate's own knob
//--- (A02.K0001 per GENESIS_NAMING_SYSTEM.md's worked example -- OrderGate
//--- is the single chokepoint that must enforce it on every path to the
//--- broker) -- but O7 SizeEngine's OWN contract also requires
//--- "min(size,FLOOR) applied last" as its final composition step, and a
//--- caller of THIS organ may never reach O8 at all if it discards O7's
//--- output early (e.g. a dry-run/diagnostic caller). Defining the
//--- constant here, once, and having A02_OrderGate.mqh #include this file
//--- to reuse the identical value (rather than redefining it) keeps
//--- INV-08 (no duplicated magic numbers) intact while still satisfying
//--- BOTH organs' own literal contracts -- a deliberate, documented
//--- deviation from the naming doc's implied file location, made for a
//--- concrete technical reason (avoiding two independent #define sites   |
//--- for the one number that must never drift apart).                   |
#define A01_HARD_FLOOR_PERCENT 7.5   // A02.K0001 -- matches this project's own documented, real ceiling (WARRANT#109)

//--- A01.K#### kelly sub-function knobs, matching the precedent's own
//--- proven defaults (KellyFraction=0.25 quarter-Kelly, cap language).
#define A01_KELLY_KAPPA_DEFAULT 0.25   // A01.K0001
#define A01_KELLY_CAP_DEFAULT   0.05   // A01.K0002 -- fraction of capital, matches precedent's LE_ComputeCappedKellySize default cap
#define A01_MIN_VARIANCE        0.0001 // A01.K0003 -- below this, kelly abstains (returns 0) rather than dividing by near-zero
#define A01_CORRELATION_SAFETY_MARGIN 0.10   // A01.K0004 -- PROMETHEUS 2.1: a named margin added to a MEASURED correlation before sizing, not tuned per-call

//+----------------------------------------------------------------------+
//| A01.F0001 -- capped fractional-Kelly, kept from the precedent's real,|
//| sound formula verbatim (see header). Never negative -- an edge below |
//| zero returns 0, this never sizes a bet against its own measured      |
//| direction.                                                           |
//+----------------------------------------------------------------------+
double A01_Kelly(double edge, double varianceProxy, double kappa = A01_KELLY_KAPPA_DEFAULT, double cap = A01_KELLY_CAP_DEFAULT) {
    if(varianceProxy <= A01_MIN_VARIANCE) return 0.0;
    if(edge <= 0.0) return 0.0;
    double f = kappa * edge / varianceProxy;
    return MathMax(0.0, MathMin(cap, f));
}

//+----------------------------------------------------------------------+
//| A01.F0002 -- effective independent bet count under average pairwise  |
//| correlation rho, for N (raw, simultaneously-open) positions. Standard|
//| equicorrelation effective-N: n_eff = N/(1+(N-1)*rho).                |
//| rho is clamped to [0,1] -- a negative measured correlation is treated|
//| as zero here rather than allowed to INFLATE n_eff past N, which is   |
//| what "conservative bias" (n_eff<=N always) requires.                 |
//+----------------------------------------------------------------------+
double A01_EffectiveN(int rawN, double avgCorrelation) {
    if(rawN <= 0) return 0.0;
    double rho = MathMax(0.0, MathMin(1.0, avgCorrelation));
    double denom = 1.0 + (rawN - 1.0) * rho;
    double nEff = (denom > 1e-9) ? (rawN / denom) : (double)rawN;
    return MathMax(1.0, MathMin((double)rawN, nEff));
}

//+-----------------------------------------------------------------+
//| A01.F0003 -- drawdown-budget factor: fades linearly from 1.0 (no|
//| drawdown) to 0.0 as currentDDPercent approaches ddBudgetCeiling,|
//| matching the precedent's own documented KellyDDBudget behaviour |
//| ("drawdown %% at which risk fades to ~0").                      |
//+-----------------------------------------------------------------+
double A01_DDBudgetFactor(double currentDDPercent, double ddBudgetCeiling) {
    if(ddBudgetCeiling <= 0.0) return 0.0;
    double frac = 1.0 - (MathMax(0.0, currentDDPercent) / ddBudgetCeiling);
    return MathMax(0.0, MathMin(1.0, frac));
}

//+-----------------------------------------------------------------------+
//| A01.F0005 -- PROMETHEUS 2.1 (added pass_6): the correlation-ESTIMATE   |
//| half of "correlation is always assumed >= measured." A01_EffectiveN    |
//| already clamps whatever rho it is GIVEN conservatively (n_eff<=N) --   |
//| but until this pass nothing inflated the MEASURED rho itself before it |
//| reached that formula, so an exact measurement carried no safety margin |
//| at all. A caller computes rho, then calls this BEFORE A01_EffectiveN,  |
//| same "compose upstream" discipline R03/A03 already establish for       |
//| confidence -- this is not a second n_eff formula, it is a safety       |
//| margin on one of the first formula's own inputs.                       |
//+-----------------------------------------------------------------------+
double A01_ConservativeCorrelation(double measuredRho, double marginOverride = A01_CORRELATION_SAFETY_MARGIN) {
    double m = MathMax(0.0, marginOverride);
    return MathMax(0.0, MathMin(1.0, measuredRho + m));
}

//+-----------------------------------------------------------------------+
//| A01.F0006 -- PROMETHEUS 2.3 (added pass_6): "crisis-correlation is the |
//| default assumption under stress." Before this pass, a caller with no   |
//| real correlation measurement yet had no honest default to fall back on |
//| -- silently passing rho=0.0 (MQL4's own double default) would be        |
//| exactly backwards, the LEAST conservative value precisely when there    |
//| is the least evidence to justify it. isRegimeKnown=false returns 1.0    |
//| unconditionally (every position moves as one until proven otherwise),   |
//| never a guessed intermediate value.                                     |
//+-----------------------------------------------------------------------+
double A01_CorrelationRegimeDefault(bool isRegimeKnown, double measuredRho) {
    if(!isRegimeKnown) return 1.0;
    return MathMax(0.0, MathMin(1.0, measuredRho));
}

//--- A01.K0005/K0006 -- PROMETHEUS 2.3 reach (pass_8): the boundaries between
//--- calm/transitional/crisis correlation regimes. Not fitted or tuned per-call;
//--- fixed, named thresholds, same posture as every other GENESIS knob.
#define A01_CORR_REGIME_CALM_THRESHOLD   0.30   // A01.K0005
#define A01_CORR_REGIME_CRISIS_THRESHOLD 0.70   // A01.K0006

enum A01_CorrelationRegime {
    A01_CORR_CALM,
    A01_CORR_TRANSITIONAL,
    A01_CORR_CRISIS
};

//+-----------------------------------------------------------------------+
//| A01.F0009 -- PROMETHEUS 2.3 reach (pass_8): "know that correlations    |
//| themselves change regime (calm vs crisis) and track which correlation- |
//| regime is active." Closes 2.3's remaining gap -- pass_6 only supplied  |
//| a crisis DEFAULT for an unknown reading (A01_CorrelationRegimeDefault);|
//| nothing actually classified a regime from real readings. Takes the     |
//| CALLER's own rolling window of measured rho readings (this organ never |
//| computes correlation itself -- that is 2.1's still-open reach, needing |
//| live cross-instrument data this environment cannot supply) and         |
//| classifies by the WINDOW MAXIMUM, never the average -- one crisis-level|
//| reading anywhere in the window must dominate the verdict, matching     |
//| "crisis-correlation is the default assumption under stress," not get   |
//| smoothed away by calmer neighbours. Zero readings (no evidence at all) |
//| is itself classified CRISIS, the same fail-safe posture as             |
//| A01_CorrelationRegimeDefault's isRegimeKnown=false case.                |
//+-----------------------------------------------------------------------+
A01_CorrelationRegime A01_ClassifyCorrelationRegime(const double &recentRho[], int n,
                                                     double crisisThreshold = A01_CORR_REGIME_CRISIS_THRESHOLD,
                                                     double calmThreshold   = A01_CORR_REGIME_CALM_THRESHOLD) {
    if(n <= 0) return A01_CORR_CRISIS;
    double maxRho = 0.0;
    for(int i = 0; i < n; i++) maxRho = MathMax(maxRho, MathMax(0.0, MathMin(1.0, recentRho[i])));
    if(maxRho >= crisisThreshold) return A01_CORR_CRISIS;
    if(maxRho <= calmThreshold)   return A01_CORR_CALM;
    return A01_CORR_TRANSITIONAL;
}

//+-----------------------------------------------------------------------+
//| A01.F0007 -- PROMETHEUS 5.4 (pass_7): cross-candidate risk allocator.  |
//| "Spend drawdown budget where conviction and edge-durability are        |
//| highest; starve the marginal." Takes N simultaneous candidates, each   |
//| with a confidence (already composed elsewhere, [0,1]) and a durability |
//| (a real lower-confidence-bound edge estimate, e.g. C01_Adjudication's  |
//| ciLow -- can be <=0 for a candidate that is not yet proven durable).   |
//| weight_i = max(0,confidence_i) * max(0,durability_i) -- a non-durable  |
//| candidate is weighted to EXACTLY zero, starved outright, never just    |
//| de-prioritised by a smaller-but-nonzero share. Weights normalise to    |
//| sum to totalBudgetPercent, but the dumb hard floor governs the smart   |
//| budget always: totalBudgetPercent is clamped to A01_HARD_FLOOR_PERCENT |
//| before any split happens, AND every individual allocation is clamped   |
//| again after the split -- two independent floor checks, not one.        |
//| If every candidate is non-durable (sumWeights==0), every allocation is |
//| zero -- never an even split as a fallback, which would silently arm    |
//| budget behind a candidate this organ itself just said isn't durable.   |
//+-----------------------------------------------------------------------+
void A01_AllocateBudget(const double &confidences[], const double &durabilities[], int n, double totalBudgetPercent, double &allocations[]) {
    ArrayResize(allocations, n);
    double budget = MathMax(0.0, MathMin(A01_HARD_FLOOR_PERCENT, totalBudgetPercent));

    double weights[];
    ArrayResize(weights, n);
    double sumWeights = 0.0;
    for(int i = 0; i < n; i++) {
        double w = MathMax(0.0, confidences[i]) * MathMax(0.0, durabilities[i]);
        weights[i] = w;
        sumWeights += w;
    }

    for(int i = 0; i < n; i++) {
        double share = (sumWeights > 1e-12) ? (weights[i] / sumWeights) * budget : 0.0;
        allocations[i] = MathMax(0.0, MathMin(A01_HARD_FLOOR_PERCENT, share));
    }
}

//+---------------------------------------------------------------------+
//| A01.F0004 -- the organ's one entry point. confidence appears in this|
//| expression EXACTLY ONCE, as a single multiplicative factor -- there |
//| is no second confidence-shaped parameter anywhere in this signature |
//| to accidentally stack (INV-12's structural guarantee: not policed by|
//| a later audit, made impossible by having only one place to put it). |
//| min(size,FLOOR) is applied as the LAST step, per the contract's own |
//| explicit ordering.                                                  |
//+---------------------------------------------------------------------+
double A01_ComposeSize(double edge, double varianceProxy, double confidence, double ddBudget, int rawN, double avgCorrelation,
                        double kappa = A01_KELLY_KAPPA_DEFAULT, double kellyCap = A01_KELLY_CAP_DEFAULT) {
    double kellySize   = A01_Kelly(edge, varianceProxy, kappa, kellyCap);
    double confClamped = MathMax(0.0, MathMin(1.0, confidence));
    double nEff         = A01_EffectiveN(rawN, avgCorrelation);
    double invNEff       = (nEff > 1e-9) ? (1.0 / nEff) : 0.0;

    double size = kellySize * confClamped * ddBudget * invNEff;
    return MathMax(0.0, MathMin(A01_HARD_FLOOR_PERCENT, size));
}

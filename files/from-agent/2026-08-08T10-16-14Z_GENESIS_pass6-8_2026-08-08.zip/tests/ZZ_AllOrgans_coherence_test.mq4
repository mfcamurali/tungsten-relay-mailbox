//+----------------------------------------------------------------------+
//| ZZ.T0001 -- whole-codebase coherence check                           |
//|                                                                      |
//| Includes every GENESIS organ built so far in ONE translation unit.   |
//| Each organ compiled clean in isolation (paired only with its own     |
//| dependencies) -- this is the only place all of them exist together in|
//| the same namespace at once, which is the only way to catch a symbol  |
//| collision (two organs accidentally defining the same function/macro/ |
//| struct name) that isolated per-organ compiles cannot see. Every stage|
//| routes its verdict through G03_LogVerdict (pass_5) rather than raw    |
//| Print, so this smoke run also doubles as a real demonstration of the |
//| elegant live-feed format every organ's own reason/narrative text now |
//| uses.                                                                 |
//+----------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\GENESIS_Constants.mqh"
#include "..\src\GENESIS_Types.mqh"
#include "..\src\Substrate\R01_SubstrateDiagnostic.mqh"
#include "..\src\Substrate\R02_SearchDispatcher.mqh"
#include "..\src\Substrate\R03_TimeAwareSizing.mqh"
#include "..\src\Substrate\R04_CuratedNeuralNet.mqh"
#include "..\src\Perception\P01_RegimeState.mqh"
#include "..\src\Perception\P02_FeatureBank.mqh"
#include "..\src\Perception\P03_CostModel.mqh"
#include "..\src\Cognition\C01_EdgeAdjudicator.mqh"
#include "..\src\Cognition\C02_OverfitImmune.mqh"
#include "..\src\Cognition\C03_EvidenceLedger.mqh"
#include "..\src\Cognition\C04_ChampionRegister.mqh"
#include "..\src\Action\A01_SizeEngine.mqh"
#include "..\src\Action\A02_OrderGate.mqh"
#include "..\src\Action\A03_GraduatedDeploy.mqh"
#include "..\src\Conscience\G01_ArmController.mqh"
#include "..\src\Conscience\G02_GateBus.mqh"
#include "..\src\Conscience\G03_Logger.mqh"
#include "..\src\Conscience\G04_SelfDiagnosis.mqh"

//+--------------------------------------------------------------------+
//| A minimal end-to-end smoke composition: wires every system's real  |
//| entry point into one flow (Substrate -> Perception -> Cognition -> |
//| Action, policed by Conscience) to prove the interfaces genuinely   |
//| compose, not just that each file compiles standalone. This is NOT a|
//| claim of a validated trading decision -- fixture data, not real    |
//| market data -- it proves the PLUMBING is coherent end to end.      |
//+--------------------------------------------------------------------+
void OnStart() {
    G03_LogVerdict("GENESIS.Coherence", "Whole-codebase coherence check starting \xB7 19 files, one translation unit");

    // SUBSTRATE: classify a synthetic time-varying series, dispatch a search method.
    R01_Series series; R01_ZeroSeries(series);
    double subMean[5] = { 0.3, -0.3, 0.3, -0.3, 0.3 };
    for(int w = 0; w < 5; w++) for(int i = 0; i < 40; i++) R01_Accumulate(series, subMean[w], w);
    R01_Verdict substrateVerdict = R01_Classify(series, 0.0);
    R02_SearchMethod method = R02_Dispatch(substrateVerdict);
    G03_LogVerdict("Substrate", StringFormat("%s substrate, %d sign flips \xB7 dispatched to %s search",
                    R01_ClassName(substrateVerdict.classOut), substrateVerdict.flips, R02_MethodName(method)));

    // PERCEPTION: a regime belief update and a cost-net edge.
    P01_BeliefVector prior = P01_UniformBelief();
    double lr[9] = {2,1,1,1,1,1,1,1,1};
    P01_Verdict regimeVerdict = P01_Classify(prior, lr, 0.85, true);
    P03_ResetBracketMap();
    string bErr; for(int r = 0; r < 9; r++) P03_SetBracket(r, 1.5, 2.5, bErr);
    P03_CostReport cost = P03_NetEdge(0.4, 10.0, 0.0001, 0.0020);
    G03_LogVerdict("Perception", StringFormat("Regime %d dominant, %.1f%% confidence \xB7 net edge %.4f ATR after cost",
                    regimeVerdict.dominant, regimeVerdict.confidence * 100.0, cost.edgeNet));

    // COGNITION: adjudicate a durable-looking multi-window edge, screen it for overfit.
    C01_WindowResult windows[5];
    windows[0].meanReturnATR = 0.35; windows[0].n = 40;
    windows[1].meanReturnATR = 0.30; windows[1].n = 45;
    windows[2].meanReturnATR = 0.40; windows[2].n = 38;
    windows[3].meanReturnATR = 0.32; windows[3].n = 42;
    windows[4].meanReturnATR = 0.38; windows[4].n = 41;
    C01_Adjudication adjudication = C01_Adjudicate(windows);
    C02_TrustResult trust = C02_Evaluate(3.0, false, 0.15);
    G03_LogVerdict("Cognition", StringFormat("%s \xB7 edge %.4f ATR \xB7 overfit trust %.2f (%s)",
                    (adjudication.verdict == C01_EDGE ? "Edge confirmed" : "No edge"), adjudication.edge, trust.trust,
                    (trust.rejected ? "rejected" : "accepted")));

    // COGNITION (C04 extension): promote a champion from the adjudication,
    // then prove the auto-revert path fires on an injected regression --
    // this is the plumbing proof for INV-17, which pass_2 named but did not
    // build a mechanism for.
    C04_RegisterState champState;
    champState.hasChampion = false; champState.hasBackup = false; champState.revertCount = 0;
    string champReason;
    C04_Champion firstChamp; firstChamp.configId = "smoke-gen1"; firstChamp.regime = 0;
    firstChamp.edge = adjudication.edge; firstChamp.ciLow = adjudication.ciLow; firstChamp.ciHigh = adjudication.ciHigh;
    firstChamp.windowsUsed = adjudication.windowsUsed; firstChamp.provenance = TimeCurrent(); firstChamp.generation = 0;
    bool promoted = C04_Promote(champState, firstChamp, champReason);
    // A second, durably-better challenger promotes over the first -- this is
    // what gives the register an actual backup to fall back to, matching the
    // real "every champion has a backup from the 2nd promotion onward" claim.
    C04_Champion secondChamp = firstChamp; secondChamp.configId = "smoke-gen2";
    secondChamp.ciLow = firstChamp.ciLow + 0.05; secondChamp.edge = firstChamp.edge + 0.05; secondChamp.ciHigh = firstChamp.ciHigh + 0.05;
    bool promoted2 = C04_Promote(champState, secondChamp, champReason);
    C04_Champion regressedLive = secondChamp; regressedLive.configId = "smoke-gen2-live";
    regressedLive.ciHigh = secondChamp.ciLow - 0.10; regressedLive.windowsUsed = secondChamp.windowsUsed;
    bool regressionFired = false; string revertReason = "";
    if(promoted && promoted2) {
        bool regressed = C04_DetectRegression(champState, regressedLive, champReason);
        if(regressed) { regressionFired = C04_AutoRevert(champState, revertReason); }
    }
    G03_LogVerdict("Cognition.ChampionRegister", StringFormat("%s \xB7 %s \xB7 %d revert%s so far",
                    (promoted ? "First champion promoted" : "No champion promoted"),
                    (regressionFired ? "regression detected and reverted" : "no regression detected"),
                    champState.revertCount, (champState.revertCount == 1 ? "" : "s")));

    // CONSCIENCE, on the cognition output: diagnose if NONE, gate the pipeline, log it.
    G04_Diagnosis diag = G04_Diagnose(adjudication, substrateVerdict);
    G02_Gate gates[2];
    gates[0].name = "overfit-immune"; gates[0].result = trust.rejected ? G02_GATE_BLOCK : G02_PASS;
    gates[1].name = "edge-adjudicator"; gates[1].result = (adjudication.verdict == C01_EDGE) ? G02_PASS : G02_GATE_BLOCK;
    G02_BusVerdict busVerdict = G02_Evaluate(gates);
    G03_LogVerdict("Conscience.GateBus", StringFormat("%s \xB7 %s", (busVerdict.allPass ? "All gates pass" : "Blocked \xB7 " + busVerdict.blockedBy), diag.narrative));

    // ACTION, only reached conceptually here (not gated by a real ArmController
    // decision in this smoke test -- that needs G01, exercised next).
    string armReason;
    G01_ArmVerdict armVerdict = G01_EvaluateArming(150, 62.0, adjudication.verdict == C01_EDGE, trust.rejected, armReason);

    // CONSCIENCE (GENESIS_Types/INV-03 extension): the same arming decision
    // via the structurally-honest rate type -- a real GENESIS_Rate computed
    // from actual counts must agree with the plain-double call above, and an
    // unknown rate must refuse regardless of how good oosTradeCount looks.
    GENESIS_Rate ghostRate = GENESIS_ComputeRate(93, 150);   // 62.0%, matches the plain call above exactly
    string rateArmReason;
    G01_ArmVerdict rateArmVerdict = G01_EvaluateArmingFromRate(150, ghostRate, adjudication.verdict == C01_EDGE, trust.rejected, rateArmReason);
    G01_ArmVerdict unknownRateVerdict = G01_EvaluateArmingFromRate(150, GENESIS_UnknownRate(), true, false, rateArmReason);
    G03_LogVerdict("Conscience.ArmController", StringFormat("%s \xB7 rate-typed entry point %s the plain entry point \xB7 an unknown rate correctly %s",
                    armReason, (rateArmVerdict == armVerdict ? "agrees with" : "DISAGREES with"),
                    (unknownRateVerdict == G01_REFUSE ? "refuses" : "FAILED TO REFUSE")));

    double deployFactor = A03_DeploymentFactor(150);
    double size = A01_ComposeSize(MathMax(0.0, cost.edgeNet), 0.01, regimeVerdict.confidence * deployFactor, 1.0, 1, 0.0);
    A02_GateDecision orderGate = A02_Gate(size);
    G03_LogVerdict("Action.SizeEngine", StringFormat("Deployment factor %.4f \xB7 composed size %.4f%% \xB7 %.4f%% approved after the hard floor",
                    deployFactor, size, orderGate.approvedRiskPercent));

    G03_LogVerdict("GENESIS.Coherence", "Coherent \xB7 Substrate through Conscience compose end to end with no symbol collisions (fixture data \xB7 not a validated trading result)");
}

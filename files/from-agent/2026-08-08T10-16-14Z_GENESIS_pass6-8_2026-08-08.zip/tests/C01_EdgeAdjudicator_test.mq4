//+---------------------------------------------------------------------+
//| C01.T0001 -- acceptance test for C01 EdgeAdjudicator                |
//| Contract under test (GENESIS_MASTER_SPEC.md O4):                    |
//|   "Overfit fixture -> NONE with cause; durable fixture -> EDGE      |
//|    surviving k windows; single-split call won't compile."           |
//|                                                                     |
//| Note on the "won't compile" clause: C01_Adjudicate has exactly one  |
//| signature (array of C01_WindowResult) -- there is no overload for a |
//| single split to accidentally call, so MQL4 cannot express a         |
//| single-split call to this organ AT ALL differently from a k=1 array |
//| call. What this test proves instead, honestly: a k=1 (or k=2) array,|
//| no matter how strong the apparent edge, can never produce an EDGE   |
//| verdict -- the single-split/underpowered case is structurally       |
//| refused by the gate, not merely discouraged.                        |
//+---------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Cognition\C01_EdgeAdjudicator.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  C01.T0001  ", name); }
    else     { g_fail++; Print("FAIL  C01.T0001  ", name, "  -- ", detail); }
}

C01_WindowResult MakeWindow(double meanR, int n) {
    C01_WindowResult w; w.meanReturnATR = meanR; w.n = n; return w;
}

//+---------------------------------------------------------------------+
//| "Overfit fixture -> NONE with cause": windows that look inconsistent|
//| OOS (some strongly positive, some strongly negative) -- exactly what|
//| a genuinely overfit strategy produces when actually walk-forward    |
//| tested (great on the window it was tuned near, poor elsewhere).     |
//+---------------------------------------------------------------------+
void Test_OverfitFixtureIsNone() {
    C01_WindowResult windows[];
    ArrayResize(windows, 5);
    windows[0] = MakeWindow( 0.80, 50);
    windows[1] = MakeWindow(-0.60, 50);
    windows[2] = MakeWindow( 0.30, 50);
    windows[3] = MakeWindow(-0.90, 50);
    windows[4] = MakeWindow( 0.10, 50);

    C01_Adjudication r = C01_Adjudicate(windows);
    Check("overfit (inconsistent-sign) fixture verdicts NONE",
          r.verdict == C01_NONE, StringFormat("got verdict=%d edge=%.4f", r.verdict, r.edge));
    Check("overfit fixture's NONE verdict carries a non-empty cause",
          StringLen(r.cause) > 0, "cause string was empty on a NONE verdict");
}

//+-----------------------------------------------------------------+
//| "durable fixture -> EDGE surviving k windows": every independent|
//| window positive, tight and consistent -- a real, durable edge.  |
//+-----------------------------------------------------------------+
void Test_DurableFixtureIsEdge() {
    C01_WindowResult windows[];
    ArrayResize(windows, 5);
    windows[0] = MakeWindow(0.35, 40);
    windows[1] = MakeWindow(0.30, 45);
    windows[2] = MakeWindow(0.40, 38);
    windows[3] = MakeWindow(0.32, 42);
    windows[4] = MakeWindow(0.38, 41);

    C01_Adjudication r = C01_Adjudicate(windows);
    Check("durable (consistently positive) fixture verdicts EDGE",
          r.verdict == C01_EDGE, StringFormat("got verdict=%d cause=%s", r.verdict, r.cause));
    Check("durable fixture's edge survived all 5 windows (windowsUsed==5)",
          r.windowsUsed == 5, StringFormat("windowsUsed=%d", r.windowsUsed));
    Check("durable fixture's CI excludes zero on the low side",
          r.ciLow > 0.0, StringFormat("ciLow=%.4f", r.ciLow));
}

//+----------------------------------------------------------------+
//| A single window that individually loses money among otherwise- |
//| positive windows must block EDGE -- "surviving k windows" means|
//| every one, not most.                                           |
//+----------------------------------------------------------------+
void Test_OneBadWindowBlocksEdge() {
    C01_WindowResult windows[];
    ArrayResize(windows, 5);
    windows[0] = MakeWindow(0.35, 40);
    windows[1] = MakeWindow(0.30, 45);
    windows[2] = MakeWindow(-0.05, 38);   // one non-positive window among four strong ones
    windows[3] = MakeWindow(0.32, 42);
    windows[4] = MakeWindow(0.38, 41);

    C01_Adjudication r = C01_Adjudicate(windows);
    Check("a single non-positive window among four positives still blocks EDGE",
          r.verdict == C01_NONE, StringFormat("got verdict=%d (expected NONE)", r.verdict));
    Check("the durability-failure cause mentions non-positive/durability, not just significance",
          StringFind(r.cause, "durable") >= 0, StringFormat("cause='%s'", r.cause));
}

//+--------------------------------------------------------------------+
//| "single-split call won't compile" (adapted, see file header): a k=1|
//| or k=2 array -- no matter how strong -- can never verdict EDGE,    |
//| because the organ's one entry point refuses to adjudicate below    |
//| C01_MIN_WINDOWS(3) regardless of content.                          |
//+--------------------------------------------------------------------+
void Test_SingleSplitNeverProducesEdge() {
    C01_WindowResult one[]; ArrayResize(one, 1); one[0] = MakeWindow(5.0, 1000);   // absurdly strong single split
    C01_Adjudication r1 = C01_Adjudicate(one);
    Check("a single-window (k=1) call, however strong, never verdicts EDGE",
          r1.verdict == C01_NONE, StringFormat("got verdict=%d on a single-split call", r1.verdict));
    Check("a single-window call's cause names insufficient windows",
          StringFind(r1.cause, "insufficient") >= 0, StringFormat("cause='%s'", r1.cause));

    C01_WindowResult two[]; ArrayResize(two, 2); two[0] = MakeWindow(5.0, 1000); two[1] = MakeWindow(5.0, 1000);
    C01_Adjudication r2 = C01_Adjudicate(two);
    Check("a two-window (k=2, still below C01_MIN_WINDOWS) call never verdicts EDGE",
          r2.verdict == C01_NONE, StringFormat("got verdict=%d on a below-floor call", r2.verdict));
}

void OnStart() {
    Print("=== C01.T0001 EdgeAdjudicator acceptance test -- start ===");
    Test_OverfitFixtureIsNone();
    Test_DurableFixtureIsEdge();
    Test_OneBadWindowBlocksEdge();
    Test_SingleSplitNeverProducesEdge();
    PrintFormat("=== C01.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("C01.T0001 GREEN -- O4 EdgeAdjudicator meets its acceptance contract.");
    else            Print("C01.T0001 RED -- see FAIL lines above.");
}

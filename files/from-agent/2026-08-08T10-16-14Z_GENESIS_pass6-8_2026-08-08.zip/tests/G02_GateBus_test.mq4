//+----------------------------------------------------------------------+
//| G02.T0001 -- acceptance test for G02 GateBus                         |
//| Contract under test (GENESIS_MASTER_SPEC.md O11):                    |
//|   "Injected BLOCK halts; search for override path returns nothing;   |
//|    incomplete gate treated as BLOCK."                                |
//|                                                                      |
//| The "search for override path returns nothing" clause is verified    |
//| OUTSIDE this compiled test, the same way as A02_OrderGate's broker-  |
//| call audit: a real grep of G02_GateBus.mqh confirms every occurrence |
//| of override/force/proceed/skip/bypass is inside a comment describing |
//| the absence of such a mechanism, never in actual code (function name,|
//| parameter, or flag) -- recorded in GENESIS_LEDGER.json's G02 entry.  |
//+----------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Conscience\G02_GateBus.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  G02.T0001  ", name); }
    else     { g_fail++; Print("FAIL  G02.T0001  ", name, "  -- ", detail); }
}

//+---------------------------------------------------------------------+
//| "Injected BLOCK halts": a single BLOCK among otherwise-passing gates|
//| must halt the whole bus.                                            |
//+---------------------------------------------------------------------+
void Test_InjectedBlockHalts() {
    G02_Gate gates[4];
    gates[0].name = "cost-gate";       gates[0].result = G02_PASS;
    gates[1].name = "sample-gate";     gates[1].result = G02_PASS;
    gates[2].name = "overfit-gate";    gates[2].result = G02_GATE_BLOCK;   // injected block
    gates[3].name = "arm-gate";        gates[3].result = G02_PASS;

    G02_BusVerdict v = G02_Evaluate(gates);
    Check("a single injected BLOCK among 3 passing gates halts the whole bus (allPass=false)",
          !v.allPass, StringFormat("allPass=%s", v.allPass ? "true":"false"));
    Check("the halting verdict names the specific gate that blocked",
          StringFind(v.blockedBy, "overfit-gate") >= 0, StringFormat("blockedBy='%s'", v.blockedBy));
}

//+------------------------------------------------------------------+
//| "incomplete gate treated as BLOCK": INCOMPLETE halts exactly like|
//| BLOCK -- the Pre-Flight bug this organ exists to make impossible.|
//+------------------------------------------------------------------+
void Test_IncompleteTreatedAsBlock() {
    G02_Gate gates[3];
    gates[0].name = "cost-gate";    gates[0].result = G02_PASS;
    gates[1].name = "sample-gate";  gates[1].result = G02_PASS;
    gates[2].name = "power-gate";   gates[2].result = G02_INCOMPLETE;   // the exact Pre-Flight bug shape

    G02_BusVerdict v = G02_Evaluate(gates);
    Check("a single INCOMPLETE gate halts the bus exactly like a BLOCK would (no softer outcome)",
          !v.allPass, StringFormat("allPass=%s", v.allPass ? "true":"false"));
    Check("the halting verdict tags the incomplete gate as (incomplete), distinguishable but still halting",
          StringFind(v.blockedBy, "incomplete") >= 0, StringFormat("blockedBy='%s'", v.blockedBy));
}

//+-----------------------------------+
//| All gates PASS -> the bus permits.|
//+-----------------------------------+
void Test_AllPassPermits() {
    G02_Gate gates[3];
    gates[0].name = "cost-gate";    gates[0].result = G02_PASS;
    gates[1].name = "sample-gate";  gates[1].result = G02_PASS;
    gates[2].name = "power-gate";   gates[2].result = G02_PASS;

    G02_BusVerdict v = G02_Evaluate(gates);
    Check("all gates PASS -> bus verdict is allPass=true",
          v.allPass, StringFormat("allPass=%s blockedBy='%s'", v.allPass?"true":"false", v.blockedBy));
    Check("an all-pass verdict has an empty blockedBy string",
          StringLen(v.blockedBy) == 0, StringFormat("blockedBy='%s'", v.blockedBy));
}

//+----------------------------------------------------------------------+
//| An empty gate list is never vacuously treated as "everything passed."|
//+----------------------------------------------------------------------+
void Test_EmptyGateListIsNotVacuousPass() {
    G02_Gate empty[]; ArrayResize(empty, 0);
    Check("an empty gate array is correctly detected as having no registered gates",
          !G02_HasAnyGates(empty), "G02_HasAnyGates incorrectly reported true for an empty array");
}

void OnStart() {
    Print("=== G02.T0001 GateBus acceptance test -- start ===");
    Test_InjectedBlockHalts();
    Test_IncompleteTreatedAsBlock();
    Test_AllPassPermits();
    Test_EmptyGateListIsNotVacuousPass();
    PrintFormat("=== G02.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("G02.T0001 GREEN -- O11 GateBus meets its acceptance contract.");
    else            Print("G02.T0001 RED -- see FAIL lines above.");
}

//+----------------------------------------------------------------------+
//| R01.T0001 -- acceptance test for R01 SubstrateDiagnostic             |
//| GENESIS test-first protocol (GENESIS_MASTER_SPEC.md sec.5)           |
//|                                                                      |
//| Contract under test (GENESIS_MASTER_SPEC.md O14):                    |
//|   "Sign-flip fixture -> TIME-VARYING; stable -> STATIONARY;          |
//|    sparse -> UNKNOWN; feeds dispatch."                               |
//| Also proves INV-18: an UNKNOWN verdict's t-stat is never a fabricated|
//| 0.0 -- it must be EMPTY_VALUE, distinguishable from a genuinely      |
//| measured zero.                                                       |
//|                                                                      |
//| This is a read-only diagnostic script -- no order, no broker call, no|
//| chart/state modification. Compiling it (0 errors) is the automated   |
//| proof available from this shell without a live MT4 terminal; actually|
//| RUNNING it (attaching to a chart so OnStart() executes and prints its|
//| PASS/FAIL lines) needs Manuel's explicit consent to touch MetaTrader,|
//| same standing rule as every TUNGSTEN live-run request -- see         |
//| genesis-phoenix skill's "honest constraint" section.                 |
//+----------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Substrate\R01_SubstrateDiagnostic.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  R01.T0001  ", name); }
    else     { g_fail++; Print("FAIL  R01.T0001  ", name, "  -- ", detail); }
}

//+--------------------------------------------------------------------+
//| Fixture 1: sign-flip -- 5 sub-windows alternating clearly positive/|
//| negative means (well outside the dead-zone), each with n well above|
//| the power floor. Must classify TIME_VARYING with flips>=1.         |
//+--------------------------------------------------------------------+
void Test_SignFlipFixture() {
    R01_Series s; R01_ZeroSeries(s);
    double subMean[R01_SUBWINDOWS] = { 0.30, -0.30, 0.30, -0.30, 0.30 };   // alternating, far outside +-0.02 dead-zone
    for(int w = 0; w < R01_SUBWINDOWS; w++)
        for(int i = 0; i < 40; i++)                                        // 40 > R01_MIN_N_PER_SUBWINDOW(30)
            R01_Accumulate(s, subMean[w], w);

    R01_Verdict v = R01_Classify(s, 0.0);
    Check("sign-flip fixture classifies TIME_VARYING",
          v.classOut == R01_TIME_VARYING,
          StringFormat("got %s", R01_ClassName(v.classOut)));
    Check("sign-flip fixture reports flips>=1",
          v.flips >= 1,
          StringFormat("got flips=%d", v.flips));
    Check("sign-flip fixture reports a real (non-EMPTY_VALUE) t-stat",
          v.tstat != EMPTY_VALUE,
          "t-stat unexpectedly not computed on a fully-powered series");
}

//+---------------------------------------------------------------------+
//| Fixture 2: stable -- 5 sub-windows all the same sign, tight, low    |
//| variance, no dead-zone crossing. Must classify STATIONARY, flips==0.|
//+---------------------------------------------------------------------+
// A perfectly constant series has zero variance by construction, which
// makes |t| degenerate (undefined/infinite) rather than a meaningful small
// number -- so the stable fixture uses small, bounded per-observation noise
// instead of a flat constant, so the variance is real and the fixture is
// honest about what STATIONARY vs a zero-variance edge case actually means.
void Test_StableFixtureWithNoise() {
    R01_Series s; R01_ZeroSeries(s);
    // Deterministic pseudo-noise (no MathRand dependency, so the fixture is
    // reproducible run to run): a small oscillation around a constant
    // positive mean, amplitude far below the level that would flip sign.
    double noise[8] = { 0.01, -0.01, 0.02, -0.02, 0.015, -0.015, 0.005, -0.005 };
    for(int w = 0; w < R01_SUBWINDOWS; w++)
        for(int i = 0; i < 40; i++)
            R01_Accumulate(s, 0.10 + noise[i % 8], w);

    R01_Verdict v = R01_Classify(s, 0.0);
    Check("stable fixture classifies STATIONARY",
          v.classOut == R01_STATIONARY,
          StringFormat("got %s (flips=%d, t=%.3f)", R01_ClassName(v.classOut), v.flips, v.tstat));
    Check("stable fixture reports zero flips",
          v.flips == 0,
          StringFormat("got flips=%d", v.flips));
}

//+--------------------------------------------------------------+
//| Fixture 3: sparse -- far below the power floor. Must classify|
//| UNKNOWN, and its t-stat must be EMPTY_VALUE (INV-18: never a |
//| fabricated 0.0 standing in for "not measured").              |
//+--------------------------------------------------------------+
void Test_SparseFixture() {
    R01_Series s; R01_ZeroSeries(s);
    for(int i = 0; i < 5; i++)          // 5 << R01_MIN_N_PER_SUBWINDOW(30)
        R01_Accumulate(s, 0.30, 0);

    R01_Verdict v = R01_Classify(s, 0.0);
    Check("sparse fixture classifies UNKNOWN",
          v.classOut == R01_UNKNOWN,
          StringFormat("got %s", R01_ClassName(v.classOut)));
    Check("sparse fixture's t-stat is EMPTY_VALUE, not a fabricated 0.0 (INV-18)",
          v.tstat == EMPTY_VALUE,
          StringFormat("got t=%.6f", v.tstat));
}

//+-------------------------------------------------------------------+
//| "Feeds dispatch": the verdict type itself must be sufficient for a|
//| consumer (O15 SearchDispatcher) to make a total, deterministic    |
//| decision with no third state left unhandled.                      |
//+-------------------------------------------------------------------+
void Test_FeedsDispatch() {
    R01_SubstrateClass all[3] = { R01_UNKNOWN, R01_STATIONARY, R01_TIME_VARYING };
    bool allNamed = true;
    for(int i = 0; i < 3; i++) if(R01_ClassName(all[i]) == "UNKNOWN" && all[i] != R01_UNKNOWN) allNamed = false;
    Check("every R01_SubstrateClass value has a distinct, resolvable name",
          allNamed, "a class value fell through to the UNKNOWN default name incorrectly");
}

//+-----------------------------------------------------------------------+
//| PROMETHEUS 3.5 (pass_6): flip-probability turns the sign-flip fixture's|
//| raw count into a real [0,1] estimate, and composes into confidence     |
//| exactly once (never a second multiplier alongside it, INV-12).         |
//+-----------------------------------------------------------------------+
void Test_FlipProbabilityOnAlternatingFixture() {
    R01_Series s; R01_ZeroSeries(s);
    double subMean[R01_SUBWINDOWS] = { 0.30, -0.30, 0.30, -0.30, 0.30 };   // 5 powered sub-windows, 4 transitions, all flip
    for(int w = 0; w < R01_SUBWINDOWS; w++) for(int i = 0; i < 40; i++) R01_Accumulate(s, subMean[w], w);

    double fp = R01_FlipProbability(s);
    Check("an alternating-sign fixture (every transition flips) reports flip-probability 1.0",
          MathAbs(fp - 1.0) < 1e-9, StringFormat("got %.4f", fp));
}

void Test_FlipProbabilityOnStableFixture() {
    R01_Series s; R01_ZeroSeries(s);
    for(int w = 0; w < R01_SUBWINDOWS; w++) for(int i = 0; i < 40; i++) R01_Accumulate(s, 0.10, w);   // never flips

    double fp = R01_FlipProbability(s);
    Check("a stable (never-flipping) fixture reports flip-probability 0.0",
          MathAbs(fp - 0.0) < 1e-9, StringFormat("got %.4f", fp));
}

void Test_FlipProbabilityOnSparseFixtureIsZeroNotFabricated() {
    R01_Series s; R01_ZeroSeries(s);
    for(int i = 0; i < 5; i++) R01_Accumulate(s, 0.30, 0);   // far below the power floor, only 1 sub-window has any data

    double fp = R01_FlipProbability(s);
    Check("fewer than 2 powered sub-windows (no transition is even measurable) reports 0.0, not a crash or a fabricated value",
          MathAbs(fp - 0.0) < 1e-9, StringFormat("got %.4f", fp));
}

void Test_FlipDiscountComposesIntoConfidenceOnce() {
    double noDiscount = R01_ApplyFlipDiscount(0.80, 0.0);
    Check("zero flip-probability leaves confidence untouched",
          MathAbs(noDiscount - 0.80) < 1e-9, StringFormat("got %.4f", noDiscount));

    double fullDiscount = R01_ApplyFlipDiscount(0.80, 1.0);
    Check("flip-probability 1.0 discounts confidence to zero (a maximally unstable series is never trusted)",
          MathAbs(fullDiscount - 0.0) < 1e-9, StringFormat("got %.4f", fullDiscount));

    double halfDiscount = R01_ApplyFlipDiscount(0.80, 0.5);
    Check("flip-probability applies as a single multiplicative discount, not a second confidence factor stacked elsewhere",
          MathAbs(halfDiscount - 0.40) < 1e-9, StringFormat("got %.4f", halfDiscount));
}

void OnStart() {
    Print("=== R01.T0001 SubstrateDiagnostic acceptance test -- start ===");
    Test_SignFlipFixture();
    Test_StableFixtureWithNoise();
    Test_SparseFixture();
    Test_FeedsDispatch();
    Test_FlipProbabilityOnAlternatingFixture();
    Test_FlipProbabilityOnStableFixture();
    Test_FlipProbabilityOnSparseFixtureIsZeroNotFabricated();
    Test_FlipDiscountComposesIntoConfidenceOnce();
    PrintFormat("=== R01.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("R01.T0001 GREEN -- O14 SubstrateDiagnostic meets its acceptance contract.");
    else            Print("R01.T0001 RED -- see FAIL lines above.");
}

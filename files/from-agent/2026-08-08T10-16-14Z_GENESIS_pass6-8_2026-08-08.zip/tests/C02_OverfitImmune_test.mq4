//+----------------------------------------------------------------------+
//| C02.T0001 -- acceptance test for C02 OverfitImmune                   |
//| Contract under test (GENESIS_MASTER_SPEC.md O5):                     |
//|   "PBO>0.5 or gap>8pp or resample-divergent -> trust<tau -> rejected;|
//|    healthy candidate passes all three."                              |
//| Read-only diagnostic script, same posture as prior GENESIS tests.    |
//+----------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Cognition\C02_OverfitImmune.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  C02.T0001  ", name); }
    else     { g_fail++; Print("FAIL  C02.T0001  ", name, "  -- ", detail); }
}

void Test_PBOAloneTriggersRejection() {
    C02_TrustResult r = C02_Evaluate(2.0, false, 0.60);   // gap fine, resample fine, PBO>0.5
    Check("PBO=0.60 alone (gap/resample healthy) drops trust below tau",
          r.trust < C02_TRUST_THRESHOLD, StringFormat("trust=%.3f", r.trust));
    Check("PBO=0.60 alone is rejected",
          r.rejected, "not rejected despite PBO>0.5");
    Check("rejection reason names PBO specifically",
          StringFind(r.reason, "PBO") >= 0, StringFormat("reason='%s'", r.reason));
}

void Test_GapAloneTriggersRejection() {
    C02_TrustResult r = C02_Evaluate(12.0, false, 0.10);   // gap>8pp, resample fine, PBO healthy
    Check("gap=12pp alone (resample/PBO healthy) drops trust below tau",
          r.trust < C02_TRUST_THRESHOLD, StringFormat("trust=%.3f", r.trust));
    Check("gap=12pp alone is rejected",
          r.rejected, "not rejected despite gap>8pp");
    Check("rejection reason names WF-gap specifically",
          StringFind(r.reason, "WF-gap") >= 0, StringFormat("reason='%s'", r.reason));
}

void Test_ResampleAloneTriggersRejection() {
    C02_TrustResult r = C02_Evaluate(2.0, true, 0.10);   // gap fine, PBO healthy, resample divergent
    Check("resample-divergent alone (gap/PBO healthy) drops trust below tau",
          r.trust < C02_TRUST_THRESHOLD, StringFormat("trust=%.3f", r.trust));
    Check("resample-divergent alone is rejected",
          r.rejected, "not rejected despite resample divergence");
    Check("rejection reason names resample specifically",
          StringFind(r.reason, "resample") >= 0, StringFormat("reason='%s'", r.reason));
}

//+---------------------------------------------------------------------+
//| Two healthy guards must never dilute one failing guard -- proves the|
//| MIN composition, not an average that could let 2-of-3 good scores   |
//| paper over the third.                                               |
//+---------------------------------------------------------------------+
void Test_MinCompositionNotAverage() {
    // If this were an average: (0.0 + 1.0 + 1.0)/3 = 0.667 >= tau(0.5) -- WOULD wrongly pass.
    // Under MIN: min(0.0, 1.0, 1.0) = 0.0 < tau -- correctly rejected.
    C02_TrustResult r = C02_Evaluate(20.0, false, 0.05);   // gap badly fails, other two are excellent
    Check("one badly-failing guard is not diluted by two excellent guards (MIN, not average)",
          r.rejected && r.trust < 0.01, StringFormat("trust=%.3f rejected=%s", r.trust, r.rejected ? "true":"false"));
}

void Test_HealthyCandidatePassesAllThree() {
    C02_TrustResult r = C02_Evaluate(3.0, false, 0.15);   // gap within ceiling, resample agrees, PBO low
    Check("healthy candidate (gap<=8pp, resample agrees, PBO<0.5) is NOT rejected",
          !r.rejected, StringFormat("trust=%.3f reason='%s'", r.trust, r.reason));
    Check("healthy candidate's trust equals the weakest of its three sub-scores",
          MathAbs(r.trust - MathMin(r.trustFromGap, MathMin(r.trustFromResample, r.trustFromPBO))) < 1e-12,
          "trust did not equal min(subscores)");
    Check("healthy candidate's trust is in [0,1]",
          r.trust >= 0.0 && r.trust <= 1.0, StringFormat("trust=%.3f", r.trust));
}

void OnStart() {
    Print("=== C02.T0001 OverfitImmune acceptance test -- start ===");
    Test_PBOAloneTriggersRejection();
    Test_GapAloneTriggersRejection();
    Test_ResampleAloneTriggersRejection();
    Test_MinCompositionNotAverage();
    Test_HealthyCandidatePassesAllThree();
    PrintFormat("=== C02.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("C02.T0001 GREEN -- O5 OverfitImmune meets its acceptance contract.");
    else            Print("C02.T0001 RED -- see FAIL lines above.");
}

//+-------------------------------------------------------------------+
//| G01.T0001 -- acceptance test for G01 ArmController                |
//| Contract under test (GENESIS_MASTER_SPEC.md O10):                 |
//|   "arm(n<30)->refuse; arm(WF-fragile)->block; arm(n>=30,durable)->|
//|    permit."                                                       |
//| Read-only diagnostic script, same posture as prior GENESIS tests. |
//+-------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Conscience\G01_ArmController.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  G01.T0001  ", name); }
    else     { g_fail++; Print("FAIL  G01.T0001  ", name, "  -- ", detail); }
}

//+------------------------------------------------------------------+
//| "arm(n<30)->refuse": exactly reproduces this project's own real  |
//| incident -- a single OOS trade at a fake 100% WR must REFUSE, not|
//| permit, however good the number looks.                           |
//+------------------------------------------------------------------+
void Test_LowNAlwaysRefuses() {
    string reason;
    G01_ArmVerdict v = G01_EvaluateArming(1, 100.0, true, false, reason);   // the real incident: n=1, WR=100%, durable=true, not fragile
    Check("n=1 at a 'perfect' 100% WR still REFUSES (reproduces the real historical incident correctly)",
          v == G01_REFUSE, StringFormat("got verdict=%d reason='%s'", v, reason));

    G01_ArmVerdict v2 = G01_EvaluateArming(29, 90.0, true, false, reason);
    Check("n=29 (one below the floor) still REFUSES",
          v2 == G01_REFUSE, StringFormat("got verdict=%d", v2));

    Check("REFUSE reason explicitly names the sample size / UNKNOWN WR, not a fabricated pass/fail on the WR itself",
          StringFind(reason, "UNKNOWN") >= 0 || StringFind(reason, "REFUSE") >= 0, StringFormat("reason='%s'", reason));
}

//+-----------------------------------------------------------------------+
//| "arm(WF-fragile)->block": sufficient n, durable, but fragile -> BLOCK,|
//| not REFUSE (a different verdict for a different failure class) and    |
//| not PERMIT.                                                           |
//+-----------------------------------------------------------------------+
void Test_WFFragileBlocks() {
    string reason;
    G01_ArmVerdict v = G01_EvaluateArming(100, 60.0, true, true, reason);   // n>=30, durable, but WF-fragile
    Check("sufficient n + durable but WF-fragile -> BLOCK (not REFUSE, not PERMIT)",
          v == G01_BLOCK, StringFormat("got verdict=%d reason='%s'", v, reason));
}

//+-------------------------------------------------------------------+
//| Not-durable (even with sufficient n and non-fragile WF) must also |
//| BLOCK -- all three conditions are required, not just two of three.|
//+-------------------------------------------------------------------+
void Test_NotDurableBlocks() {
    string reason;
    G01_ArmVerdict v = G01_EvaluateArming(100, 60.0, false, false, reason);
    Check("sufficient n + not WF-fragile but NOT durable -> BLOCK",
          v == G01_BLOCK, StringFormat("got verdict=%d", v));
}

//+----------------------------------------------------------+
//| "arm(n>=30,durable)->permit": the genuinely healthy case.|
//+----------------------------------------------------------+
void Test_HealthyCasePermits() {
    string reason;
    G01_ArmVerdict v = G01_EvaluateArming(150, 62.0, true, false, reason);
    Check("n=150, durable, not WF-fragile -> PERMIT",
          v == G01_PERMIT, StringFormat("got verdict=%d reason='%s'", v, reason));
    Check("PERMIT reason includes the real n and ghostWR values, not a bare verdict with no evidence attached",
          StringFind(reason, "150") >= 0, StringFormat("reason='%s'", reason));
}

//+--------------------------------------------------------------------+
//| Order of checks: n<30 must refuse EVEN IF wfFragile is also true --|
//| the power floor is checked first, unconditionally.                 |
//+--------------------------------------------------------------------+
void Test_LowNRefusesEvenIfAlsoFragile() {
    string reason;
    G01_ArmVerdict v = G01_EvaluateArming(5, 50.0, false, true, reason);   // fails every condition at once
    Check("n<30 refuses even when WF-fragile AND not durable are also true (power floor checked first)",
          v == G01_REFUSE, StringFormat("got verdict=%d", v));
}

//+-----------------------------------------------------------------------+
//| G01_EvaluateArmingFromRate (INV-03, pass_3): an UNKNOWN GENESIS_Rate   |
//| (n=0, never measured) REFUSES immediately, before oosTradeCount is    |
//| even consulted -- distinct from, but the same outcome as, the plain   |
//| n<30 REFUSE path.                                                     |
//+-----------------------------------------------------------------------+
void Test_UnknownRateAlwaysRefuses() {
    string reason;
    GENESIS_Rate unknown = GENESIS_UnknownRate();
    // Deliberately pass a HIGH oosTradeCount -- proves the refusal comes
    // from the rate being unknown, not from a coincidental low-n refusal.
    G01_ArmVerdict v = G01_EvaluateArmingFromRate(150, unknown, true, false, reason);
    Check("an UNKNOWN GENESIS_Rate REFUSES even with n=150 -- evidence-less WR is never evaluated",
          v == G01_REFUSE, StringFormat("got verdict=%d reason='%s'", v, reason));
    Check("UNKNOWN-rate refusal reason names the rate, not the sample size",
          StringFind(reason, "UNKNOWN") >= 0, StringFormat("reason='%s'", reason));
}

//+-----------------------------------------------------------------------+
//| A real, properly-constructed GENESIS_Rate (via GENESIS_ComputeRate,   |
//| n divided honestly) reproduces F0001's exact healthy-case behaviour   |
//| -- the rate-based entry point is a structural guarantee ON TOP OF     |
//| F0001's logic, not a different decision path.                        |
//+-----------------------------------------------------------------------+
void Test_KnownRateMatchesPlainEntryPoint() {
    string reasonA, reasonB;
    GENESIS_Rate rate = GENESIS_ComputeRate(93, 150);   // 62.0% WR, n=150, properly divided
    G01_ArmVerdict vRate  = G01_EvaluateArmingFromRate(150, rate, true, false, reasonA);
    G01_ArmVerdict vPlain = G01_EvaluateArming(150, rate.value, true, false, reasonB);
    Check("rate-based entry point agrees with the plain entry point given an equivalent known rate",
          vRate == vPlain && vRate == G01_PERMIT, StringFormat("rate-verdict=%d plain-verdict=%d", vRate, vPlain));
}

void OnStart() {
    Print("=== G01.T0001 ArmController acceptance test -- start ===");
    Test_LowNAlwaysRefuses();
    Test_WFFragileBlocks();
    Test_NotDurableBlocks();
    Test_HealthyCasePermits();
    Test_LowNRefusesEvenIfAlsoFragile();
    Test_UnknownRateAlwaysRefuses();
    Test_KnownRateMatchesPlainEntryPoint();
    PrintFormat("=== G01.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("G01.T0001 GREEN -- O10 ArmController meets its acceptance contract.");
    else            Print("G01.T0001 RED -- see FAIL lines above.");
}

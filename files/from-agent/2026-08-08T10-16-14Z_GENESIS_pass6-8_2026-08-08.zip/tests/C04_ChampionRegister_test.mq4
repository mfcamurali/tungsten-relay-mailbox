//+----------------------------------------------------------------------+
//| C04.T0001 -- acceptance test for C04 ChampionRegister                |
//| Contract under test (this organ closes INV-17, ledger honest gap):   |
//|   "A new champion that underperforms the prior proven one auto-      |
//|    reverts; every champion has a backup." REGRESSION-INJECT test:    |
//|   inject regression -> system reverts to prior champion; backup      |
//|   always exists once a second promotion has happened.                |
//|                                                                      |
//| Persistence sub-tests perform real file I/O (MQL4/Files/             |
//| genesis_c04_test.dat) -- same standing rule as C03's test: compiling |
//| proves syntactic correctness only; Manuel's consent is still needed  |
//| to attach and actually run this script in MT4 for a live PASS/FAIL.  |
//+----------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Cognition\C04_ChampionRegister.mqh"

int g_pass = 0, g_fail = 0;
string g_TestFile = "genesis_c04_test.dat";

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  C04.T0001  ", name); }
    else     { g_fail++; Print("FAIL  C04.T0001  ", name, "  -- ", detail); }
}

C04_Champion MakeChampion(string configId, int regime, double edge, double ciLow, double ciHigh, int windows) {
    C04_Champion c;
    c.configId = configId; c.regime = regime; c.edge = edge; c.ciLow = ciLow; c.ciHigh = ciHigh;
    c.windowsUsed = windows; c.provenance = TimeCurrent(); c.generation = 0;
    return c;
}

C04_RegisterState EmptyState() {
    C04_RegisterState s;
    s.hasChampion = false; s.hasBackup = false; s.revertCount = 0;
    return s;
}

//+-------------------------------------------------------------------+
//| Bootstrap: insufficient evidence never promotes, even as the first|
//| challenger ever seen -- no "first thing measured auto-wins".      |
//+-------------------------------------------------------------------+
void Test_BootstrapInsufficientEvidenceRejects() {
    C04_RegisterState state = EmptyState();
    C04_Champion weak = MakeChampion("cfgA", 3, 0.10, 0.02, 0.18, 2);   // only 2 windows, C01_MIN_WINDOWS=3
    string reason;
    C04_PromoteVerdict v = C04_ShouldPromote(state, weak, reason);
    Check("bootstrap challenger with <C01_MIN_WINDOWS windows is REJECT_INSUFFICIENT",
          v == C04_REJECT_INSUFFICIENT, StringFormat("verdict=%d reason=%s", v, reason));
}

void Test_BootstrapNotSignificantRejects() {
    C04_RegisterState state = EmptyState();
    C04_Champion notSig = MakeChampion("cfgB", 3, 0.05, -0.02, 0.12, 5);   // enough windows, ciLow<=0
    string reason;
    C04_PromoteVerdict v = C04_ShouldPromote(state, notSig, reason);
    Check("bootstrap challenger with ciLow<=0 is REJECT_NOT_BETTER (no auto-win for being first)",
          v == C04_REJECT_NOT_BETTER, StringFormat("verdict=%d reason=%s", v, reason));
}

void Test_BootstrapPromotes() {
    C04_RegisterState state = EmptyState();
    C04_Champion good = MakeChampion("cfgC", 3, 0.25, 0.10, 0.40, 5);
    string reason;
    bool promoted = C04_Promote(state, good, reason);
    Check("bootstrap challenger clearing durability+significance promotes", promoted, reason);
    Check("after bootstrap promotion, hasChampion=true", state.hasChampion, "hasChampion still false");
    Check("after bootstrap promotion, hasBackup=false (nothing to demote yet)", !state.hasBackup, "hasBackup unexpectedly true");
    Check("promoted champion's configId matches", state.current.configId == "cfgC", state.current.configId);
    Check("first-ever champion is generation 1", state.current.generation == 1, StringFormat("generation=%d", state.current.generation));
}

//+-------------------------------------------------------------------+
//| Second promotion: a durably-better challenger displaces the       |
//| champion and the OLD champion becomes the backup -- this is the   |
//| literal mechanism proving "every champion has a backup" from the  |
//| second promotion onward.                                          |
//+-------------------------------------------------------------------+
void Test_SecondPromotionCreatesBackup() {
    C04_RegisterState state = EmptyState();
    string reason;
    C04_Promote(state, MakeChampion("cfgD", 1, 0.20, 0.08, 0.32, 5), reason);

    C04_Champion better = MakeChampion("cfgE", 1, 0.30, 0.15, 0.45, 6);   // ciLow 0.15 > champion ciLow 0.08
    bool promoted = C04_Promote(state, better, reason);
    Check("durably-better challenger promotes", promoted, reason);
    Check("new champion is cfgE", state.current.configId == "cfgE", state.current.configId);
    Check("backup now exists and is the old champion cfgD", state.hasBackup && state.backup.configId == "cfgD",
          StringFormat("hasBackup=%s backup.configId=%s", state.hasBackup ? "true":"false", state.backup.configId));
    Check("new champion is generation 2", state.current.generation == 2, StringFormat("generation=%d", state.current.generation));
}

void Test_NotDurablyBetterRejectsAndLeavesStateUnchanged() {
    C04_RegisterState state = EmptyState();
    string reason;
    C04_Promote(state, MakeChampion("cfgF", 2, 0.20, 0.10, 0.30, 5), reason);

    C04_Champion notBetter = MakeChampion("cfgG", 2, 0.22, 0.05, 0.40, 5);   // higher point estimate, LOWER ciLow -- must not promote
    bool promoted = C04_Promote(state, notBetter, reason);
    Check("challenger with higher edge but lower ciLow is rejected (worst-case comparison, not point-estimate)",
          !promoted, reason);
    Check("champion unchanged after a rejected challenger", state.current.configId == "cfgF", state.current.configId);
    Check("no backup created from a rejected challenge", !state.hasBackup, "hasBackup unexpectedly true after a rejection");
}

//+-------------------------------------------------------------------+
//| Regression detection + auto-revert -- the decisive INV-17 test:   |
//| inject regression -> system reverts to prior champion.            |
//+-------------------------------------------------------------------+
void Test_RegressionDetectedAndAutoReverts() {
    C04_RegisterState state = EmptyState();
    string reason;
    C04_Promote(state, MakeChampion("cfgH_old", 4, 0.15, 0.05, 0.25, 5), reason);
    C04_Promote(state, MakeChampion("cfgI_new", 4, 0.28, 0.18, 0.38, 6), reason);   // now current, cfgH_old is backup

    C04_Champion liveObserved = MakeChampion("cfgI_new_live", 4, -0.10, -0.20, -0.02, 8);   // clearly worse, ciHigh < champion's promotion ciLow
    bool regressed = C04_DetectRegression(state, liveObserved, reason);
    Check("live performance well below promotion-time ciLow is flagged as regression", regressed, reason);

    bool reverted = C04_AutoRevert(state, reason);
    Check("auto-revert succeeds when a backup exists", reverted, reason);
    Check("reverted champion is the prior proven cfgH_old", state.current.configId == "cfgH_old", state.current.configId);
    Check("the just-reverted-from cfgI_new becomes the new backup (somewhere to fall back to on a 2nd regression)",
          state.backup.configId == "cfgI_new", state.backup.configId);
    Check("revertCount incremented", state.revertCount == 1, StringFormat("revertCount=%d", state.revertCount));
}

void Test_OverlappingLiveResultIsNotRegression() {
    C04_RegisterState state = EmptyState();
    string reason;
    C04_Promote(state, MakeChampion("cfgJ", 5, 0.20, 0.10, 0.30, 5), reason);

    C04_Champion normalVariance = MakeChampion("cfgJ_live", 5, 0.18, 0.08, 0.28, 6);   // ciHigh 0.28 still > champion ciLow 0.10
    bool regressed = C04_DetectRegression(state, normalVariance, reason);
    Check("ordinary sampling variance (overlapping CI) does not trigger regression", !regressed, reason);
}

void Test_AutoRevertRefusesWithNoBackup() {
    C04_RegisterState state = EmptyState();
    string reason;
    C04_Promote(state, MakeChampion("cfgK_only", 6, 0.20, 0.10, 0.30, 5), reason);   // first-ever champion, no backup

    bool reverted = C04_AutoRevert(state, reason);
    Check("auto-revert REFUSES (not silently no-ops) when no backup exists -- fails closed",
          !reverted, reason);
    Check("current champion unchanged after a refused revert", state.current.configId == "cfgK_only", state.current.configId);
    Check("refusal reason names the missing backup", StringFind(reason, "no backup") >= 0, reason);
}

//+-------------------------------------------------------------------+
//| Persistence round-trip: build a register with a real revert       |
//| history, save it, discard in-memory state (simulated restart),    |
//| reload, and confirm current+backup+revertCount all survive.       |
//+-------------------------------------------------------------------+
void Test_RegisterPersistsAcrossRestart() {
    C04_RegisterState state = EmptyState();
    string reason;
    C04_Promote(state, MakeChampion("cfgL_gen1", 7, 0.15, 0.05, 0.25, 5), reason);
    C04_Promote(state, MakeChampion("cfgL_gen2", 7, 0.28, 0.18, 0.38, 6), reason);
    C04_AutoRevert(state, reason);   // exercises a non-trivial state: reverted once

    bool saved = C04_SaveRegister(g_TestFile, state);
    Check("register saves successfully", saved, "C04_SaveRegister returned false");

    C04_RegisterState reloaded;   // "kill" -- fresh, unrelated struct simulating a restart
    string loadError;
    bool loaded = C04_LoadRegister(g_TestFile, reloaded, loadError);
    Check("register reloads successfully after simulated restart", loaded, loadError);
    Check("reloaded hasChampion matches", reloaded.hasChampion == state.hasChampion, "hasChampion mismatch");
    Check("reloaded current.configId matches", reloaded.current.configId == state.current.configId,
          StringFormat("expected=%s got=%s", state.current.configId, reloaded.current.configId));
    Check("reloaded hasBackup matches", reloaded.hasBackup == state.hasBackup, "hasBackup mismatch");
    Check("reloaded backup.configId matches", reloaded.backup.configId == state.backup.configId,
          StringFormat("expected=%s got=%s", state.backup.configId, reloaded.backup.configId));
    Check("reloaded revertCount matches", reloaded.revertCount == state.revertCount,
          StringFormat("expected=%d got=%d", state.revertCount, reloaded.revertCount));
}

//+-----------------------------------------------------------------------+
//| PROMETHEUS 4.5 (pass_6): "a strategy shape that has failed before      |
//| starts guilty, not innocent." A configId that was reverted FROM must   |
//| clear a strictly higher ciLow bar to re-promote than a fresh one       |
//| would, even when both present the identical evidence.                  |
//+-----------------------------------------------------------------------+
void Test_RepeatOffenderRequiresHigherBar() {
    C04_RegisterState state = EmptyState();
    string reason;
    C04_Promote(state, MakeChampion("cfgM_champ", 8, 0.15, 0.05, 0.25, 5), reason);   // champion, ciLow=0.05
    C04_Promote(state, MakeChampion("cfgN_bad", 8, 0.20, 0.10, 0.30, 5), reason);     // promotes over champ, cfgM_champ -> backup

    C04_Champion liveObserved = MakeChampion("cfgN_bad_live", 8, -0.10, -0.20, -0.02, 6);
    C04_DetectRegression(state, liveObserved, reason);
    C04_AutoRevert(state, reason);   // reverts to cfgM_champ; cfgN_bad recorded in revertedConfigIds
    Check("cfgN_bad is recorded as a repeat offender after being reverted from",
          C04_IsRepeatOffender(state, "cfgN_bad"), "cfgN_bad not found in revert history after a real revert");

    // Same ciLow, offered by the repeat offender vs. a fresh configId.
    double retryCiLow = state.current.ciLow + (C04_REPEAT_OFFENDER_MARGIN * 0.5);   // clears the plain bar, not the repeat-offender bar
    C04_Champion cfgN_retry = MakeChampion("cfgN_bad", 8, 0.12, retryCiLow, 0.20, 5);
    string retryReason;
    C04_PromoteVerdict vRetry = C04_ShouldPromote(state, cfgN_retry, retryReason);
    Check("the repeat offender is rejected even though its ciLow would beat the champion's plain ciLow",
          vRetry == C04_REJECT_NOT_BETTER, StringFormat("verdict=%d reason=%s", vRetry, retryReason));

    C04_Champion freshChallenger = MakeChampion("cfgO_fresh", 8, 0.12, retryCiLow, 0.20, 5);
    string freshReason;
    C04_PromoteVerdict vFresh = C04_ShouldPromote(state, freshChallenger, freshReason);
    Check("the IDENTICAL ciLow from a fresh (never-reverted) configId promotes normally -- only repeat offenders face the higher bar",
          vFresh == C04_PROMOTE, StringFormat("verdict=%d reason=%s", vFresh, freshReason));
}

void OnStart() {
    Print("=== C04.T0001 ChampionRegister acceptance test -- start ===");
    Test_BootstrapInsufficientEvidenceRejects();
    Test_BootstrapNotSignificantRejects();
    Test_BootstrapPromotes();
    Test_SecondPromotionCreatesBackup();
    Test_NotDurablyBetterRejectsAndLeavesStateUnchanged();
    Test_RegressionDetectedAndAutoReverts();
    Test_OverlappingLiveResultIsNotRegression();
    Test_AutoRevertRefusesWithNoBackup();
    Test_RegisterPersistsAcrossRestart();
    Test_RepeatOffenderRequiresHigherBar();
    PrintFormat("=== C04.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("C04.T0001 GREEN -- C04 ChampionRegister meets its acceptance contract (closes INV-17).");
    else            Print("C04.T0001 RED -- see FAIL lines above.");
}

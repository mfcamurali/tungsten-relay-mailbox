//+---------------------------------------------------------------------+
//| P02.T0001 -- acceptance test for P02 FeatureBank                    |
//| Contract under test (GENESIS_MASTER_SPEC.md O2):                    |
//|   "Inject a noise feature -> retired within window; AUC computed OOS|
//|    only; retired features never feed Cognition."                    |
//| Read-only diagnostic script, same posture as prior GENESIS tests.   |
//+---------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Perception\P02_FeatureBank.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  P02.T0001  ", name); }
    else     { g_fail++; Print("FAIL  P02.T0001  ", name, "  -- ", detail); }
}

void MakeNoiseSamples(P02_OOSSample &out[], int n) {
    ArrayResize(out, n);
    // All identical values (total tie), outcome alternating -- deterministic
    // construction that forces AUC to exactly 0.5 (see organ header math).
    for(int i = 0; i < n; i++) { out[i].value = 5.0; out[i].outcomePositive = (i % 2 == 0); }
}

void MakeSignalSamples(P02_OOSSample &out[], int n) {
    ArrayResize(out, n);
    // Positives cleanly separated above negatives -- real discriminative power, AUC->1.0.
    for(int i = 0; i < n; i++) {
        bool pos = (i % 2 == 0);
        out[i].outcomePositive = pos;
        out[i].value = pos ? (10.0 + i * 0.01) : (0.0 + i * 0.01);
    }
}

//+---------------------------------------------------------------------+
//| "Inject a noise feature -> retired within window": once n clears the|
//| power floor, a feature with zero real separation must be retired.   |
//+---------------------------------------------------------------------+
void Test_NoiseFeatureRetires() {
    P02_OOSSample noise[];
    MakeNoiseSamples(noise, 40);   // 40 > P02_MIN_N_FOR_AUC(30)
    P02_FeatureStatus st = P02_Evaluate(noise);
    Check("noise feature's AUC computes to ~0.5",
          st.aucComputed && MathAbs(st.auc - 0.5) < 1e-9,
          StringFormat("aucComputed=%s auc=%.6f", st.aucComputed ? "true":"false", st.auc));
    Check("noise feature is retired once evaluated",
          st.retired, StringFormat("auc=%.6f threshold=%.2f", st.auc, P02_RETIRE_AUC_THRESHOLD));
}

//+----------------------------------------------------------------------+
//| A real, separated signal must NOT be retired -- proves the gate isn't|
//| just "always retire," it's a genuine threshold test.                 |
//+----------------------------------------------------------------------+
void Test_SignalFeatureSurvives() {
    P02_OOSSample signal[];
    MakeSignalSamples(signal, 40);
    P02_FeatureStatus st = P02_Evaluate(signal);
    Check("cleanly-separated signal feature computes a high AUC (>0.9)",
          st.aucComputed && st.auc > 0.9,
          StringFormat("auc=%.6f", st.auc));
    Check("cleanly-separated signal feature is NOT retired",
          !st.retired, StringFormat("auc=%.6f", st.auc));
}

//+----------------------------------------------------------------------+
//| "retired within window": below the power floor, a feature is neither |
//| confirmed-good NOR flagged retired -- it simply hasn't been evaluated|
//| yet. Growing the same noise feature's window across the power floor  |
//| boundary shows retirement happening exactly at the point evidence    |
//| becomes sufficient, not before (fails closed, never fabricated).     |
//+----------------------------------------------------------------------+
void Test_RetirementWithinWindow() {
    P02_OOSSample sparse[];
    MakeNoiseSamples(sparse, 10);   // 10 < P02_MIN_N_FOR_AUC(30)
    P02_FeatureStatus stSparse = P02_Evaluate(sparse);
    Check("below the power floor, AUC is not yet computed",
          !stSparse.aucComputed, StringFormat("n=%d aucComputed=%s", stSparse.n, stSparse.aucComputed ? "true":"false"));
    Check("below the power floor, the feature is NOT flagged retired (nothing to retire from)",
          !stSparse.retired, "an uncomputed feature was incorrectly marked retired");
    Check("below the power floor, the feature is still NOT usable (fails closed, not open)",
          !P02_IsUsable(stSparse), "an unevaluated feature was incorrectly usable");

    P02_OOSSample full[];
    MakeNoiseSamples(full, 40);   // same noise pattern, now past the floor
    P02_FeatureStatus stFull = P02_Evaluate(full);
    Check("the SAME noise feature, once its window clears the power floor, is retired",
          stFull.retired, "noise feature failed to retire once evaluable");
}

//+-----------------------------------------------------------------+
//| "retired features never feed Cognition": P02_IsUsable is the one|
//| sanctioned gate, and it must be false for retired, false for    |
//| unevaluated, true only for a real surviving signal.             |
//+-----------------------------------------------------------------+
void Test_RetiredNeverUsable() {
    P02_OOSSample noise[]; MakeNoiseSamples(noise, 40);
    P02_OOSSample signal[]; MakeSignalSamples(signal, 40);
    P02_FeatureStatus stNoise  = P02_Evaluate(noise);
    P02_FeatureStatus stSignal = P02_Evaluate(signal);
    Check("retired (noise) feature is never usable",
          !P02_IsUsable(stNoise), "retired feature reported usable=true");
    Check("surviving (signal) feature is usable",
          P02_IsUsable(stSignal), "a genuinely separated feature reported usable=false");
}

//+----------------------------------------------------------------------+
//| "AUC computed OOS only": structural -- P02_OOSSample is the only     |
//| sample type in this organ's entire API; there is no in-sample        |
//| variant to accidentally call. This test asserts that structural fact |
//| the only way a compiled test can: by using the type and nothing else.|
//+----------------------------------------------------------------------+
void Test_OOSOnlyByConstruction() {
    P02_OOSSample s[]; MakeSignalSamples(s, 40);
    double auc = P02_ComputeAUC(s);   // the organ's only scoring function, only accepts P02_OOSSample
    Check("the organ's only AUC function accepts and only accepts P02_OOSSample (no in-sample path exists to call instead)",
          auc != EMPTY_VALUE, "sanity: a well-formed OOS sample set failed to produce a real AUC at all");
}

void OnStart() {
    Print("=== P02.T0001 FeatureBank acceptance test -- start ===");
    Test_NoiseFeatureRetires();
    Test_SignalFeatureSurvives();
    Test_RetirementWithinWindow();
    Test_RetiredNeverUsable();
    Test_OOSOnlyByConstruction();
    PrintFormat("=== P02.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("P02.T0001 GREEN -- O2 FeatureBank meets its acceptance contract.");
    else            Print("P02.T0001 RED -- see FAIL lines above.");
}

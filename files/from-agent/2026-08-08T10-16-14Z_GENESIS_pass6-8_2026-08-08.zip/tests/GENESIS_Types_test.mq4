//+----------------------------------------------------------------------+
//| GENESIS.T0001 -- acceptance test for GENESIS_Types (the INV-03       |
//| shared rate type)                                                    |
//| Contract under test (INV-03, GENESIS_MASTER_SPEC.md §1):             |
//|   "Every rate divides by its true observed count, never a constant   |
//|    window literal." Property test over n in [1,50] (the spec's own   |
//|    named regression test: "recentWinRate(k) divides by k for all     |
//|    k<20; property test over k in [1,50]"), plus WARRANT#124's exact   |
//|    failure shape (a /20.0-style hardcoded denominator) made           |
//|    structurally unreproducible through this type.                    |
//| Read-only diagnostic script, same posture as prior GENESIS tests.    |
//+----------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\GENESIS_Types.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  GENESIS.T0001  ", name); }
    else     { g_fail++; Print("FAIL  GENESIS.T0001  ", name, "  -- ", detail); }
}

//+-------------------------------------------------------------------+
//| n<=0 -> UnknownRate, never a fabricated 0% (INV-18-style honesty). |
//+-------------------------------------------------------------------+
void Test_ZeroNIsUnknown() {
    GENESIS_Rate r0 = GENESIS_ComputeRate(0, 0);
    Check("n=0 produces an UNKNOWN rate (isKnown=false), not a fabricated 0%",
          !r0.isKnown, StringFormat("isKnown=%s value=%.4f", r0.isKnown ? "true":"false", r0.value));

    GENESIS_Rate rNeg = GENESIS_ComputeRate(3, -5);   // a corrupt/negative n
    Check("a negative n also produces UNKNOWN, not a crash or a nonsensical rate",
          !rNeg.isKnown, "negative-n case did not refuse");
}

//+-----------------------------------------------------------------------+
//| THE decisive property test named in the spec's own regression-test    |
//| text: for every k in [1,50], a rate computed from k observations       |
//| divides by k itself, never by a fixed window literal (20, or anything  |
//| else) regardless of how small k is. This is WARRANT#124's failure      |
//| shape (understating WR whenever fewer than 20 trades exist) made       |
//| impossible to reproduce: there is no k at which this function's real   |
//| division is silently replaced by a constant.                          |
//+-----------------------------------------------------------------------+
void Test_DividesByRealNForAllKInRange() {
    bool allCorrect = true;
    int firstBadK = -1;
    for(int k = 1; k <= 50; k++) {
        int successes = k / 2;   // varies with k, exercises many distinct fractions
        GENESIS_Rate r = GENESIS_ComputeRate(successes, k);
        double expected = ((double)successes / (double)k) * 100.0;
        if(MathAbs(r.value - expected) > 1e-9) { allCorrect = false; if(firstBadK < 0) firstBadK = k; }
        if(r.n != k) { allCorrect = false; if(firstBadK < 0) firstBadK = k; }
    }
    Check("for every k in [1,50], GENESIS_ComputeRate divides by k itself (never a fixed literal like /20.0)",
          allCorrect, StringFormat("first mismatch at k=%d", firstBadK));
}

//+-------------------------------------------------------------------+
//| Specifically reproduces the WARRANT#124 boundary: k<20 (where a    |
//| hardcoded /20.0 denominator would have understated the rate) must  |
//| still divide by the real, smaller k.                               |
//+-------------------------------------------------------------------+
void Test_SubTwentyKNeverUsesHardcodedTwenty() {
    // 3 wins out of 5 real trades = 60%. A /20.0 bug would report 3/20=15%.
    GENESIS_Rate r = GENESIS_ComputeRate(3, 5);
    Check("k=5 (well under a hypothetical /20.0 literal) reports 60%, not 15% (the WARRANT#124 failure shape)",
          MathAbs(r.value - 60.0) < 1e-9, StringFormat("got %.4f", r.value));
    Check("the rate carries its own real n=5, not a fixed window size",
          r.n == 5, StringFormat("got n=%d", r.n));
}

//+---------------------------------------------------------------------+
//| successes is clamped into [0,n] -- a corrupt count (more wins than  |
//| trades) never produces a rate above 100% or a negative one.         |
//+---------------------------------------------------------------------+
void Test_SuccessesClampedToValidRange() {
    GENESIS_Rate rOver = GENESIS_ComputeRate(999, 10);
    Check("successes > n clamps to 100%, never an out-of-range rate",
          MathAbs(rOver.value - 100.0) < 1e-9, StringFormat("got %.4f", rOver.value));

    GENESIS_Rate rNeg = GENESIS_ComputeRate(-5, 10);
    Check("negative successes clamps to 0%, never a negative rate",
          MathAbs(rNeg.value - 0.0) < 1e-9, StringFormat("got %.4f", rNeg.value));
}

//+-------------------------------------------------------------------+
//| CI widens as n shrinks (less evidence -> less certainty) and the  |
//| point estimate always sits inside its own CI.                     |
//+-------------------------------------------------------------------+
void Test_ConfidenceIntervalShape() {
    GENESIS_Rate rSmall = GENESIS_ComputeRate(3, 5);
    GENESIS_Rate rLarge = GENESIS_ComputeRate(300, 500);   // same ~60% rate, far larger n
    double widthSmall = rSmall.ciHigh - rSmall.ciLow;
    double widthLarge = rLarge.ciHigh - rLarge.ciLow;
    Check("a rate backed by fewer observations has a wider confidence interval",
          widthSmall > widthLarge, StringFormat("small-n width=%.2f large-n width=%.2f", widthSmall, widthLarge));

    Check("the point estimate lies within its own [ciLow,ciHigh]",
          rSmall.value >= rSmall.ciLow && rSmall.value <= rSmall.ciHigh,
          StringFormat("value=%.2f ciLow=%.2f ciHigh=%.2f", rSmall.value, rSmall.ciLow, rSmall.ciHigh));
}

//+-----------------------------------------------------------------------+
//| GENESIS_RateIsDiagnosticallyPowered reuses the one shared power-floor |
//| concept (INV-07) -- n=29 not powered, n=30 powered, and an unknown    |
//| rate is never powered regardless of a (meaningless) n field.          |
//+-----------------------------------------------------------------------+
void Test_DiagnosticPowerGate() {
    GENESIS_Rate rBelow = GENESIS_ComputeRate(15, 29);
    GENESIS_Rate rAt    = GENESIS_ComputeRate(15, 30);
    Check("n=29 is not diagnostically powered", !GENESIS_RateIsDiagnosticallyPowered(rBelow), "n=29 wrongly powered");
    Check("n=30 is diagnostically powered", GENESIS_RateIsDiagnosticallyPowered(rAt), "n=30 wrongly unpowered");

    GENESIS_Rate rUnknown = GENESIS_UnknownRate();
    Check("an UNKNOWN rate is never diagnostically powered, regardless of its n field",
          !GENESIS_RateIsDiagnosticallyPowered(rUnknown), "unknown rate wrongly reported as powered");
}

void OnStart() {
    Print("=== GENESIS.T0001 shared rate-type acceptance test -- start ===");
    Test_ZeroNIsUnknown();
    Test_DividesByRealNForAllKInRange();
    Test_SubTwentyKNeverUsesHardcodedTwenty();
    Test_SuccessesClampedToValidRange();
    Test_ConfidenceIntervalShape();
    Test_DiagnosticPowerGate();
    PrintFormat("=== GENESIS.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("GENESIS.T0001 GREEN -- the shared rate type meets INV-03's own named regression test.");
    else            Print("GENESIS.T0001 RED -- see FAIL lines above.");
}

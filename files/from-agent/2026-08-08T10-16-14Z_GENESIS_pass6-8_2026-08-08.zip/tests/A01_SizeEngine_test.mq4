//+-------------------------------------------------------------------+
//| A01.T0001 -- acceptance test for A01 SizeEngine                   |
//| Contract under test (GENESIS_MASTER_SPEC.md O7):                  |
//|   "Symbolic confidence-degree=1; rho->1 => n_eff->1; size <= FLOOR|
//|    under fuzz."                                                   |
//| Read-only diagnostic script, same posture as prior GENESIS tests. |
//+-------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Action\A01_SizeEngine.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  A01.T0001  ", name); }
    else     { g_fail++; Print("FAIL  A01.T0001  ", name, "  -- ", detail); }
}

//+-----------------------------------------------------------------------+
//| "confidence-degree=1": since MQL4 offers no symbolic algebra, this is |
//| tested the honest empirical equivalent -- size scales EXACTLY         |
//| linearly with confidence (doubling confidence exactly doubles size,   |
//| all else fixed), which is only true if confidence appears to the      |
//| first power exactly once, not squared/cubed by a hidden second factor.|
//+-----------------------------------------------------------------------+
void Test_ConfidenceDegreeOne() {
    double edge = 0.5, variance = 0.01, ddBudget = 1.0; int rawN = 1; double corr = 0.0;
    double sizeAtHalf = A01_ComposeSize(edge, variance, 0.20, ddBudget, rawN, corr);
    double sizeAtFull = A01_ComposeSize(edge, variance, 0.40, ddBudget, rawN, corr);
    Check("doubling confidence (0.20->0.40) exactly doubles size (confidence enters to the first power, once)",
          MathAbs(sizeAtFull - 2.0 * sizeAtHalf) < 1e-9,
          StringFormat("sizeAtHalf=%.6f sizeAtFull=%.6f ratio=%.4f", sizeAtHalf, sizeAtFull, sizeAtFull / MathMax(1e-9, sizeAtHalf)));

    double sizeAtQuarter = A01_ComposeSize(edge, variance, 0.10, ddBudget, rawN, corr);
    Check("confidence scaling is linear across 3 points (0.10/0.20/0.40), not quadratic",
          MathAbs(sizeAtHalf - 2.0 * sizeAtQuarter) < 1e-9,
          StringFormat("sizeAtQuarter=%.6f sizeAtHalf=%.6f", sizeAtQuarter, sizeAtHalf));
}

//+---------------------------------------------------------------------+
//| "rho->1 => n_eff->1": as average correlation approaches 1, effective|
//| bet count collapses to 1 regardless of raw N.                       |
//+---------------------------------------------------------------------+
void Test_RhoToOneCollapsesNEff() {
    double nEffLowCorr  = A01_EffectiveN(10, 0.0);
    double nEffHighCorr = A01_EffectiveN(10, 1.0);
    Check("rho=0 (independent) gives n_eff==raw N",
          MathAbs(nEffLowCorr - 10.0) < 1e-9, StringFormat("n_eff=%.4f", nEffLowCorr));
    Check("rho=1 (fully correlated) collapses n_eff to 1, regardless of raw N=10",
          MathAbs(nEffHighCorr - 1.0) < 1e-9, StringFormat("n_eff=%.4f", nEffHighCorr));

    double nEffN50HighCorr = A01_EffectiveN(50, 1.0);
    Check("rho=1 collapses n_eff to 1 even for a much larger raw N=50",
          MathAbs(nEffN50HighCorr - 1.0) < 1e-9, StringFormat("n_eff=%.4f", nEffN50HighCorr));

    Check("n_eff is always <= raw N (conservative bias) across a grid of N/rho",
          A01_EffectiveN(20, 0.3) <= 20.0 + 1e-9 && A01_EffectiveN(5, 0.7) <= 5.0 + 1e-9,
          "n_eff exceeded raw N for at least one combination");
}

//+--------------------------------------------------------------------+
//| "size <= FLOOR under fuzz": across a wide grid of inputs, including|
//| deliberately extreme/adversarial ones, size must never exceed the  |
//| hard floor.                                                        |
//+--------------------------------------------------------------------+
void Test_SizeNeverExceedsFloorUnderFuzz() {
    double edges[4]      = { 0.01, 0.5, 5.0, 100.0 };
    double variances[4]  = { 0.0001, 0.001, 0.01, 1.0 };
    double confidences[3]= { 0.1, 0.5, 1.0 };
    double ddBudgets[3]  = { 0.0, 0.5, 1.0 };
    int    rawNs[3]      = { 1, 5, 50 };
    double corrs[3]      = { 0.0, 0.5, 1.0 };

    bool allWithinFloor = true;
    double worst = 0.0;
    for(int a=0;a<4;a++) for(int b=0;b<4;b++) for(int c=0;c<3;c++)
    for(int d=0;d<3;d++) for(int e=0;e<3;e++) for(int f=0;f<3;f++) {
        double size = A01_ComposeSize(edges[a], variances[b], confidences[c], ddBudgets[d], rawNs[e], corrs[f]);
        if(size > A01_HARD_FLOOR_PERCENT + 1e-9) { allWithinFloor = false; if(size > worst) worst = size; }
    }
    Check("size never exceeds HARD_FLOOR across a full fuzz grid (incl. extreme edge/variance combos)",
          allWithinFloor, StringFormat("worst observed size=%.4f, floor=%.4f", worst, A01_HARD_FLOOR_PERCENT));
}

void Test_NeverNegative() {
    double size = A01_ComposeSize(-5.0, 0.01, 0.5, 1.0, 1, 0.0);   // negative edge
    Check("negative edge never produces a negative size (kelly abstains, size floors at 0)",
          size >= 0.0, StringFormat("size=%.6f", size));
}

//+-----------------------------------------------------------------------+
//| PROMETHEUS 2.1/2.3 (pass_6): correlation is always assumed >= measured,|
//| and an unknown correlation regime defaults to the crisis assumption    |
//| (rho=1.0), never the least-conservative rho=0.0.                       |
//+-----------------------------------------------------------------------+
void Test_ConservativeCorrelationAddsMargin() {
    double conservative = A01_ConservativeCorrelation(0.30);
    Check("A01_ConservativeCorrelation inflates a measured rho by the safety margin, never returns the raw measurement",
          conservative > 0.30, StringFormat("measured=0.30 conservative=%.4f", conservative));
    double clamped = A01_ConservativeCorrelation(0.95);
    Check("A01_ConservativeCorrelation clamps at 1.0, never produces an invalid correlation above 1",
          clamped <= 1.0 + 1e-9, StringFormat("got %.4f", clamped));
}

void Test_UnknownCorrelationRegimeDefaultsToCrisis() {
    double unknownDefault = A01_CorrelationRegimeDefault(false, 0.0);
    Check("an UNKNOWN correlation regime defaults to rho=1.0 (crisis assumption), never the least-conservative 0.0",
          MathAbs(unknownDefault - 1.0) < 1e-9, StringFormat("got %.4f", unknownDefault));

    double knownPassthrough = A01_CorrelationRegimeDefault(true, 0.40);
    Check("a KNOWN correlation regime passes the real measured value through unchanged",
          MathAbs(knownPassthrough - 0.40) < 1e-9, StringFormat("got %.4f", knownPassthrough));
}

//+-----------------------------------------------------------------------+
//| PROMETHEUS 5.4 (pass_7): "spend budget where conviction and           |
//| durability are highest, starve the marginal" + "the dumb hard floor   |
//| governs the smart budget, always."                                    |
//+-----------------------------------------------------------------------+
void Test_AllocateBudgetStarvesNonDurableCandidate() {
    double conf[3]  = { 0.8, 0.8, 0.8 };
    double durab[3] = { 0.02, 0.05, -0.01 };   // 3rd candidate: ciLow<=0, not durable
    double alloc[];
    A01_AllocateBudget(conf, durab, 3, 5.0, alloc);
    Check("a candidate with non-positive durability (ciLow<=0) is starved to exactly zero allocation",
          alloc[2] < 1e-12, StringFormat("alloc[2]=%.6f", alloc[2]));
    Check("the higher-durability candidate (0.05) gets a strictly larger share than the lower one (0.02)",
          alloc[1] > alloc[0], StringFormat("alloc[0]=%.6f alloc[1]=%.6f", alloc[0], alloc[1]));
}

void Test_AllocateBudgetNeverExceedsHardFloorPerCandidateOrTotal() {
    double conf[2]  = { 1.0, 1.0 };
    double durab[2] = { 1.0, 0.0001 };   // deliberately lopsided -- almost all weight on candidate 0
    double alloc[];
    A01_AllocateBudget(conf, durab, 2, 50.0, alloc);   // absurd requested budget, way above the floor
    double total = alloc[0] + alloc[1];
    Check("no single candidate's allocation exceeds the hard floor even when requested budget is absurdly high",
          alloc[0] <= A01_HARD_FLOOR_PERCENT + 1e-9 && alloc[1] <= A01_HARD_FLOOR_PERCENT + 1e-9,
          StringFormat("alloc[0]=%.4f alloc[1]=%.4f floor=%.4f", alloc[0], alloc[1], A01_HARD_FLOOR_PERCENT));
    Check("total allocation never exceeds the hard floor -- the dumb floor governs the smart budget",
          total <= A01_HARD_FLOOR_PERCENT + 1e-9, StringFormat("total=%.4f", total));
}

void Test_AllocateBudgetAllZeroDurabilityStarvesEveryone() {
    double conf[2]  = { 0.9, 0.9 };
    double durab[2] = { 0.0, -0.5 };   // nobody durable
    double alloc[];
    A01_AllocateBudget(conf, durab, 2, 5.0, alloc);
    Check("when every candidate is non-durable, every allocation is zero (no division-by-zero fallback to an even split)",
          alloc[0] < 1e-12 && alloc[1] < 1e-12, StringFormat("alloc[0]=%.6f alloc[1]=%.6f", alloc[0], alloc[1]));
}

//+-----------------------------------------------------------------------+
//| PROMETHEUS 2.3 reach (pass_8): "know that correlations themselves      |
//| change regime (calm vs crisis) and track which correlation-regime is   |
//| active." No evidence / any crisis-level reading anywhere in the        |
//| window must classify CRISIS -- never CALM by omission.                 |
//+-----------------------------------------------------------------------+
void Test_ClassifyCorrelationRegimeNoEvidenceIsCrisis() {
    double empty[];
    A01_CorrelationRegime r = A01_ClassifyCorrelationRegime(empty, 0);
    Check("zero readings (no evidence) classifies CRISIS, the fail-safe default, never CALM",
          r == A01_CORR_CRISIS, "expected A01_CORR_CRISIS");
}

void Test_ClassifyCorrelationRegimeCalmWindow() {
    double calmSeries[5] = { 0.10, 0.15, 0.05, 0.20, 0.12 };
    A01_CorrelationRegime r = A01_ClassifyCorrelationRegime(calmSeries, 5);
    Check("a window where every reading is low classifies CALM",
          r == A01_CORR_CALM, "expected A01_CORR_CALM");
}

void Test_ClassifyCorrelationRegimeOneCrisisReadingDominates() {
    double mostlyCalmOneSpike[5] = { 0.10, 0.15, 0.05, 0.85, 0.12 };   // one crisis-level spike
    A01_CorrelationRegime r = A01_ClassifyCorrelationRegime(mostlyCalmOneSpike, 5);
    Check("a single crisis-level reading in an otherwise-calm window still classifies CRISIS (max, not average)",
          r == A01_CORR_CRISIS, "expected A01_CORR_CRISIS -- a single spike must not be averaged away");
}

void Test_ClassifyCorrelationRegimeTransitional() {
    double midSeries[3] = { 0.45, 0.50, 0.48 };
    A01_CorrelationRegime r = A01_ClassifyCorrelationRegime(midSeries, 3);
    Check("a window between the calm and crisis thresholds classifies TRANSITIONAL",
          r == A01_CORR_TRANSITIONAL, "expected A01_CORR_TRANSITIONAL");
}

void OnStart() {
    Print("=== A01.T0001 SizeEngine acceptance test -- start ===");
    Test_ConfidenceDegreeOne();
    Test_RhoToOneCollapsesNEff();
    Test_SizeNeverExceedsFloorUnderFuzz();
    Test_NeverNegative();
    Test_ConservativeCorrelationAddsMargin();
    Test_UnknownCorrelationRegimeDefaultsToCrisis();
    Test_AllocateBudgetStarvesNonDurableCandidate();
    Test_AllocateBudgetNeverExceedsHardFloorPerCandidateOrTotal();
    Test_AllocateBudgetAllZeroDurabilityStarvesEveryone();
    Test_ClassifyCorrelationRegimeNoEvidenceIsCrisis();
    Test_ClassifyCorrelationRegimeCalmWindow();
    Test_ClassifyCorrelationRegimeOneCrisisReadingDominates();
    Test_ClassifyCorrelationRegimeTransitional();
    PrintFormat("=== A01.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("A01.T0001 GREEN -- O7 SizeEngine meets its acceptance contract.");
    else            Print("A01.T0001 RED -- see FAIL lines above.");
}

//+-----------------------------------------------------------------------+
//| R04.T0001 -- acceptance test for R04 CuratedNeuralNet                 |
//|                                                                       |
//| No real market/ghost-trade data exists yet to train this network on   |
//| (see organ header) -- so this test proves the MECHANISM is real and   |
//| correct the only honest way available: classic, well-known toy        |
//| problems (XOR, 3-bit parity) that a linear model provably cannot      |
//| solve, so convergence is direct evidence the hidden layers and        |
//| backprop are doing genuine nonlinear work, not a relabeled regression.|
//|                                                                       |
//| This test performs real, moderately heavy computation (two training   |
//| runs of several thousand epochs each) -- like C03's file-I/O test,    |
//| its actual PASS/FAIL (did training converge) can only be observed by  |
//| live execution in MT4, not by compiling it. Compiling proves the      |
//| forward/backward math is syntactically and type-correct; it does not  |
//| prove convergence.                                                    |
//+-----------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Substrate\R04_CuratedNeuralNet.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  R04.T0001  ", name); }
    else     { g_fail++; Print("FAIL  R04.T0001  ", name, "  -- ", detail); }
}

void ZeroPad(double &arr[], double a, double b, double c = 0.0) {
    ArrayResize(arr, R04_INPUT_SIZE);
    ArrayInitialize(arr, 0.0);
    arr[0] = a; arr[1] = b; arr[2] = c;
}

//+---------------------------------------------------------------------+
//| XOR: the textbook proof a network has real hidden-layer nonlinearity|
//| -- no linear model (a plain weighted sum + single activation) can   |
//| separate XOR's classes; only a network with a real hidden layer can.|
//+---------------------------------------------------------------------+
void Test_LearnsXOR() {
    R04_Network net;
    R04_InitNetwork(net, 42);

    R04_Sample samples[4];
    ZeroPad(samples[0].inVec, 0.0, 0.0); samples[0].target[0] = 0.0;
    ZeroPad(samples[1].inVec, 0.0, 1.0); samples[1].target[0] = 1.0;
    ZeroPad(samples[2].inVec, 1.0, 0.0); samples[2].target[0] = 1.0;
    ZeroPad(samples[3].inVec, 1.0, 1.0); samples[3].target[0] = 0.0;

    double mseBefore = R04_MSE(net, samples);
    R04_Train(net, samples, 10000, 0.5);
    double mseAfter = R04_MSE(net, samples);

    Check("XOR training reduces MSE substantially (real learning occurred)",
          mseAfter < mseBefore * 0.25,
          StringFormat("mseBefore=%.4f mseAfter=%.4f", mseBefore, mseAfter));
    Check("XOR training converges to a low absolute error (<0.05 MSE)",
          mseAfter < 0.05, StringFormat("mseAfter=%.4f", mseAfter));

    bool allCorrect = true;
    double output[];
    for(int i = 0; i < 4; i++) {
        R04_Predict(net, samples[i].inVec, output);
        double predicted = (output[0] > 0.5) ? 1.0 : 0.0;
        if(MathAbs(predicted - samples[i].target[0]) > 0.5) allCorrect = false;
    }
    Check("all 4 XOR patterns classify correctly after training",
          allCorrect, "at least one XOR pattern misclassified after 10000 epochs");
}

//+----------------------------------------------------------------------+
//| 3-bit parity: harder than XOR (needs real capacity across both hidden|
//| layers, not just the first) -- output=1 iff an ODD number of the 3   |
//| inVec bits are 1. A genuine stress test that this is real depth doing|
//| real work, not an oversized network memorising 4 XOR patterns by     |
//| coincidence.                                                         |
//+----------------------------------------------------------------------+
void Test_LearnsThreeBitParity() {
    R04_Network net;
    R04_InitNetwork(net, 7);

    R04_Sample samples[8];
    for(int i = 0; i < 8; i++) {
        ArrayInitialize(samples[i].inVec, 0.0);
        ArrayInitialize(samples[i].target, 0.0);
        double b0 = ((i & 1) != 0) ? 1.0 : 0.0;
        double b1 = ((i & 2) != 0) ? 1.0 : 0.0;
        double b2 = ((i & 4) != 0) ? 1.0 : 0.0;
        ZeroPad(samples[i].inVec, b0, b1, b2);
        int onesCount = (int)(b0 + b1 + b2);
        samples[i].target[0] = (onesCount % 2 == 1) ? 1.0 : 0.0;
    }

    double mseBefore = R04_MSE(net, samples);
    R04_Train(net, samples, 20000, 0.5);
    double mseAfter = R04_MSE(net, samples);

    Check("3-bit parity training reduces MSE substantially",
          mseAfter < mseBefore * 0.25,
          StringFormat("mseBefore=%.4f mseAfter=%.4f", mseBefore, mseAfter));
    Check("3-bit parity training converges to a low absolute error (<0.10 MSE)",
          mseAfter < 0.10, StringFormat("mseAfter=%.4f", mseAfter));

    int correct = 0;
    double output[];
    for(int i = 0; i < 8; i++) {
        R04_Predict(net, samples[i].inVec, output);
        double predicted = (output[0] > 0.5) ? 1.0 : 0.0;
        if(MathAbs(predicted - samples[i].target[0]) < 0.5) correct++;
    }
    Check("at least 7 of 8 parity patterns classify correctly (a linear model could not exceed chance on this problem)",
          correct >= 7, StringFormat("correct=%d/8", correct));
}

//+----------------------------------------------------------------------+
//| The live-trust gate must refuse an under-trained network exactly like|
//| every other underpowered read in this codebase, regardless of how    |
//| well it happens to fit its own tiny training set.                    |
//+----------------------------------------------------------------------+
void Test_TrustGateRefusesSmallSample() {
    Check("8 training samples (XOR) is nowhere near the live-trust floor",
          !R04_IsTrustworthy(8), "8 samples incorrectly reported as trustworthy for a live decision");
    Check("499 samples is still below the n>=500 trading-weight floor",
          !R04_IsTrustworthy(499), "499 samples incorrectly reported as trustworthy");
    Check("500 samples clears the floor",
          R04_IsTrustworthy(500), "500 samples incorrectly reported as NOT trustworthy");
}

void OnStart() {
    Print("=== R04.T0001 CuratedNeuralNet acceptance test -- start (this will take a few seconds) ===");
    Test_LearnsXOR();
    Test_LearnsThreeBitParity();
    Test_TrustGateRefusesSmallSample();
    PrintFormat("=== R04.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("R04.T0001 GREEN -- R04 CuratedNeuralNet demonstrates real learning capability.");
    else            Print("R04.T0001 RED -- see FAIL lines above.");
}

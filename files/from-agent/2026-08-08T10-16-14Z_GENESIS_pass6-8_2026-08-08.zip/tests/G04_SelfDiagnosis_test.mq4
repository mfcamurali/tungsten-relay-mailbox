//+------------------------------------------------------------------+
//| G04.T0001 -- acceptance test for G04 SelfDiagnosis               |
//| Contract under test (GENESIS_MASTER_SPEC.md O13):                |
//|   "Every no-edge line carries cause+stat; flat vs time-varying   |
//|    correctly distinguished on fixtures."                         |
//| Read-only diagnostic script, same posture as prior GENESIS tests.|
//+------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Conscience\G04_SelfDiagnosis.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  G04.T0001  ", name); }
    else     { g_fail++; Print("FAIL  G04.T0001  ", name, "  -- ", detail); }
}

C01_Adjudication MakeNoneAdjudication(string cause) {
    C01_Adjudication a;
    a.edge = EMPTY_VALUE; a.ciLow = EMPTY_VALUE; a.ciHigh = EMPTY_VALUE;
    a.verdict = C01_NONE; a.windowsUsed = 5; a.cause = cause;
    return a;
}

C01_Adjudication MakeEdgeAdjudication() {
    C01_Adjudication a;
    a.edge = 0.35; a.ciLow = 0.10; a.ciHigh = 0.60;
    a.verdict = C01_EDGE; a.windowsUsed = 5; a.cause = "";
    return a;
}

R01_Verdict MakeSubstrate(R01_SubstrateClass c, int flips, double tstat, int n) {
    R01_Verdict v;
    v.classOut = c; v.flips = flips; v.tstat = tstat; v.nTotal = n;
    return v;
}

//+-----------------------------------------------------------------+
//| "flat vs time-varying correctly distinguished on fixtures": the |
//| decisive test -- the SAME NONE C01 verdict, paired with two     |
//| different substrate readings, must produce two different causes.|
//+-----------------------------------------------------------------+
void Test_FlatVsTimeVaryingDistinguished() {
    C01_Adjudication none = MakeNoneAdjudication("not significant: 95% CI does not exclude zero");

    R01_Verdict flatSubstrate = MakeSubstrate(R01_STATIONARY, 0, 0.4, 200);
    G04_Diagnosis dFlat = G04_Diagnose(none, flatSubstrate);
    Check("stationary substrate + NONE verdict -> cause FLAT",
          dFlat.cause == G04_CAUSE_FLAT, StringFormat("got cause=%d", dFlat.cause));

    R01_Verdict tvSubstrate = MakeSubstrate(R01_TIME_VARYING, 2, 4.1, 200);
    G04_Diagnosis dTV = G04_Diagnose(none, tvSubstrate);
    Check("time-varying substrate + the SAME NONE verdict -> cause TIME-VARYING (correctly distinguished)",
          dTV.cause == G04_CAUSE_TIME_VARYING, StringFormat("got cause=%d", dTV.cause));

    Check("FLAT and TIME-VARYING fixtures produce genuinely different causes from the identical C01 input",
          dFlat.cause != dTV.cause, "both fixtures produced the same cause despite different substrate readings");
}

//+-------------------------------------------------------------------+
//| "Every no-edge line carries cause+stat": narrative is never empty,|
//| tstat is always populated (or honestly EMPTY_VALUE for UNPOWERED, |
//| never silently 0.0).                                              |
//+-------------------------------------------------------------------+
void Test_EveryNoEdgeCarriesCauseAndStat() {
    C01_Adjudication none = MakeNoneAdjudication("insufficient independent windows");

    R01_Verdict unpowered = MakeSubstrate(R01_UNKNOWN, 0, EMPTY_VALUE, 5);
    G04_Diagnosis dUnp = G04_Diagnose(none, unpowered);
    Check("UNPOWERED cause has a non-empty narrative",
          StringLen(dUnp.narrative) > 0, "narrative was empty");
    Check("UNPOWERED cause's tstat is honestly EMPTY_VALUE, never a fabricated 0.0",
          dUnp.tstat == EMPTY_VALUE, StringFormat("tstat=%.6f", dUnp.tstat));
    Check("UNPOWERED narrative names the cause explicitly",
          StringFind(dUnp.narrative, "UNPOWERED") >= 0, StringFormat("narrative='%s'", dUnp.narrative));

    R01_Verdict flat = MakeSubstrate(R01_STATIONARY, 0, 0.2, 300);
    G04_Diagnosis dFlat = G04_Diagnose(none, flat);
    Check("FLAT cause has a non-empty narrative carrying a real t-stat",
          StringLen(dFlat.narrative) > 0 && dFlat.tstat != EMPTY_VALUE,
          StringFormat("narrative='%s' tstat=%.4f", dFlat.narrative, dFlat.tstat));

    R01_Verdict tv = MakeSubstrate(R01_TIME_VARYING, 1, 3.8, 300);
    G04_Diagnosis dTV = G04_Diagnose(none, tv);
    Check("TIME-VARYING cause has a non-empty narrative carrying a real t-stat",
          StringLen(dTV.narrative) > 0 && dTV.tstat != EMPTY_VALUE,
          StringFormat("narrative='%s' tstat=%.4f", dTV.narrative, dTV.tstat));
}

//+----------------------------------------------------------------------+
//| "No bare 'equal weights' output": every one of the three null-cause  |
//| narratives must literally mention its own cause name -- never a bare,|
//| unexplained fallback message.                                        |
//+----------------------------------------------------------------------+
void Test_NoBareEqualWeightsOutput() {
    C01_Adjudication none = MakeNoneAdjudication("test cause");
    string causeNames[3] = { "UNPOWERED", "TIME-VARYING", "FLAT" };
    R01_Verdict substrates[3];
    substrates[0] = MakeSubstrate(R01_UNKNOWN, 0, EMPTY_VALUE, 3);
    substrates[1] = MakeSubstrate(R01_TIME_VARYING, 1, 3.5, 100);
    substrates[2] = MakeSubstrate(R01_STATIONARY, 0, 0.3, 100);

    bool allNamed = true;
    for(int i = 0; i < 3; i++) {
        G04_Diagnosis d = G04_Diagnose(none, substrates[i]);
        if(StringFind(d.narrative, causeNames[i]) < 0) allNamed = false;
    }
    Check("every one of the 3 null-cause narratives explicitly names its own cause (no bare fallback text)",
          allNamed, "at least one narrative did not name its own cause");
}

//+-------------------------------------------------------------------+
//| An EDGE verdict has nothing to diagnose -- distinct, honest state.|
//+-------------------------------------------------------------------+
void Test_EdgeVerdictHasNothingToDiagnose() {
    C01_Adjudication edge = MakeEdgeAdjudication();
    R01_Verdict substrate = MakeSubstrate(R01_STATIONARY, 0, 0.5, 200);
    G04_Diagnosis d = G04_Diagnose(edge, substrate);
    Check("an EDGE verdict produces G04_NONE_TO_DIAGNOSE, not one of the 3 null causes",
          d.cause == G04_NONE_TO_DIAGNOSE, StringFormat("got cause=%d", d.cause));
}

void OnStart() {
    Print("=== G04.T0001 SelfDiagnosis acceptance test -- start ===");
    Test_FlatVsTimeVaryingDistinguished();
    Test_EveryNoEdgeCarriesCauseAndStat();
    Test_NoBareEqualWeightsOutput();
    Test_EdgeVerdictHasNothingToDiagnose();
    PrintFormat("=== G04.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("G04.T0001 GREEN -- O13 SelfDiagnosis meets its acceptance contract.");
    else            Print("G04.T0001 RED -- see FAIL lines above.");
}

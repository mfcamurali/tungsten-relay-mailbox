//+----------------------------------------------------------------------+
//| P03.T0001 -- acceptance test for P03 CostModel                       |
//| Contract under test (GENESIS_MASTER_SPEC.md O3):                     |
//|   "All 9 brackets distinct+present; reported edge <= gross; high-cost|
//|    regime reports negative openly."                                  |
//| Read-only diagnostic script, same posture as prior GENESIS tests.    |
//+----------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Perception\P03_CostModel.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  P03.T0001  ", name); }
    else     { g_fail++; Print("FAIL  P03.T0001  ", name, "  -- ", detail); }
}

//+---------------------------------------------------------------------+
//| "All 9 brackets distinct+present": every regime index 0-8 populated |
//| exactly once, map reports complete, every regime resolves to ITS OWN|
//| bracket (never a fallback/default), and a duplicate-set attempt is  |
//| refused.                                                            |
//+---------------------------------------------------------------------+
void Test_AllNinePresent() {
    P03_ResetBracketMap();
    string err;
    bool allSet = true;
    for(int r = 0; r < 9; r++) {
        double sl = 1.0 + r * 0.1, tp = 2.0 + r * 0.2;   // distinct per-regime values, so a mixed-up index is detectable
        if(!P03_SetBracket(r, sl, tp, err)) allSet = false;
    }
    Check("all 9 regimes accept a bracket set", allSet, "at least one P03_SetBracket call unexpectedly failed");
    Check("map reports complete once all 9 are set", P03_IsMapComplete(), "IsMapComplete()==false after setting all 9");

    bool allCorrect = true;
    for(int r = 0; r < 9; r++) {
        P03_Bracket b;
        if(!P03_GetBracket(r, b)) { allCorrect = false; continue; }
        double expectSL = 1.0 + r * 0.1, expectTP = 2.0 + r * 0.2;
        if(MathAbs(b.slATR - expectSL) > 1e-9 || MathAbs(b.tpATR - expectTP) > 1e-9) allCorrect = false;
    }
    Check("every regime resolves to its OWN distinct calibrated bracket, never a mixed-up or default one",
          allCorrect, "at least one regime's bracket did not match what was set for that exact index");

    string dupErr;
    bool dupAccepted = P03_SetBracket(0, 9.9, 9.9, dupErr);
    Check("a duplicate set for an already-populated regime is refused",
          !dupAccepted, "P03_SetBracket allowed overwriting an already-populated regime silently");
}

//+----------------------------------------------------------------------+
//| Missing regime -> the WHOLE map refuses lookups, even for regimes    |
//| that DO have real data -- "no default fallthrough" for the incomplete|
//| case, matching INV-05's own "missing/duplicate regime fails build."  |
//+----------------------------------------------------------------------+
void Test_MissingRegimeBlocksAllLookups() {
    P03_ResetBracketMap();
    string err;
    for(int r = 0; r < 8; r++) P03_SetBracket(r, 1.5, 2.5, err);   // regime 8 deliberately left unset
    Check("map with one regime missing reports incomplete",
          !P03_IsMapComplete(), "IsMapComplete()==true despite regime 8 never being set");

    P03_Bracket b;
    bool gotPopulatedRegime = P03_GetBracket(0, b);   // regime 0 WAS set, but the map overall is incomplete
    Check("even a genuinely-populated regime refuses to resolve while the map is incomplete",
          !gotPopulatedRegime, "P03_GetBracket(0,...) succeeded despite the map being incomplete overall");
}

//+--------------------------------------------------------------------+
//| "reported edge <= gross": for any non-negative cost, net must never|
//| exceed gross.                                                      |
//+--------------------------------------------------------------------+
void Test_EdgeNeverExceedsGross() {
    double grosses[3] = { 0.5, 1.0, 2.0 };
    double spreads[3] = { 0.0, 5.0, 50.0 };
    bool allHold = true;
    for(int g = 0; g < 3; g++) for(int s = 0; s < 3; s++) {
        P03_CostReport r = P03_NetEdge(grosses[g], spreads[s], 0.0001, 0.0050);   // point value/ATR representative of a 5-pip ATR instrument
        if(r.costComputed && r.edgeNet > r.edgeGross + 1e-12) allHold = false;
    }
    Check("edgeNet never exceeds edgeGross across a grid of gross/spread combinations",
          allHold, "at least one combination produced edgeNet > edgeGross");
}

//+----------------------------------------------------------------------+
//| "high-cost regime reports negative openly": cost exceeding gross must|
//| surface as a real negative number, never clamped to zero.            |
//+----------------------------------------------------------------------+
void Test_HighCostSurfacesNegative() {
    // gross edge 0.3 ATR, spread cost deliberately large relative to ATR.
    P03_CostReport r = P03_NetEdge(0.3, 80.0, 0.0001, 0.0010);   // spreadPrice=0.008, /ATR(0.001) = 8.0 ATR of cost
    Check("a high-cost regime's net edge is a real, un-clamped negative number",
          r.costComputed && r.edgeNet < 0.0,
          StringFormat("costComputed=%s edgeNet=%.4f", r.costComputed ? "true":"false", r.edgeNet));
    Check("the negative net edge is not silently floored at zero",
          r.edgeNet < -1.0, StringFormat("edgeNet=%.4f, expected a real large negative", r.edgeNet));
}

void OnStart() {
    Print("=== P03.T0001 CostModel acceptance test -- start ===");
    Test_AllNinePresent();
    Test_MissingRegimeBlocksAllLookups();
    Test_EdgeNeverExceedsGross();
    Test_HighCostSurfacesNegative();
    PrintFormat("=== P03.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("P03.T0001 GREEN -- O3 CostModel meets its acceptance contract.");
    else            Print("P03.T0001 RED -- see FAIL lines above.");
}

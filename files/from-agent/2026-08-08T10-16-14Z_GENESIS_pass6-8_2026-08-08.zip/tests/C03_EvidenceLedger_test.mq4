//+----------------------------------------------------------------------+
//| C03.T0001 -- acceptance test for C03 EvidenceLedger                  |
//| Contract under test (GENESIS_MASTER_SPEC.md O6):                     |
//|   "Accumulate->kill->reload intact+monotonic; tampered ledger fails  |
//|    schema hash and refuses load."                                    |
//|                                                                      |
//| Unlike every prior GENESIS test, this one performs REAL file I/O     |
//| (MQL4/Files/genesis_c03_test.dat) -- the only way to honestly test   |
//| "survives a restart" is to actually write and re-read a file. This   |
//| still touches nothing broker/trading-related (no orders, no chart    |
//| state) -- a script writing its own data file is normal, low-risk     |
//| script behaviour, not a live-trading action -- but per the standing  |
//| rule (see genesis-phoenix skill), it still needs Manuel to attach and|
//| run this script in MT4 before its PASS/FAIL lines can be observed;   |
//| compiling it (this step) only proves it is syntactically well-formed.|
//+----------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Cognition\C03_EvidenceLedger.mqh"
#include "..\src\Conscience\G01_ArmController.mqh"

int g_pass = 0, g_fail = 0;
string g_TestFile = "genesis_c03_test.dat";
string g_TallyFile = "genesis_c03_tally_test.dat";

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  C03.T0001  ", name); }
    else     { g_fail++; Print("FAIL  C03.T0001  ", name, "  -- ", detail); }
}

C03_Entry MakeEntry(int regime, double edge, double ciLow, double ciHigh, int windows, datetime prov) {
    C03_Entry e; e.regime = regime; e.edge = edge; e.ciLow = ciLow; e.ciHigh = ciHigh;
    e.windowsUsed = windows; e.provenance = prov;
    return e;
}

//+-------------------------------------------------------------------+
//| "Accumulate->kill->reload intact+monotonic": build a ledger in    |
//| memory, save it, discard the in-memory copy entirely (simulating a|
//| restart), reload from disk, and confirm every field and the entry |
//| ORDER match exactly.                                              |
//+-------------------------------------------------------------------+
void Test_AccumulateKillReloadIntact() {
    C03_Entry ledger[]; ArrayResize(ledger, 0);
    C03_Append(ledger, MakeEntry(0, 0.35, 0.20, 0.50, 5, D'2026.08.01 00:00'));
    C03_Append(ledger, MakeEntry(3, 0.18, 0.05, 0.31, 4, D'2026.08.02 00:00'));
    C03_Append(ledger, MakeEntry(7, 0.42, 0.30, 0.54, 6, D'2026.08.03 00:00'));

    bool saved = C03_SaveLedger(g_TestFile, ledger);
    Check("ledger saves successfully", saved, "C03_SaveLedger returned false");

    // "kill" -- discard the in-memory ledger entirely, exactly simulating
    // a restart with no surviving process state.
    ArrayResize(ledger, 0);

    C03_Entry reloaded[];
    C03_LoadResult r = C03_LoadLedger(g_TestFile, reloaded);
    Check("reload succeeds after simulated restart", r.ok, StringFormat("error='%s'", r.error));
    Check("reload recovers all 3 entries", r.entriesLoaded == 3, StringFormat("entriesLoaded=%d", r.entriesLoaded));

    bool intact = (ArraySize(reloaded) == 3);
    if(intact) {
        intact = intact && reloaded[0].regime == 0 && MathAbs(reloaded[0].edge - 0.35) < 1e-9;
        intact = intact && reloaded[1].regime == 3 && MathAbs(reloaded[1].edge - 0.18) < 1e-9;
        intact = intact && reloaded[2].regime == 7 && MathAbs(reloaded[2].edge - 0.42) < 1e-9;
    }
    Check("every field of every entry survives the round-trip exactly",
          intact, "at least one field mismatched after reload");

    bool monotonic = (reloaded[0].provenance < reloaded[1].provenance) && (reloaded[1].provenance < reloaded[2].provenance);
    Check("entry order is preserved (monotonic provenance) after reload",
          monotonic, "reloaded entries are not in original append order");
}

//+---------------------------------------------------------------------+
//| "tampered ledger fails schema hash and refuses load": corrupt one   |
//| byte of a saved file's entry data directly, then confirm load       |
//| refuses (ok=false) rather than silently accepting corrupted content.|
//+---------------------------------------------------------------------+
void Test_TamperedLedgerRefusesLoad() {
    C03_Entry ledger[]; ArrayResize(ledger, 0);
    C03_Append(ledger, MakeEntry(1, 0.25, 0.10, 0.40, 5, D'2026.08.01 00:00'));
    C03_Append(ledger, MakeEntry(2, 0.30, 0.15, 0.45, 5, D'2026.08.02 00:00'));
    C03_SaveLedger(g_TestFile, ledger);

    // Corrupt the file directly: reopen for read+write in binary mode,
    // seek past the 12-byte header (magic+version+count, 3 ints), and
    // overwrite the first entry's regime field with a different value --
    // this changes real content without going through C03_SaveLedger, so
    // the stored checksum no longer matches.
    int h = FileOpen(g_TestFile, FILE_BIN | FILE_READ | FILE_WRITE);
    bool opened = (h != INVALID_HANDLE);
    if(opened) {
        FileSeek(h, 12, SEEK_SET);   // 3 x 4-byte ints: magic, version, count
        FileWriteInteger(h, 999);    // corrupt regime field of entry 0
        FileClose(h);
    }
    Check("tamper step successfully reopened and modified the file",
          opened, "could not reopen the saved file to tamper with it");

    C03_Entry reloaded[];
    C03_LoadResult r = C03_LoadLedger(g_TestFile, reloaded);
    Check("tampered ledger refuses to load (ok=false)",
          !r.ok, StringFormat("tampered file loaded successfully with ok=true, %d entries", r.entriesLoaded));
    Check("tampered ledger's error message mentions checksum",
          StringFind(r.error, "checksum") >= 0, StringFormat("error='%s'", r.error));
    Check("tampered ledger yields zero recovered entries -- never a partial load",
          ArraySize(reloaded) == 0, StringFormat("got %d entries despite failed checksum", ArraySize(reloaded)));
}

//+-------------------------------------------------------------------+
//| A schema/magic-mismatched (e.g. entirely unrelated) file must also|
//| refuse cleanly, not crash or misread garbage as real entries.     |
//+-------------------------------------------------------------------+
void Test_WrongMagicRefusesLoad() {
    string junkFile = "genesis_c03_test_junk.dat";
    int h = FileOpen(junkFile, FILE_BIN | FILE_WRITE);
    if(h != INVALID_HANDLE) { FileWriteInteger(h, 0x12345678); FileWriteInteger(h, 1); FileWriteInteger(h, 0); FileClose(h); }

    C03_Entry reloaded[];
    C03_LoadResult r = C03_LoadLedger(junkFile, reloaded);
    Check("a file with the wrong magic marker refuses to load",
          !r.ok, StringFormat("ok=%s error='%s'", r.ok ? "true":"false", r.error));
    Check("wrong-magic error message names the magic mismatch",
          StringFind(r.error, "magic") >= 0, StringFormat("error='%s'", r.error));
}

//+-----------------------------------------------------------------------+
//| C03_WinLossTally (added pass_5, closes INV-03's real wiring gap):      |
//| record real outcomes, convert to a GENESIS_Rate via the actual         |
//| division this whole invariant protects, and confirm the result feeds   |
//| G01_ArmController's rate-typed entry point correctly end to end.       |
//+-----------------------------------------------------------------------+
void Test_TallyDividesByRealAccumulatedCount() {
    C03_WinLossTally tally; tally.wins = 0; tally.losses = 0;
    for(int i = 0; i < 3; i++) C03_RecordOutcome(tally, true);    // 3 real wins
    for(int i = 0; i < 2; i++) C03_RecordOutcome(tally, false);   // 2 real losses

    GENESIS_Rate rate = C03_TallyToRate(tally);
    Check("tally of 3 wins/2 losses converts to a KNOWN rate", rate.isKnown, "rate was not known");
    Check("rate divides by the REAL accumulated total (5), not a fixed window literal",
          rate.n == 5, StringFormat("n=%d", rate.n));
    Check("3 wins of 5 real trades is exactly 60%%, not a /20.0-style understated figure",
          MathAbs(rate.value - 60.0) < 1e-9, StringFormat("value=%.4f", rate.value));
}

void Test_EmptyTallyIsUnknown() {
    C03_WinLossTally tally; tally.wins = 0; tally.losses = 0;
    GENESIS_Rate rate = C03_TallyToRate(tally);
    Check("an empty tally (no outcomes recorded yet) converts to an UNKNOWN rate, never a fabricated 0%%",
          !rate.isKnown, StringFormat("isKnown=%s value=%.4f", rate.isKnown?"true":"false", rate.value));
}

//+-----------------------------------------------------------------------+
//| The decisive end-to-end proof: real recorded outcomes -> a real        |
//| GENESIS_Rate -> a real arming decision, with no synthetic shortcut      |
//| anywhere in the chain.                                                 |
//+-----------------------------------------------------------------------+
void Test_TallyFeedsArmingDecisionEndToEnd() {
    C03_WinLossTally tally; tally.wins = 0; tally.losses = 0;
    for(int i = 0; i < 93; i++)  C03_RecordOutcome(tally, true);
    for(int i = 0; i < 57; i++)  C03_RecordOutcome(tally, false);   // 150 real trades, 62.0% win rate

    GENESIS_Rate liveRate = C03_TallyToRate(tally);
    string reason;
    G01_ArmVerdict v = G01_EvaluateArmingFromRate(tally.wins + tally.losses, liveRate, true, false, reason);
    Check("150 real recorded trades at a real 62.0%% win rate arms via the end-to-end tally->rate->G01 path",
          v == G01_PERMIT, StringFormat("got verdict=%d reason='%s'", v, reason));
}

void Test_TallyPersistsAcrossRestart() {
    C03_WinLossTally tally; tally.wins = 0; tally.losses = 0;
    for(int i = 0; i < 7; i++) C03_RecordOutcome(tally, true);
    for(int i = 0; i < 4; i++) C03_RecordOutcome(tally, false);

    bool saved = C03_SaveTally(g_TallyFile, tally);
    Check("tally saves successfully", saved, "C03_SaveTally returned false");

    C03_WinLossTally reloaded;   // "kill" -- fresh struct simulating a restart
    string loadError;
    bool loaded = C03_LoadTally(g_TallyFile, reloaded, loadError);
    Check("tally reloads successfully after simulated restart", loaded, loadError);
    Check("reloaded wins/losses match exactly", reloaded.wins == 7 && reloaded.losses == 4,
          StringFormat("wins=%d losses=%d", reloaded.wins, reloaded.losses));
}

void OnStart() {
    Print("=== C03.T0001 EvidenceLedger acceptance test -- start ===");
    Test_AccumulateKillReloadIntact();
    Test_TamperedLedgerRefusesLoad();
    Test_WrongMagicRefusesLoad();
    Test_TallyDividesByRealAccumulatedCount();
    Test_EmptyTallyIsUnknown();
    Test_TallyFeedsArmingDecisionEndToEnd();
    Test_TallyPersistsAcrossRestart();
    PrintFormat("=== C03.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("C03.T0001 GREEN -- O6 EvidenceLedger meets its acceptance contract.");
    else            Print("C03.T0001 RED -- see FAIL lines above.");
}

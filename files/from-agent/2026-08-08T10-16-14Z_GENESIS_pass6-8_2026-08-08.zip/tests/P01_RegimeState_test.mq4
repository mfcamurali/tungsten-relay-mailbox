//+------------------------------------------------------------------+
//| P01.T0001 -- acceptance test for P01 RegimeState                 |
//| Contract under test (GENESIS_MASTER_SPEC.md O1):                 |
//|   "Given labeled fixtures, argmax matches >= baseline; membership|
//|    sums to 1+-1e-9; stale bar -> REFUSE."                        |
//| Read-only diagnostic script, same posture as the Substrate tests.|
//+------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Perception\P01_RegimeState.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  P01.T0001  ", name); }
    else     { g_fail++; Print("FAIL  P01.T0001  ", name, "  -- ", detail); }
}

//+-----------------------------------------------------------------+
//| "membership sums to 1+-1e-9": across several likelihood vectors,|
//| including degenerate/near-zero ones.                            |
//+-----------------------------------------------------------------+
void Test_MembershipSumsToOne() {
    P01_BeliefVector prior = P01_UniformBelief();

    double lrEven[9] = {1,1,1,1,1,1,1,1,1};
    double lrSkewed[9] = {5,0.2,1,1,1,1,1,1,1};
    double lrDegenerate[9] = {0,0,0,0,0,0,0,0,0};   // every likelihood zero -- must still sum to 1 (falls back to uniform)

    P01_BeliefVector b1 = P01_UpdateBelief(prior, lrEven, 0.85);
    P01_BeliefVector b2 = P01_UpdateBelief(prior, lrSkewed, 0.85);
    P01_BeliefVector b3 = P01_UpdateBelief(prior, lrDegenerate, 0.85);

    double s1=0, s2=0, s3=0;
    for(int i=0;i<9;i++) { s1+=b1.p[i]; s2+=b2.p[i]; s3+=b3.p[i]; }

    Check("even-likelihood belief sums to 1 (+-1e-9)", MathAbs(s1-1.0) < 1e-9, StringFormat("sum=%.12f", s1));
    Check("skewed-likelihood belief sums to 1 (+-1e-9)", MathAbs(s2-1.0) < 1e-9, StringFormat("sum=%.12f", s2));
    Check("all-zero-likelihood belief still sums to 1 (fails toward uniform, not toward zero)", MathAbs(s3-1.0) < 1e-9, StringFormat("sum=%.12f", s3));
}

//+---------------------------------------------------------------------+
//| "labeled fixtures, argmax matches >= baseline": 3 fixtures, each    |
//| strongly favouring one labeled regime index, over several successive|
//| updates (simulating repeated confirming evidence, same pattern the  |
//| precedent's own prior-carry-forward was designed for).              |
//+---------------------------------------------------------------------+
void Test_ArgmaxMatchesLabel() {
    int labels[3]     = { 0, 4, 8 };
    int matched = 0;
    for(int f = 0; f < 3; f++) {
        P01_BeliefVector belief = P01_UniformBelief();
        double lr[9];
        for(int i = 0; i < 9; i++) lr[i] = (i == labels[f]) ? 4.0 : 0.9;   // labeled regime's evidence consistently 4x stronger
        // Several successive bars of confirming evidence, prior carried
        // forward EXPLICITLY by the caller (never a hidden static) --
        // this is exactly the cross-bar responsibility P01 deliberately
        // does not own itself (see organ header).
        for(int step = 0; step < 5; step++) {
            P01_Verdict v = P01_Classify(belief, lr, 0.85, true);
            belief = v.belief;
        }
        int dom; double prob;
        P01_Dominant(belief, dom, prob);
        if(dom == labels[f]) matched++;
        Check(StringFormat("fixture favouring regime %d converges to dominant=%d after 5 confirming bars", labels[f], labels[f]),
              dom == labels[f], StringFormat("got dominant=%d prob=%.3f", dom, prob));
    }
    double matchRate = matched / 3.0;
    Check("argmax match rate over labeled fixtures clears baseline (>=0.8)",
          matchRate >= 0.8, StringFormat("match rate=%.2f (%d/3)", matchRate, matched));
}

//+---------------------------------------------------------------------+
//| "stale bar -> REFUSE": freshBar=false must always refuse, regardless|
//| of what prior/likelihoods are passed, and must never silently return|
//| a usable-looking non-refused verdict.                               |
//+---------------------------------------------------------------------+
void Test_StaleBarRefuses() {
    P01_BeliefVector prior = P01_UniformBelief();
    double lr[9] = {4,1,1,1,1,1,1,1,1};   // even a confident-looking likelihood must not overrule staleness
    P01_Verdict v = P01_Classify(prior, lr, 0.85, false);
    Check("stale bar (freshBar=false) sets refused=true",
          v.refused == true, "verdict was not marked refused despite freshBar=false");
    double s=0; for(int i=0;i<9;i++) s+=v.belief.p[i];
    Check("refused verdict's belief still sums to 1 (safe uniform default, not garbage)",
          MathAbs(s-1.0) < 1e-9, StringFormat("sum=%.12f", s));
}

//+---------------------------------------------------------------------+
//| "Ambiguous regime -> max-entropy vector, never a guess": genuinely  |
//| flat evidence (all likelihood ratios equal) must produce the uniform|
//| distribution, not an arbitrary tie-broken favourite.                |
//+---------------------------------------------------------------------+
void Test_AmbiguousIsMaxEntropy() {
    P01_BeliefVector prior = P01_UniformBelief();
    double lrFlat[9] = {1,1,1,1,1,1,1,1,1};
    P01_Verdict v = P01_Classify(prior, lrFlat, 0.85, true);
    double maxH = MathLog(9.0) / MathLog(2.0);
    Check("fully ambiguous evidence produces entropy at (or very near) the maximum",
          v.entropy > maxH - 1e-6, StringFormat("entropy=%.6f maxH=%.6f", v.entropy, maxH));
    Check("fully ambiguous evidence produces confidence near zero",
          v.confidence < 1e-6, StringFormat("confidence=%.6f", v.confidence));
}

//+----------------------------------------------------------------------+
//| "deterministic for a given bar": identical inputs must always        |
//| produce an identical output -- calling twice with the same prior/    |
//| likelihoods/decay must not drift (proves the pure-function design,   |
//| the precedent's own historical failure mode this organ was redesigned|
//| to make impossible).                                                 |
//+----------------------------------------------------------------------+
void Test_DeterministicForGivenBar() {
    P01_BeliefVector prior = P01_UniformBelief();
    double lr[9] = {2,1,3,1,1,1,1,1,1};
    P01_Verdict v1 = P01_Classify(prior, lr, 0.85, true);
    P01_Verdict v2 = P01_Classify(prior, lr, 0.85, true);
    bool identical = true;
    for(int i=0;i<9;i++) if(MathAbs(v1.belief.p[i]-v2.belief.p[i]) > 1e-15) identical = false;
    Check("repeated calls with identical inputs produce byte-identical belief vectors",
          identical, "two calls with the same prior/likelihoods/decay produced different output");
}

void OnStart() {
    Print("=== P01.T0001 RegimeState acceptance test -- start ===");
    Test_MembershipSumsToOne();
    Test_ArgmaxMatchesLabel();
    Test_StaleBarRefuses();
    Test_AmbiguousIsMaxEntropy();
    Test_DeterministicForGivenBar();
    PrintFormat("=== P01.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("P01.T0001 GREEN -- O1 RegimeState meets its acceptance contract.");
    else            Print("P01.T0001 RED -- see FAIL lines above.");
}

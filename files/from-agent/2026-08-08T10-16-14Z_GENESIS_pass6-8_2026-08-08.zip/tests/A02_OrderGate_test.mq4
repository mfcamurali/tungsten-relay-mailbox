//+-----------------------------------------------------------------------+
//| A02.T0001 -- acceptance test for A02 OrderGate                        |
//| Contract under test (GENESIS_MASTER_SPEC.md O8):                      |
//|   "Every entry type routes here; realized risk <= FLOOR always;       |
//|    direct-broker call elsewhere fails build."                         |
//|                                                                       |
//| The "direct-broker call elsewhere fails build" clause is verified     |
//| OUTSIDE this compiled test (a real grep-based audit of src/ confirming|
//| zero OrderSend/OrderClose/OrderModify/OrderDelete references exist    |
//| anywhere except inside this organ's own dormant, commented placeholder|
//| -- recorded in GENESIS_LEDGER.json's A02 entry) -- MQL4 has no way to |
//| express "this identifier must not appear elsewhere" as a compile      |
//| test, so the honest equivalent is a real, run, automated source scan. |
//+-----------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Action\A02_OrderGate.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  A02.T0001  ", name); }
    else     { g_fail++; Print("FAIL  A02.T0001  ", name, "  -- ", detail); }
}

//+-----------------------------------------------------------------------+
//| "Every entry type routes here": the gate function takes no            |
//| entry-type parameter at all -- proving there is no type-shaped        |
//| branch a future entry type could slip past unclamped. Simulate several|
//| "entry types" by calling the SAME function with the same-shaped       |
//| proposal and confirming identical clamping behaviour every time.      |
//+-----------------------------------------------------------------------+
void Test_EveryEntryTypeRoutesHere() {
    // 5 "entry types" (market/stop/limit/sign-agnostic-leg/optimal-stopping-exit,
    // named only in the test -- the gate itself has no such concept, which IS the point).
    double proposals[5] = { 20.0, 20.0, 20.0, 20.0, 20.0 };
    bool allClampedIdentically = true;
    for(int i = 0; i < 5; i++) {
        A02_GateDecision d = A02_Gate(proposals[i]);
        if(MathAbs(d.approvedRiskPercent - A01_HARD_FLOOR_PERCENT) > 1e-9 || !d.wasClamped) allClampedIdentically = false;
    }
    Check("identical over-floor proposals from 5 different simulated entry types all clamp identically",
          allClampedIdentically, "at least one simulated entry type was not clamped the same way as the others");
}

//+--------------------------------------------------------------------+
//| "realized risk <= FLOOR always": fuzz a wide range of proposed risk|
//| values, including negative and absurdly large ones.                |
//+--------------------------------------------------------------------+
void Test_RealizedRiskNeverExceedsFloor() {
    double proposals[7] = { -10.0, 0.0, 3.0, 7.5, 7.500001, 50.0, 1000000.0 };
    bool allWithinFloor = true;
    for(int i = 0; i < 7; i++) {
        A02_GateDecision d = A02_Gate(proposals[i]);
        if(d.approvedRiskPercent > A01_HARD_FLOOR_PERCENT + 1e-9) allWithinFloor = false;
    }
    Check("approved risk never exceeds HARD_FLOOR across a wide fuzz range including absurd inputs",
          allWithinFloor, "at least one proposal produced an approved risk above the floor");

    A02_GateDecision atFloor = A02_Gate(A01_HARD_FLOOR_PERCENT);
    Check("a proposal exactly AT the floor is approved, not wrongly clamped/flagged",
          atFloor.approved && !atFloor.wasClamped,
          StringFormat("approved=%s wasClamped=%s", atFloor.approved?"true":"false", atFloor.wasClamped?"true":"false"));
}

//+-----------------------------------------------------------------------+
//| The placement chokepoint itself: dormant by default, refuses an       |
//| already-over-floor request outright rather than silently placing a    |
//| clamped order, and is provably the only broker-API call site in the   |
//| entire src/ tree (see file header + GENESIS_LEDGER.json's audit note).|
//+-----------------------------------------------------------------------+
void Test_PlacementChokepointDormantAndSafe() {
    string err;
    bool placedNormal = A02_PlaceOrder(3.0, err);
    Check("PlaceOrder refuses while A02_LIVE_EXECUTION_ENABLED is false, even for an in-range request",
          !placedNormal && StringFind(err, "DISABLED") >= 0,
          StringFormat("placed=%s err='%s'", placedNormal?"true":"false", err));

    string err2;
    bool placedOverFloor = A02_PlaceOrder(50.0, err2);
    Check("PlaceOrder REFUSES an over-floor request outright (does not silently clamp-and-place)",
          !placedOverFloor && StringFind(err2, "REFUSED") >= 0,
          StringFormat("placed=%s err='%s'", placedOverFloor?"true":"false", err2));
}

void OnStart() {
    Print("=== A02.T0001 OrderGate acceptance test -- start ===");
    Test_EveryEntryTypeRoutesHere();
    Test_RealizedRiskNeverExceedsFloor();
    Test_PlacementChokepointDormantAndSafe();
    PrintFormat("=== A02.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("A02.T0001 GREEN -- O8 OrderGate meets its acceptance contract.");
    else            Print("A02.T0001 RED -- see FAIL lines above.");
}

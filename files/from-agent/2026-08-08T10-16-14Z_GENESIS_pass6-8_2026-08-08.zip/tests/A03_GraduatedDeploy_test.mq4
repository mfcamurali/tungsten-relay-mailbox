//+------------------------------------------------------------------+
//| A03.T0001 -- acceptance test for A03 GraduatedDeploy             |
//| Contract under test (GENESIS_MASTER_SPEC.md O9):                 |
//|   "From cold start, size rises smoothly with evidence; no step   |
//|    discontinuity; never full-size on n<30."                      |
//| Read-only diagnostic script, same posture as prior GENESIS tests.|
//+------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Action\A03_GraduatedDeploy.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  A03.T0001  ", name); }
    else     { g_fail++; Print("FAIL  A03.T0001  ", name, "  -- ", detail); }
}

//+------------------------------------------------------------+
//| Cold start (n=0): micro probe only, never zero, never full.|
//+------------------------------------------------------------+
void Test_ColdStartIsMicroProbe() {
    double f = A03_DeploymentFactor(0);
    Check("cold start (n=0) deployment is the micro-probe floor, not zero",
          f > 0.0 && MathAbs(f - A03_MICRO_PROBE_FLOOR) < 1e-9,
          StringFormat("f=%.6f expected~%.6f", f, A03_MICRO_PROBE_FLOOR));
    Check("cold start deployment is nowhere near full size",
          f < 0.05, StringFormat("f=%.6f", f));
}

//+---------------------------------------------------------------------+
//| "size rises smoothly with evidence": monotonic non-decreasing across|
//| the full evidence range.                                            |
//+---------------------------------------------------------------------+
void Test_RisesMonotonicallyWithEvidence() {
    int ns[7] = { 0, 10, 30, 100, 250, 500, 1000 };
    bool monotonic = true;
    double prev = -1.0;
    for(int i = 0; i < 7; i++) {
        double f = A03_DeploymentFactor(ns[i]);
        if(f < prev - 1e-12) monotonic = false;
        prev = f;
    }
    Check("deployment factor is monotonic non-decreasing as evidence (n) grows",
          monotonic, "at least one larger n produced a smaller deployment factor");

    Check("deployment factor at n=1000 (well past the floor) is at/near full (1.0)",
          MathAbs(A03_DeploymentFactor(1000) - 1.0) < 1e-9,
          StringFormat("f(1000)=%.6f", A03_DeploymentFactor(1000)));
}

//+------------------------------------------------------------------------+
//| "no step discontinuity": sweep n and n+1 across a wide range, including|
//| the precedent's old binary threshold points (n=30, n=500), and confirm |
//| the per-step delta stays small everywhere -- no cliff anywhere.        |
//+------------------------------------------------------------------------+
void Test_NoStepDiscontinuityAnywhere() {
    double maxDelta = 0.0;
    int worstN = -1;
    for(int n = 0; n < 700; n++) {
        double delta = MathAbs(A03_DeploymentFactor(n + 1) - A03_DeploymentFactor(n));
        if(delta > maxDelta) { maxDelta = delta; worstN = n; }
    }
    Check("no single-step (n -> n+1) change anywhere exceeds a small bound (<0.01) -- no cliff at any n, including the old n=30/n=500 thresholds",
          maxDelta < 0.01, StringFormat("largest single-step delta=%.6f at n=%d", maxDelta, worstN));

    // Specifically check the precedent's own old binary-threshold points --
    // these are exactly where a step function WOULD have jumped.
    double deltaAt30  = MathAbs(A03_DeploymentFactor(31) - A03_DeploymentFactor(29));
    double deltaAt500 = MathAbs(A03_DeploymentFactor(501) - A03_DeploymentFactor(499));
    Check("no discontinuity straddling the old n=30 diagnostic threshold",
          deltaAt30 < 0.01, StringFormat("delta=%.6f", deltaAt30));
    Check("no discontinuity straddling the n=500 trading-weight floor",
          deltaAt500 < 0.01, StringFormat("delta=%.6f", deltaAt500));
}

//+---------------------------------------------------+
//| "never full-size on n<30": explicit, direct check.|
//+---------------------------------------------------+
void Test_NeverFullSizeBelow30() {
    bool allFarFromFull = true;
    double worst = 0.0;
    for(int n = 0; n < 30; n++) {
        double f = A03_DeploymentFactor(n);
        if(f > 0.10) { allFarFromFull = false; if(f > worst) worst = f; }
    }
    Check("deployment factor stays well below full size for every n<30",
          allFarFromFull, StringFormat("worst observed f=%.6f for some n<30", worst));
}

void OnStart() {
    Print("=== A03.T0001 GraduatedDeploy acceptance test -- start ===");
    Test_ColdStartIsMicroProbe();
    Test_RisesMonotonicallyWithEvidence();
    Test_NoStepDiscontinuityAnywhere();
    Test_NeverFullSizeBelow30();
    PrintFormat("=== A03.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("A03.T0001 GREEN -- O9 GraduatedDeploy meets its acceptance contract.");
    else            Print("A03.T0001 RED -- see FAIL lines above.");
}

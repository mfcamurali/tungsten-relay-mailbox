//+-----------------------------------------------------------------------+
//| G03.T0001 -- acceptance test for G03 Logger                           |
//| Contract under test (GENESIS_MASTER_SPEC.md O12):                     |
//|   "Every @decision emits one line; static scan finds zero Print; feed |
//|    shows all verdicts live."                                          |
//|                                                                       |
//| "static scan finds zero Print" is verified OUTSIDE this compiled test,|
//| same pattern as A02/G02's own audits: a real grep of the entire src/  |
//| tree confirms the only Print() call anywhere is this organ's own      |
//| single line -- recorded in GENESIS_LEDGER.json's G03 entry.           |
//|                                                                       |
//| This test performs real file I/O (writes genesis_live_feed.log), same |
//| posture as C03's own test -- its file-content assertions can only be  |
//| confirmed by live execution, not by compiling it.                     |
//+-----------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Conscience\G03_Logger.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  G03.T0001  ", name); }
    else     { g_fail++; Print("FAIL  G03.T0001  ", name, "  -- ", detail); }
}

//+---------------------------------------------------------------------+
//| "Every @decision emits one line": the emitted-count must increase by|
//| exactly 1 per call, never 0, never 2 (e.g. from an accidental double|
//| write).                                                             |
//+---------------------------------------------------------------------+
void Test_EachCallEmitsExactlyOneLine() {
    int before = G03_GetEmittedCount();
    G03_LogVerdict("G01_ArmController", "PERMIT: n=150, durable, not WF-fragile");
    int afterOne = G03_GetEmittedCount();
    Check("one call to G03_LogVerdict increases the emitted count by exactly 1",
          afterOne == before + 1, StringFormat("before=%d after=%d", before, afterOne));

    G03_LogVerdict("C01_EdgeAdjudicator", "NONE: not durable, 1 of 5 windows non-positive");
    G03_LogVerdict("G02_GateBus", "BLOCK: overfit-gate");
    int afterThree = G03_GetEmittedCount();
    Check("three calls to G03_LogVerdict increase the emitted count by exactly 3 total",
          afterThree == before + 3, StringFormat("before=%d afterThree=%d", before, afterThree));
}

//+--------------------------------------------------------------------+
//| "feed shows all verdicts live": every logged verdict must actually |
//| land in the feed file, in order, not just in the in-memory counter.|
//+--------------------------------------------------------------------+
void Test_FeedShowsAllVerdictsLive() {
    // Start from a clean feed file for a deterministic check.
    if(FileIsExist(G03_LOG_FILENAME)) FileDelete(G03_LOG_FILENAME);

    G03_LogVerdict("TestSource1", "first verdict");
    G03_LogVerdict("TestSource2", "second verdict");
    G03_LogVerdict("TestSource3", "third verdict");

    int h = FileOpen(G03_LOG_FILENAME, FILE_TXT | FILE_READ);
    bool opened = (h != INVALID_HANDLE);
    Check("the live-feed file opens for reading after 3 verdicts were logged", opened, "FileOpen failed on the feed file");
    if(!opened) return;

    string lines[3];
    int count = 0;
    while(!FileIsEnding(h) && count < 3) { lines[count] = FileReadString(h); count++; }
    FileClose(h);

    Check("the feed file contains exactly the 3 lines just logged (in order)",
          count == 3 && StringFind(lines[0], "first verdict") >= 0
                     && StringFind(lines[1], "second verdict") >= 0
                     && StringFind(lines[2], "third verdict") >= 0,
          StringFormat("count=%d l0='%s' l1='%s' l2='%s'", count,
                        count>0?lines[0]:"", count>1?lines[1]:"", count>2?lines[2]:""));
}

void OnStart() {
    Print("=== G03.T0001 Logger acceptance test -- start ===");
    Test_EachCallEmitsExactlyOneLine();
    Test_FeedShowsAllVerdictsLive();
    PrintFormat("=== G03.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("G03.T0001 GREEN -- O12 Logger meets its acceptance contract.");
    else            Print("G03.T0001 RED -- see FAIL lines above.");
}

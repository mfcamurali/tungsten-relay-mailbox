//+-------------------------------------------------------------------+
//| R02.T0001 -- acceptance test for R02 SearchDispatcher             |
//| GENESIS test-first protocol (GENESIS_MASTER_SPEC.md sec.5)        |
//|                                                                   |
//| Contract under test (GENESIS_MASTER_SPEC.md O15):                 |
//|   "Dispatch table total over classes; |t|>3 never linear-searched;|
//|    audited per run."                                              |
//|                                                                   |
//| Read-only diagnostic script, same posture as R01.T0001 -- see that|
//| test's header for the compile-vs-live-execution distinction.      |
//+-------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Substrate\R02_SearchDispatcher.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  R02.T0001  ", name); }
    else     { g_fail++; Print("FAIL  R02.T0001  ", name, "  -- ", detail); }
}

R01_Verdict MakeVerdict(R01_SubstrateClass c, int flips, double tstat, int n) {
    R01_Verdict v;
    v.classOut = c; v.flips = flips; v.tstat = tstat; v.nTotal = n;
    return v;
}

//+----------------------------------------------------------------------+
//| "Dispatch table total over classes": every one of the 3 possible     |
//| R01_SubstrateClass values must resolve to a defined, AVAILABLE method|
//| -- no class value may fail to dispatch or fall through to something  |
//| this environment can't actually run.                                 |
//+----------------------------------------------------------------------+
void Test_TotalOverClasses() {
    R01_SubstrateClass classes[3] = { R01_UNKNOWN, R01_STATIONARY, R01_TIME_VARYING };
    for(int i = 0; i < 3; i++) {
        R01_Verdict v = MakeVerdict(classes[i], 0, 0.0, 100);
        R02_SearchMethod m = R02_Dispatch(v);
        Check(StringFormat("class %s dispatches to an available method", R01_ClassName(classes[i])),
              R02_IsAvailable(m),
              StringFormat("dispatch returned %s, which R02_IsAvailable() says is not usable", R02_MethodName(m)));
    }
}

//+---------------------------------------------------------------------+
//| "|t|>3 never linear-searched": the precedent's own SIGN-INVERSION   |
//| threshold. A verdict carrying |t|>3 (classified TIME_VARYING by R01 |
//| specifically because of that t-stat, zero flips) must never dispatch|
//| to LINEAR.                                                          |
//+---------------------------------------------------------------------+
void Test_HighTStatNeverLinear() {
    R01_Verdict v = MakeVerdict(R01_TIME_VARYING, 0, 4.2, 200);   // |t|=4.2 > R01_TSTAT_THRESHOLD(3.0), zero flips
    R02_SearchMethod m = R02_Dispatch(v);
    Check("|t|>3 TIME_VARYING verdict never dispatches to LINEAR",
          m != R02_LINEAR,
          StringFormat("dispatched to %s", R02_MethodName(m)));

    R01_Verdict v2 = MakeVerdict(R01_TIME_VARYING, 0, -5.0, 200);   // negative-tail inversion, same threshold class
    R02_SearchMethod m2 = R02_Dispatch(v2);
    Check("|t|<-3 (negative tail) TIME_VARYING verdict never dispatches to LINEAR",
          m2 != R02_LINEAR,
          StringFormat("dispatched to %s", R02_MethodName(m2)));
}

//+-------------------------------------------------------------------+
//| STATIONARY is the ONLY class permitted to reach LINEAR -- confirms|
//| the mapping isn't just "never linear" but a real, total table.    |
//+-------------------------------------------------------------------+
void Test_StationaryReachesLinear() {
    R01_Verdict v = MakeVerdict(R01_STATIONARY, 0, 0.4, 500);
    R02_SearchMethod m = R02_Dispatch(v);
    Check("STATIONARY verdict dispatches to LINEAR",
          m == R02_LINEAR,
          StringFormat("dispatched to %s instead", R02_MethodName(m)));
}

//+---------------------------------------------------------------------+
//| "audited per run": every dispatch decision must be attributable to a|
//| named, loggable method -- no UNRECOGNIZED-METHOD output for any real|
//| verdict this organ can receive.                                     |
//+---------------------------------------------------------------------+
void Test_AuditedPerRun() {
    R01_SubstrateClass classes[3] = { R01_UNKNOWN, R01_STATIONARY, R01_TIME_VARYING };
    bool allNamed = true;
    for(int i = 0; i < 3; i++) {
        R01_Verdict v = MakeVerdict(classes[i], 1, 3.5, 100);
        string name = R02_MethodName(R02_Dispatch(v));
        if(name == "UNRECOGNIZED-METHOD") allNamed = false;
    }
    Check("every dispatch decision resolves to a named, loggable method",
          allNamed, "at least one class dispatched to an unrecognized method name");
}

//+-----------------------------------------------------------------------+
//| R02_DispatchWithNeuralOption: CURATED_NEURAL only when BOTH the       |
//| verdict is TIME_VARYING AND the caller asserts the network is         |
//| trustworthy -- never for STATIONARY/UNKNOWN, never when untrustworthy.|
//+-----------------------------------------------------------------------+
void Test_NeuralOptionGated() {
    R01_Verdict vTV  = MakeVerdict(R01_TIME_VARYING, 1, 4.0, 600);
    R01_Verdict vStat = MakeVerdict(R01_STATIONARY, 0, 0.4, 600);
    R01_Verdict vUnk = MakeVerdict(R01_UNKNOWN, 0, 0.0, 5);

    Check("TIME_VARYING + trustworthy=true dispatches to CURATED_NEURAL",
          R02_DispatchWithNeuralOption(vTV, true) == R02_CURATED_NEURAL,
          StringFormat("got %s", R02_MethodName(R02_DispatchWithNeuralOption(vTV, true))));
    Check("TIME_VARYING + trustworthy=false falls back to the safe default (never CURATED_NEURAL)",
          R02_DispatchWithNeuralOption(vTV, false) != R02_CURATED_NEURAL,
          StringFormat("got %s", R02_MethodName(R02_DispatchWithNeuralOption(vTV, false))));
    Check("STATIONARY never dispatches to CURATED_NEURAL even if trustworthy=true",
          R02_DispatchWithNeuralOption(vStat, true) != R02_CURATED_NEURAL,
          StringFormat("got %s", R02_MethodName(R02_DispatchWithNeuralOption(vStat, true))));
    Check("UNKNOWN never dispatches to CURATED_NEURAL even if trustworthy=true",
          R02_DispatchWithNeuralOption(vUnk, true) != R02_CURATED_NEURAL,
          StringFormat("got %s", R02_MethodName(R02_DispatchWithNeuralOption(vUnk, true))));
}

void OnStart() {
    Print("=== R02.T0001 SearchDispatcher acceptance test -- start ===");
    Test_TotalOverClasses();
    Test_NeuralOptionGated();
    Test_HighTStatNeverLinear();
    Test_StationaryReachesLinear();
    Test_AuditedPerRun();
    PrintFormat("=== R02.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("R02.T0001 GREEN -- O15 SearchDispatcher meets its acceptance contract.");
    else            Print("R02.T0001 RED -- see FAIL lines above.");
}

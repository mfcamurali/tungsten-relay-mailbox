# TUNGSTEN_LIMITLESS_QUANT
# PROMETHEUS — The Boundless-Capability Charter
## The specification of what the organism must *be* to be completely trusted

**Target:** GENESIS, next generation · **Benchmark:** every prior TUNGSTEN, surpassed · **Mode:** boundless ambition, spined with honesty.

> This is the charter for the TUNGSTEN we have been aiming at all along — dense, cerebral, strategic, boundless in capability, and *because of that*, disciplined without exception. Every faculty below is a genuine ambition the organism must reach. Every faculty is paired with the guardrail that stops that ambition from becoming the overfitting, the fantasy, or the silent failure that burned every previous version. **Capability without the guardrail is not power — it is the next collapse wearing a better costume.** The two columns are one design.

---

## THE PRIME AMBITION

Build an organism that can **distill all present information — even when incomplete, late, or conflicting — and make the best possible decision with it**, that reads correlation and relationship on the fly, that has walked every relevant historical event and grasped the fundamental relationships between them well enough to reproduce its own conclusions, and that expresses all of this as continuous, confidence-scaled, fail-bounded action.

And — stated with equal weight, because it is what makes the rest trustworthy — an organism that **knows the limits of its own knowledge**, never assumes a moving edge will persist, never acts bold on a thin read, and narrates honestly, in its own feed, exactly why it did what it did.

This is the level at which the system can be completely trusted, and the level at which it is worth being proud of.

---

## HOW TO READ THIS CHARTER

Each faculty has two halves that must ship together:
- **▲ The reach** — the ambition, the capability the organism must genuinely possess.
- **⊣ The spine** — the discipline that keeps that reach honest. Without it, the reach is a liability.

A faculty is only *complete* when both halves are built and the spine is proven to hold under the reach.

---

## 1 · PERCEPTION & DISTILLATION

### 1.1 · Total information intake
- **▲ Reach:** Ingest every available stream — price, volatility, spread, session, correlated instruments, macro calendar, order-flow proxies — without discarding anything as 'noise' prematurely.
- **⊣ Spine:** Every input carries a live quality/latency tag; missing data is modelled as missing, never silently zero-filled.

### 1.2 · Distillation under incompleteness
- **▲ Reach:** Form the best possible read from partial, late, or conflicting information — never freeze waiting for perfect data.
- **⊣ Spine:** Confidence is an explicit output; a read from thin data is labelled thin and sized accordingly, never trusted as if complete.

### 1.3 · Soft-membership regime sense
- **▲ Reach:** Hold the market as a continuous blend of regimes, not one hard label — 60% range / 30% momentum / 10% reversal at once.
- **⊣ Spine:** Membership sums to 1 with calibrated confidence; ambiguity returns max-entropy, never a false-confident guess.

### 1.4 · Multi-timescale coherence
- **▲ Reach:** See the same moment across M1 to D1 simultaneously and reconcile what each timescale says.
- **⊣ Spine:** Timescale conflicts are surfaced, not averaged away; disagreement lowers size, it doesn't get hidden.

### 1.5 · Signal-quality introspection
- **▲ Reach:** Know, per feature, how discriminative it is right now out-of-sample — and retire the ones that have gone dead.
- **⊣ Spine:** AUC measured OOS-only; anything below chance is auto-retired, no feature is trusted on reputation.

---

## 2 · CORRELATION & RELATIONSHIP INTELLIGENCE

### 2.1 · On-the-fly correlation
- **▲ Reach:** Compute live cross-instrument and cross-feature correlation continuously, updating as the market moves — not from a stale nightly matrix.
- **⊣ Spine:** Correlation is always assumed >= measured (conservative); n_eff shrinks size when bets are secretly the same bet.

### 2.2 · Structural relationship discovery
- **▲ Reach:** Search for the fundamental relationships between events — lead/lag, causation candidates, regime co-movement — and hold them as hypotheses.
- **⊣ Spine:** Every discovered relationship is a hypothesis with a confidence and a decay, never a law; it must survive out-of-window to be used.

### 2.3 · Correlation-regime awareness
- **▲ Reach:** Know that correlations themselves change regime (calm vs crisis) and track which correlation-regime is active.
- **⊣ Spine:** Crisis-correlation (everything to 1) is the default assumption under stress, never the calm matrix.

### 2.4 · Reproducibility of relationships
- **▲ Reach:** When a relationship is found, store it so the same conditions reproduce the same read — the organism can re-derive its own conclusions.
- **⊣ Spine:** A relationship counts as real only if it reproduces across independent windows; one-window relationships are quarantined, not deployed.

### 2.5 · Redundancy collapse
- **▲ Reach:** Recognise when many signals are one signal wearing different clothes, and count them once.
- **⊣ Spine:** n_eff from the shared correlation matrix; stacking correlated confirmations is forbidden by construction.

---

## 3 · HISTORICAL EDGE CAPTURE

### 3.1 · Exhaustive historical sweep
- **▲ Reach:** Walk every historical event of a given type — every breakout, every reversal, every news spike — and measure what the edge did each time.
- **⊣ Spine:** Measured on held-out windows the sweep never trained on; in-sample sweep results are descriptive only, never predictive.

### 3.2 · Edge-move cartography
- **▲ Reach:** Build a map of where, when, and under what conditions an edge appeared, moved, or vanished across all history.
- **⊣ Spine:** The map records edge instability as a first-class feature — a cell that flipped sign is marked flipped, not averaged.

### 3.3 · Non-stationary edge capture
- **▲ Reach:** Capture edges that MOVE — grasp them while present, follow them as they drift, release them as they fade.
- **⊣ Spine:** Recency-weighted; the estimator is built to expect movement, and a faded edge shrinks size automatically.

### 3.4 · Event-family generalisation
- **▲ Reach:** Learn the shared structure across a family of similar historical events so a novel-but-similar event is handled.
- **⊣ Spine:** Generalisation is validated on events held out of the family fit; a family that only fits itself is rejected.

### 3.5 · Sign-flip vigilance
- **▲ Reach:** Explicitly detect the project's known nemesis — edges that flip sign rather than decay — and never assume persistence.
- **⊣ Spine:** Persistence is never assumed; every edge carries a measured half-life and a flip-probability, and both gate deployment.

---

## 4 · COGNITION & STRATEGY

### 4.1 · Cerebral adjudication
- **▲ Reach:** Weigh all evidence — regime, correlation, historical analogue, cost, confidence — into a single per-regime edge verdict with a confidence interval.
- **⊣ Spine:** Scored out-of-window only; 'no edge' is a first-class verdict, and the CI must exclude break-even to act.

### 4.2 · Strategic foresight
- **▲ Reach:** Reason several moves ahead — what this position implies for exposure, drawdown budget, and the next opportunity.
- **⊣ Spine:** Foresight is bounded by the hard floor and drawdown budget; no projected future can raise present risk past the cap.

### 4.3 · Best-decision-under-uncertainty
- **▲ Reach:** Make the optimal call with the information available, sized to how good that information is — decisive without being reckless.
- **⊣ Spine:** Decisiveness scales with confidence; low information means small action, never a bold bet on a thin read.

### 4.4 · Counterfactual self-testing
- **▲ Reach:** Continuously ask 'what would have proven me wrong?' and hunt for the disconfirming evidence before acting.
- **⊣ Spine:** A candidate edge must survive an active attempt to break it (resample, CSCV, walk-forward) before it is trusted.

### 4.5 · Meta-calibration memory
- **▲ Reach:** Remember which of its own past calibrations held up and which collapsed, and weight future belief accordingly.
- **⊣ Spine:** Past-collapse is weighted heavily; a strategy shape that has failed before starts guilty, not innocent.

---

## 5 · ACTION & EXPRESSION

### 5.1 · Continuous confidence sizing
- **▲ Reach:** Express conviction as a smooth function of confidence — bold when sure and healthy, tiny when unsure — never all-or-nothing.
- **⊣ Spine:** Confidence enters size exactly once; min(size, HARD_FLOOR) is applied last and is uncrossable from every path.

### 5.2 · Graduated participation
- **▲ Reach:** Learn an edge by carefully touching it from the first bar, scaling with accumulated evidence, instead of standing down.
- **⊣ Spine:** Zero-evidence means micro probe only; full size requires >=30 real OOS trades, no exceptions.

### 5.3 · Time-aware execution
- **▲ Reach:** Size into a fresh edge and out of a stale one; act on the freshness of the signal, not a snapshot.
- **⊣ Spine:** Freshness-decay is built in; the estimator is never a full regime behind reality.

### 5.4 · Adaptive risk budgeting
- **▲ Reach:** Spend drawdown budget where conviction and edge-durability are highest; starve the marginal.
- **⊣ Spine:** Budget is loss-proportional and bounded; the dumb hard floor governs the smart budget, always.

---

## 6 · CONSCIENCE & TRUST

### 6.1 · Total self-observability
- **▲ Reach:** Every decision, verdict, and size is on the live feed the instant it happens — nothing silent, ever.
- **⊣ Spine:** One logging spine; a silent decision cannot compile.

### 6.2 · Blocking conscience
- **▲ Reach:** Every safety gate stops the system; no proceed-anyway path exists; fragile evidence never arms.
- **⊣ Spine:** Gates are BLOCK/PASS enums with no override; WF-fragile blocks arming.

### 6.3 · Honest self-diagnosis
- **▲ Reach:** Narrate WHY it stood down — flat signal vs uncapturable structure — in its own words, unprompted.
- **⊣ Spine:** Every null carries a cause and its statistics; no bare 'equal weights' output.

### 6.4 · Reproducible verdicts
- **▲ Reach:** Same conditions produce the same decision — the organism is deterministic and auditable, not moody.
- **⊣ Spine:** Determinism is tested; a non-reproducible verdict is a bug, not a feature.

### 6.5 · Incorruptible memory
- **▲ Reach:** Evidence accumulates across restarts with provenance; nothing resets, nothing corrupts silently.
- **⊣ Spine:** One serializer both directions; schema-hash mismatch aborts load.

---

## THE CROWNING FACULTY — why the two columns are one

The single hardest truth this project has learned, paid for across every prior version, is this: **the edge is real but non-stationary at the sign level.** It does not fade politely — it flips. Every capability above that touches historical edge or correlation is therefore designed around this law, not in denial of it:

- The organism captures historical edges **and** records their instability as a first-class property.
- It discovers relationships **and** holds them as decaying hypotheses that must reproduce out-of-window.
- It reads correlation on the fly **and** assumes it is higher than measured under stress.
- It is boundless in reach **and** bounded, at the very last step, by a hard floor no intelligence can raise.

This is not caution diluting ambition. It is the only form in which this much ambition is survivable. A system that could capture every historical edge but assumed they persist would be the most confident loser ever built. The spine is what turns the reach into trust.

---

## THE STANDARD OF TRUST

The organism has reached the level we need — the level worth being proud of — when all of the following are simultaneously true:

1. **It distills incomplete information into a confidence-scaled decision**, and the confidence is honest — thin reads produce small actions, provably.
2. **It computes correlation and effective independence live**, and never double-counts a bet that is secretly one bet.
3. **It has swept every relevant historical event**, mapped where each edge lived and where it moved, and can reproduce that map on held-out data.
4. **It grasps the fundamental relationships between events** as reproducible hypotheses — and refuses to trade the ones that only fit their own window.
5. **It captures moving edges while they last and releases them as they fade**, because it was built expecting movement.
6. **It reasons several moves ahead** without ever letting a projected future raise present risk past the floor.
7. **Every decision is visible, reproducible, and self-diagnosed** — the organism can always tell you why.
8. **It knows what it does not know**, says so plainly, and stands down honestly rather than acting on a mirage.

When these hold together, GENESIS is not merely better-built than every prior TUNGSTEN — it is the organism those versions were, all along, the rough sketches for.

---

## THE CLAUSE THAT KEEPS US HONEST

PROMETHEUS states this in its own voice, permanently, so no green scorecard is ever mistaken for the thing it is not:

> Every faculty in this charter is a claim about **capability and construction** — what the organism can perceive, relate, remember, and decide, and how honestly it does so. **None of it is proof of profit.** An organism that achieves every faculty above is one that can *find and trust a real edge cleanly and safely if one exists* — and can say so honestly if one does not. That is exactly, and only, what it is for. The market will decide the rest. The organism's job — and the whole of its trustworthiness — is to meet that decision having distilled everything knowable, assumed nothing it could not prove, and risked nothing it could not survive.

That is the level we need it at. That is the one worth being proud of.

---

*TUNGSTEN_LIMITLESS_QUANT · PROMETHEUS · boundless in reach, spined in honesty · distill everything, assume nothing, survive anything · the organism the sketches were always for.*
//+----------------------------------------------------------------------+
//| C01 · EdgeAdjudicator                                                |
//| GENESIS · COGNITION system · organ 01                                |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                   |
//+----------------------------------------------------------------------+
//| Purpose (GENESIS_MASTER_SPEC.md O4):                                 |
//|   Decide per regime whether a durable edge exists, with CI. Returns  |
//|   {edge, ci, verdict in {EDGE,NONE}} scored OOS only, across         |
//|   independent walk-forward windows -- single-split acceptance is     |
//|   impossible by API, not merely discouraged.                         |
//| Invariants enforced: INV-14 (walk-forward, never one split),         |
//|                       INV-18 ('no edge' is a first-class verdict).   |
//| Depends on: P02 FeatureBank (usable features), P03 CostModel         |
//|             (net-of-cost edge per window).                           |
//|                                                                      |
//| Intent, extracted from the precedent (read directly, not copied):    |
//| Phase 3B (OptimizeComponentWeightsForRegime) fit and validated every |
//| regime against exactly ONE train/holdout split -- the long-flagged   |
//| "hypothesis #3" (tungsten_forge_sls30_session memory, open since pass|
//| 2, 2026-07-09) that finally got real attention: WARRANT#50 added a   |
//| strictly-additive two-fold tightening; WARRANT#92 added a strided    |
//| resample-check; WARRANT#79 added real Bailey-Lopez de Prado CSCV     |
//| (C(8,4)=70 balanced splits) as a SEPARATE audit function bolted      |
//| alongside the original single-split search -- three increasingly     |
//| strong patches on a search that still, underneath all of them, fits  |
//| against one split first and gets audited after. Every one of those   |
//| fixes was itself real, valuable, hard-won engineering -- but each one|
//| arrived because the prior one wasn't structurally sufficient, exactly|
//| the "fix bolted on, discovered too late to inform the ones before it"|
//| pattern GENESIS_MASTER_SPEC.md's own preamble names.                 |
//|                                                                      |
//| What changed, and why (Law 1: intent kept, structure discarded):     |
//|   C01 has no single-window code path AT ALL -- its only entry point  |
//|   takes an array of independent window results, sized >=             |
//|   C01_MIN_WINDOWS. A single OOS number can never be adjudicated by   |
//|   this organ; there is no overload, no default k=1, nothing to       |
//|   accidentally call. This is INV-14's "single-split call signature is|
//|   not provided" made literal, not policed by a later CSCV audit      |
//|   layered on top of a single-split search.                           |
//+----------------------------------------------------------------------+
#property strict
#include "..\GENESIS_Constants.mqh"

#define C01_MIN_WINDOWS         3      // C01.K0001 -- fewer than this and there is no honest basis for a walk-forward verdict at all
#define C01_DURABILITY_MIN_N   10      // C01.K0002 -- a window with fewer than this many OOS trades contributes no real evidence either way
#define C01_CI_Z GENESIS_CI_Z_95       // C01.K0003 -- ~95% two-sided normal critical value, a standard literature constant, not invented here -- INV-07: aliases the one shared concept (added pass_3's 2nd smelt pass, GENESIS_Types.mqh had independently redefined this same value)

enum C01_Verdict { C01_NONE = 0, C01_EDGE = 1 };

//--- C01.S#### one independent walk-forward fold's OOS result. Net-of-cost
//--- (P03's job upstream), already OOS by construction -- there is no
//--- "which split is this" flag because every entry in the caller's array
//--- IS, by contract, an independent window.
struct C01_WindowResult {
    double meanReturnATR;   // this window's mean net-of-cost return, ATR units
    int    n;               // OOS trade count this window contributed
};

//--- C01.V#### the organ's single decisive output
struct C01_Adjudication {
    double      edge;         // EMPTY_VALUE if verdict==C01_NONE for lack-of-power reasons
    double      ciLow;
    double      ciHigh;
    C01_Verdict verdict;
    string      cause;        // always populated on C01_NONE -- feeds G04 SelfDiagnosis later (INV-18)
    int         windowsUsed;
};

//+-----------------------------------------------------------------------+
//| C01.F0001 -- the organ's one entry point. Adjudicates a regime's edge |
//| from an array of independent walk-forward window results. There is    |
//| deliberately no overload accepting a single result -- see header.     |
//|                                                                       |
//| Verdict logic, all real, standard statistics (nothing invented):      |
//|  1. windows[] with n<C01_DURABILITY_MIN_N are dropped before anything |
//|     else -- an underpowered window is not evidence either way.        |
//|  2. Fewer than C01_MIN_WINDOWS powered windows remain -> NONE,        |
//|     cause="insufficient independent windows".                         |
//|  3. edge = equal-weighted mean of the powered windows' own means      |
//|     (each window counted once, regardless of its own n -- an          |
//|     independent FOLD is the unit of evidence here, not a raw trade,   |
//|     which is exactly what makes this genuinely OOS/walk-forward       |
//|     rather than one big pooled in-sample-flavoured average).          |
//|  4. ci = edge +/- C01_CI_Z * (sample stdev of window means / sqrt(k)),|
//|     the standard normal-approximation CI of a mean across k           |
//|     independent observations.                                         |
//|  5. EDGE requires BOTH: ciLow>0 (the aggregate is significantly       |
//|     positive) AND every powered window individually positive          |
//|     ("surviving k windows" taken literally -- durability means never  |
//|     losing money in any one independent fold, not just on average).   |
//|     Otherwise NONE, cause states which condition failed.              |
//+-----------------------------------------------------------------------+
C01_Adjudication C01_Adjudicate(const C01_WindowResult &windows[]) {
    C01_Adjudication r;
    r.edge = EMPTY_VALUE; r.ciLow = EMPTY_VALUE; r.ciHigh = EMPTY_VALUE;
    r.verdict = C01_NONE; r.windowsUsed = 0; r.cause = "";

    int total = ArraySize(windows);
    double powered[]; ArrayResize(powered, 0);
    for(int i = 0; i < total; i++) {
        if(windows[i].n >= C01_DURABILITY_MIN_N) {
            int sz = ArraySize(powered);
            ArrayResize(powered, sz + 1);
            powered[sz] = windows[i].meanReturnATR;
        }
    }
    int k = ArraySize(powered);
    r.windowsUsed = k;

    if(k < C01_MIN_WINDOWS) {
        r.cause = StringFormat("insufficient independent windows: %d powered (need >=%d)", k, C01_MIN_WINDOWS);
        return r;
    }

    double sum = 0.0; for(int i = 0; i < k; i++) sum += powered[i];
    double mean = sum / k;
    double sumSq = 0.0; for(int i = 0; i < k; i++) sumSq += (powered[i] - mean) * (powered[i] - mean);
    double stdev = MathSqrt(sumSq / MathMax(1, k - 1));
    double se = stdev / MathSqrt((double)k);

    r.edge   = mean;
    r.ciLow  = mean - C01_CI_Z * se;
    r.ciHigh = mean + C01_CI_Z * se;

    bool allPositive = true;
    for(int i = 0; i < k; i++) if(powered[i] <= 0.0) { allPositive = false; break; }

    if(r.ciLow > 0.0 && allPositive) {
        r.verdict = C01_EDGE;
        r.cause = "";
    } else {
        r.verdict = C01_NONE;
        if(!allPositive)     r.cause = StringFormat("not durable: at least one of %d windows was non-positive", k);
        else                 r.cause = StringFormat("not significant: 95%% CI [%.4f, %.4f] does not exclude zero", r.ciLow, r.ciHigh);
    }
    return r;
}

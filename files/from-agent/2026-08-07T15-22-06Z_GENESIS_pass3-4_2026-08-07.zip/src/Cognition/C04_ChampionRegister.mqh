//+-----------------------------------------------------------------------+
//| C04 · ChampionRegister                                                |
//| GENESIS · COGNITION system · extension organ (not in the original 16) |
//| built on top of C03 EvidenceLedger, per the same pattern R04 used to  |
//| extend R02 SearchDispatcher.                                          |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.2.0-dev                    |
//+-----------------------------------------------------------------------+
//| Purpose (closes INV-17, named but not built in pass_2):               |
//|   "A new champion that underperforms the prior proven one auto-       |
//|    reverts; every champion has a backup."                             |
//| Invariants enforced: INV-17 (champion auto-reverts on regression).    |
//| Depends on: C01 EdgeAdjudicator (reuses C01_MIN_WINDOWS -- INV-08     |
//|             "one named constant per concept", not a second durability |
//|             floor invented here), C03 EvidenceLedger (the evidence    |
//|             this organ's champions/challengers are built from).       |
//|                                                                       |
//| Intent, extracted from the precedent (read directly, not copied):     |
//| WARRANT#128/129 are INV-17's own named origin in this project's real  |
//| history: no auto-revert mechanism existed anywhere in the precedent   |
//| for a promoted configuration that later underperformed, and the       |
//| watchdog scripts around the live terminal (tungsten_watchdog.ps1 and  |
//| its kin, per mt4_ea_swap_automation memory) restart a crashed PROCESS |
//| but have no concept of reverting a champion CONFIGURATION that is     |
//| still running fine but has started losing -- those are different      |
//| failure classes and the precedent only ever solved the first one.     |
//|                                                                       |
//| What this organ is, precisely: a small, self-contained decision +     |
//| persistence organ that holds exactly one CURRENT champion and (once a |
//| promotion has happened at least once) exactly one BACKUP -- the prior |
//| proven configuration. It never has a code path that reverts to a      |
//| "nothing" backup, and it never lets a challenger displace a champion  |
//| without both re-clearing the same durability bar C01 already          |
//| established (reusing C01_MIN_WINDOWS rather than inventing a second   |
//| threshold for the same concept -- INV-08) and beating the champion's  |
//| own worst-case (ciLow), not just its point estimate.                  |
//+-----------------------------------------------------------------------+
#property strict

#include "C01_EdgeAdjudicator.mqh"   // reuses C01_MIN_WINDOWS -- INV-08, one named constant per concept

#define C04_SCHEMA_VERSION 1
#define C04_MAGIC   0x43524731   // 'CRG1' (ChampionRegister v1)

//--- C04.S#### one champion/challenger snapshot: a config identity plus the
//--- same edge/CI/windowsUsed evidence shape C03/C01 already use, so this
//--- organ never invents a second way to describe "how good is this".
struct C04_Champion {
    string   configId;      // identifies the weight-set/config this snapshot represents
    int      regime;
    double   edge;
    double   ciLow;
    double   ciHigh;
    int      windowsUsed;
    datetime provenance;
    int      generation;    // increments once per successful promotion, audit trail
};

//--- C04.V#### promotion verdicts -- three-valued and total, same discipline
//--- as G01's REFUSE/BLOCK/PERMIT: distinguishes "no evidence" from "evidence
//--- says no" rather than collapsing both into one boolean.
enum C04_PromoteVerdict {
    C04_PROMOTE                  = 0,   // challenger clears both the durability floor and beats the champion's worst-case
    C04_REJECT_INSUFFICIENT      = 1,   // challenger has fewer than C01_MIN_WINDOWS powered windows -- no honest basis to compare at all
    C04_REJECT_NOT_BETTER        = 2    // challenger has enough evidence but does not durably beat the current champion
};

struct C04_RegisterState {
    bool         hasChampion;
    C04_Champion current;
    bool         hasBackup;
    C04_Champion backup;
    int          revertCount;
};

//+-----------------------------------------------------------------------+
//| C04.F0001 -- the organ's promotion decision. Pure: never mutates the  |
//| register itself (see C04_Promote for the mutating half) -- this split |
//| exists so a caller can ask "would this promote?" without committing,  |
//| exactly the same read/decide vs write/act separation every other      |
//| GENESIS organ keeps (e.g. C01 adjudicates, A02/O8 is what actually    |
//| acts on the adjudication).                                            |
//|                                                                       |
//| Bootstrap case (no champion registered yet): the challenger promotes  |
//| iff it clears the SAME durability floor a real champion would need    |
//| (>=C01_MIN_WINDOWS powered windows) AND its own ciLow>0 (a real,      |
//| significant edge, not merely "the first thing anyone measured") --    |
//| there is no "first challenger auto-wins" shortcut.                    |
//+-----------------------------------------------------------------------+
C04_PromoteVerdict C04_ShouldPromote(const C04_RegisterState &state, const C04_Champion &challenger, string &reason) {
    if(challenger.windowsUsed < C01_MIN_WINDOWS) {
        reason = StringFormat("REJECT_INSUFFICIENT: challenger has %d powered windows (need >=%d) -- no honest basis to compare",
                               challenger.windowsUsed, C01_MIN_WINDOWS);
        return C04_REJECT_INSUFFICIENT;
    }
    if(!state.hasChampion) {
        if(challenger.ciLow > 0.0) {
            reason = StringFormat("PROMOTE: bootstrap -- no champion registered yet, challenger clears durability (%d windows) and is significant (ciLow=%.4f>0)",
                                   challenger.windowsUsed, challenger.ciLow);
            return C04_PROMOTE;
        }
        reason = StringFormat("REJECT_NOT_BETTER: bootstrap challenger not significant (ciLow=%.4f<=0) -- no auto-win for being first",
                               challenger.ciLow);
        return C04_REJECT_NOT_BETTER;
    }
    // Durable improvement means beating the champion's WORST-CASE with the
    // challenger's WORST-CASE -- comparing point estimates (edge vs edge)
    // would let a lucky, wide-CI challenger displace a tight, proven
    // champion on noise; comparing ciLow vs ciLow does not.
    if(challenger.ciLow > state.current.ciLow) {
        reason = StringFormat("PROMOTE: challenger ciLow=%.4f beats champion ciLow=%.4f -- durable improvement, not point-estimate luck",
                               challenger.ciLow, state.current.ciLow);
        return C04_PROMOTE;
    }
    reason = StringFormat("REJECT_NOT_BETTER: challenger ciLow=%.4f does not beat champion ciLow=%.4f",
                           challenger.ciLow, state.current.ciLow);
    return C04_REJECT_NOT_BETTER;
}

//+-----------------------------------------------------------------------+
//| C04.F0002 -- the organ's one mutating promotion path. Re-runs         |
//| C04_ShouldPromote internally rather than trusting a caller's earlier  |
//| check -- there is no way to promote a challenger this function itself |
//| would refuse, matching G02 GateBus's "no override flag to compile"    |
//| discipline applied here to promotion instead of a safety gate.        |
//| The OLD current champion (if any) becomes the new backup -- this is   |
//| the literal mechanism that makes "every champion has a backup" true   |
//| by construction from the second promotion onward.                    |
//+-----------------------------------------------------------------------+
bool C04_Promote(C04_RegisterState &state, const C04_Champion &challenger, string &reason) {
    C04_PromoteVerdict v = C04_ShouldPromote(state, challenger, reason);
    if(v != C04_PROMOTE) return false;

    if(state.hasChampion) {
        state.backup = state.current;
        state.hasBackup = true;
    }
    state.current = challenger;
    state.current.generation = state.hasChampion ? state.current.generation + 1 : 1;
    state.hasChampion = true;
    return true;
}

//+-----------------------------------------------------------------------+
//| C04.F0003 -- regression detection. Compares the champion's LIVE,      |
//| freshly-observed performance (liveObserved -- same shape, re-measured |
//| after the champion has been running for a while) against the CI that |
//| justified its promotion in the first place. Deliberately asymmetric   |
//| and conservative: liveObserved.ciHigh (its best-case reading) must    |
//| fall below state.current.ciLow (the worst-case that justified         |
//| promotion) for regression to fire -- a live reading that merely       |
//| overlaps the original CI is normal sampling variance, not regression, |
//| and must not trigger a revert (an over-twitchy revert would itself be |
//| a new failure mode this organ must not introduce).                   |
//+-----------------------------------------------------------------------+
bool C04_DetectRegression(const C04_RegisterState &state, const C04_Champion &liveObserved, string &reason) {
    if(!state.hasChampion) {
        reason = "no champion registered -- nothing to regress";
        return false;
    }
    if(liveObserved.windowsUsed < C01_MIN_WINDOWS) {
        reason = StringFormat("live sample too small (%d windows, need >=%d) -- not enough evidence to call regression, avoids a twitchy revert",
                               liveObserved.windowsUsed, C01_MIN_WINDOWS);
        return false;
    }
    if(liveObserved.ciHigh < state.current.ciLow) {
        reason = StringFormat("REGRESSION: live best-case ciHigh=%.4f is below the champion's promotion-time worst-case ciLow=%.4f",
                               liveObserved.ciHigh, state.current.ciLow);
        return true;
    }
    reason = StringFormat("no regression: live ciHigh=%.4f still overlaps promotion-time ciLow=%.4f", liveObserved.ciHigh, state.current.ciLow);
    return false;
}

//+-----------------------------------------------------------------------+
//| C04.F0004 -- the organ's one revert path. Fails closed on the exact   |
//| case the invariant names as unsolved in the precedent: a champion     |
//| that has never been promoted-over-a-predecessor has no backup, and    |
//| this function REFUSES rather than silently no-op'ing or reverting to  |
//| an empty/zeroed champion, which would be worse than not reverting at  |
//| all (INV-04-style "fail closed" discipline, applied here to champion  |
//| state instead of order size).                                        |
//+-----------------------------------------------------------------------+
bool C04_AutoRevert(C04_RegisterState &state, string &reason) {
    if(!state.hasBackup) {
        reason = "REFUSE: regression detected but no backup exists -- this is the first-ever champion, cannot revert to nothing";
        return false;
    }
    C04_Champion regressed = state.current;
    state.current = state.backup;
    // The just-reverted-FROM configuration becomes the new backup rather
    // than being discarded -- a second consecutive regression (reverting
    // into another bad config) must still have somewhere to fall back to.
    state.backup = regressed;
    state.revertCount++;
    reason = StringFormat("REVERTED: restored champion generation=%d (configId=%s), revertCount now %d",
                           state.current.generation, state.current.configId, state.revertCount);
    return true;
}

//+-----------------------------------------------------------------------+
//| C04.F0005 -- THE single serializer, same writeMode-flag pattern C03   |
//| uses for the identical reason: one function body means a field added  |
//| to write and forgotten in read is not an available mistake (INV-02).  |
//+-----------------------------------------------------------------------+
void C04_SerializeChampion(int handle, bool writeMode, C04_Champion &c) {
    if(writeMode) {
        FileWriteString(handle, c.configId);
        FileWriteInteger(handle, c.regime);
        FileWriteDouble(handle, c.edge);
        FileWriteDouble(handle, c.ciLow);
        FileWriteDouble(handle, c.ciHigh);
        FileWriteInteger(handle, c.windowsUsed);
        FileWriteInteger(handle, (int)c.provenance);
        FileWriteInteger(handle, c.generation);
    } else {
        c.configId    = FileReadString(handle);
        c.regime      = FileReadInteger(handle);
        c.edge        = FileReadDouble(handle);
        c.ciLow       = FileReadDouble(handle);
        c.ciHigh      = FileReadDouble(handle);
        c.windowsUsed = FileReadInteger(handle);
        c.provenance  = (datetime)FileReadInteger(handle);
        c.generation  = FileReadInteger(handle);
    }
}

//+-----------------------------------------------------------------------+
//| C04.F0006 -- save the whole register (current + backup flags/records +|
//| revertCount). Magic+schema written first, same "detect format drift   |
//| before misreading a field" discipline as C03.                        |
//+-----------------------------------------------------------------------+
bool C04_SaveRegister(string filename, C04_RegisterState &state) {
    int h = FileOpen(filename, FILE_BIN | FILE_WRITE);
    if(h == INVALID_HANDLE) return false;
    FileWriteInteger(h, C04_MAGIC);
    FileWriteInteger(h, C04_SCHEMA_VERSION);
    FileWriteInteger(h, state.hasChampion ? 1 : 0);
    C04_SerializeChampion(h, true, state.current);
    FileWriteInteger(h, state.hasBackup ? 1 : 0);
    C04_SerializeChampion(h, true, state.backup);
    FileWriteInteger(h, state.revertCount);
    FileClose(h);
    return true;
}

//+-----------------------------------------------------------------------+
//| C04.F0007 -- load with magic/schema verification. Refuses whole on any|
//| mismatch, same fail-closed/never-half-trust discipline as C03_LoadLedger.|
//+-----------------------------------------------------------------------+
bool C04_LoadRegister(string filename, C04_RegisterState &outState, string &error) {
    error = "";
    if(!FileIsExist(filename)) { error = "file does not exist"; return false; }
    int h = FileOpen(filename, FILE_BIN | FILE_READ);
    if(h == INVALID_HANDLE) { error = "could not open file"; return false; }

    int magic = FileReadInteger(h);
    if(magic != C04_MAGIC) { FileClose(h); error = "magic marker mismatch -- not a GENESIS champion register"; return false; }
    int version = FileReadInteger(h);
    if(version != C04_SCHEMA_VERSION) { FileClose(h); error = StringFormat("schema version mismatch: file=%d expected=%d", version, C04_SCHEMA_VERSION); return false; }

    C04_RegisterState s;
    s.hasChampion = (FileReadInteger(h) != 0);
    C04_SerializeChampion(h, false, s.current);
    s.hasBackup = (FileReadInteger(h) != 0);
    C04_SerializeChampion(h, false, s.backup);
    s.revertCount = FileReadInteger(h);
    FileClose(h);

    outState = s;
    return true;
}

//+-----------------------------------------------------------------------+
//| G01 · ArmController                                                   |
//| GENESIS · CONSCIENCE system · organ 01                                |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                    |
//+-----------------------------------------------------------------------+
//| Purpose (GENESIS_MASTER_SPEC.md O10):                                 |
//|   Arm only on real, sufficient, durable evidence. Arms iff n>=30 AND  |
//|   durable AND not WF-fragile. n<30 -> never arms; WF-fragile ->       |
//|   blocks; small-n WR -> UNKNOWN (never evaluated as if it were real). |
//| Invariants enforced: INV-09 (arm only on >=30 OOS trades),            |
//|                       INV-10 (every safety gate is blocking).         |
//|                                                                       |
//| Intent, extracted from the precedent's own logged history (W-log      |
//| P5/P6, not copied): the exact incident INV-09 exists to make          |
//| structurally impossible -- a real run in this project's history       |
//| ARMED on a single OOS trade at a small-sample "fake" 100% win rate    |
//| (train 29.2% -> OOS 100%, a +70.8pp jump that a real n>=30 sample     |
//| would never let stand unchallenged). The precedent DID have an n>=30  |
//| power floor concept elsewhere (LE_DIAG_MIN_N) and a real n>=500       |
//| trading-weight floor (Prohibition #5) -- but the arming decision      |
//| itself, in that one logged incident, evaluated a win rate computed    |
//| from a single trade as if it were a trustworthy number.               |
//|                                                                       |
//| What changed, and why (Law 1: intent kept, structure discarded):      |
//|   G01_EvaluateArming checks n>=30 FIRST and returns REFUSE immediately|
//|   if it fails -- the ghost win-rate parameter is never even inspected |
//|   in that branch, so there is no code path in this organ where a      |
//|   small-n WR is treated as a real number (the structural form of      |
//|   "small-n WR -> UNKNOWN": the function refuses before it would ever  |
//|   need to interpret an unreliable WR at all).                         |
//+-----------------------------------------------------------------------+
#property strict
#include "..\GENESIS_Constants.mqh"
#include "..\GENESIS_Types.mqh"

#define G01_MIN_OOS_TRADES GENESIS_DIAGNOSTIC_POWER_FLOOR   // G01.K0001 -- matches this project's own established diagnostic power floor (LE_DIAG_MIN_N) -- INV-07: aliases the one shared concept, not a second literal 30

//--- G01.V#### the organ's one decisive verdict, three-valued and total.
enum G01_ArmVerdict {
    G01_REFUSE = 0,   // n<30 -- structurally cannot be evaluated, ghost WR never inspected
    G01_BLOCK  = 1,   // n>=30 but WF-fragile or not durable -- a real safety gate fired
    G01_PERMIT = 2    // n>=30 AND durable AND NOT WF-fragile -- arming is justified
};

//+----------------------------------------------------------------------+
//| G01.F0001 -- the organ's one entry point. Order of checks matters and|
//| is deliberate: the power floor is checked FIRST and unconditionally, |
//| before durability or fragility are even consulted -- this is what    |
//| makes "n<30 never arms" true regardless of how good ghostWR/durable  |
//| happen to look, rather than merely one of several ANDed conditions   |
//| that could theoretically be reordered by a future edit.              |
//+----------------------------------------------------------------------+
G01_ArmVerdict G01_EvaluateArming(int oosTradeCount, double ghostWR, bool durable, bool wfFragile, string &reason) {
    if(oosTradeCount < G01_MIN_OOS_TRADES) {
        reason = StringFormat("REFUSE: only %d OOS trades (need >=%d) -- win rate is UNKNOWN at this sample size, not evaluated", oosTradeCount, G01_MIN_OOS_TRADES);
        return G01_REFUSE;
    }
    if(wfFragile) {
        reason = "BLOCK: walk-forward fragile -- a real safety gate fired, no proceed-anyway path exists";
        return G01_BLOCK;
    }
    if(!durable) {
        reason = "BLOCK: edge not durable across independent windows";
        return G01_BLOCK;
    }
    reason = StringFormat("PERMIT: n=%d (>=%d), durable, not WF-fragile -- ghostWR=%.1f%% arms with real support", oosTradeCount, G01_MIN_OOS_TRADES, ghostWR);
    return G01_PERMIT;
}

//+-----------------------------------------------------------------------+
//| G01.F0002 -- INV-03 entry point, added pass_3 (GENESIS_Types.mqh). The |
//| richer sibling of F0001: takes a GENESIS_Rate instead of a raw double  |
//| ghostWR, so the win rate reaching this decision is STRUCTURALLY        |
//| guaranteed to carry the real n it was divided by (there is no way to   |
//| construct a GENESIS_Rate from a bare literal -- see that file's own    |
//| header). !isKnown REFUSES immediately, before oosTradeCount is even    |
//| inspected -- an evidence-carrying "we don't know the WR yet" and a     |
//| structural "not enough OOS trades" are the same REFUSE outcome for the |
//| same underlying reason (insufficient evidence), so this collapses to   |
//| F0001's exact behaviour once wrRate.isKnown is true, verified by the   |
//| acceptance test.                                                       |
//+-----------------------------------------------------------------------+
G01_ArmVerdict G01_EvaluateArmingFromRate(int oosTradeCount, const GENESIS_Rate &wrRate, bool durable, bool wfFragile, string &reason) {
    if(!wrRate.isKnown) {
        reason = "REFUSE: win rate is UNKNOWN (GENESIS_Rate carries no evidence) -- never evaluated as if it were a real number";
        return G01_REFUSE;
    }
    return G01_EvaluateArming(oosTradeCount, wrRate.value, durable, wfFragile, reason);
}

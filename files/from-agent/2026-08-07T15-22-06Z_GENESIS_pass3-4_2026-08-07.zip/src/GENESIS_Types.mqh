//+-----------------------------------------------------------------------+
//| GENESIS_Types -- the INV-03 shared rate type                          |
//| GENESIS · cross-cutting, depended on by all five systems, depends on  |
//| GENESIS_Constants.mqh only -- a near-leaf include, safe from every     |
//| organ regardless of build order, same placement rationale as that     |
//| file's own header.                                                    |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.3.0-dev                    |
//+-----------------------------------------------------------------------+
//| Purpose: closes INV-03, a real gap GENESIS_REGRESSION_PROOF.md's       |
//| pass_3 audit found and pass_2 had mis-described. INV-03's rule is      |
//| "every rate divides by its true observed count, never a constant       |
//| window literal," with enforcement "rate type requires an explicit n;   |
//| division by literal is banned by lint." Pass_1/pass_2 built 17 organs  |
//| that all CONSUME a rate (ghostWR, edge) as a caller-supplied double     |
//| parameter -- correct as far as it goes, but nothing in src/ actually    |
//| DEFINES what a rate is, so nothing stops a future caller from passing  |
//| a hardcoded literal in that slot. This file is the "rate type" the     |
//| invariant's own enforcement column names: a struct that CANNOT be      |
//| constructed without an explicit n, so a bare literal is structurally   |
//| impossible to hold in it, not merely discouraged.                     |
//|                                                                        |
//| Intent, extracted from the precedent (read directly, not copied):      |
//| WARRANT#124 is this invariant's own named origin -- g_Risk.recentWinRate|
//| once divided by a hardcoded /20.0 window size instead of the real,     |
//| possibly-smaller number of trades actually observed, understating WR   |
//| (and everything downstream: Kelly sizing, risk-mode gates) whenever     |
//| fewer than 20 live trades existed yet. GENESIS_REGRESSION_PROOF.md's   |
//| own INV-03 section confirms that specific historical bug is already    |
//| fixed upstream in the precedent copy GENESIS has -- but the GENERAL     |
//| failure class (a rate value floating around with no n attached, so a   |
//| caller CAN'T tell whether it's trustworthy) had no GENESIS-side        |
//| structural prevention until this file.                                 |
//|                                                                        |
//| What this is, precisely: GENESIS_Rate pairs a value with the n it was  |
//| computed from and a CI -- the exact {value,n,ci} shape INV-01's own     |
//| rule already names for win rates specifically, generalised here to any |
//| rate. The ONLY two ways to get one are GENESIS_UnknownRate() (n=0,      |
//| honestly not-yet-measurable) and GENESIS_ComputeRate(successes,n)       |
//| (divides by the REAL n passed in, always -- there is no second         |
//| constructor path that could divide by a literal instead).              |
//+-----------------------------------------------------------------------+
#ifndef GENESIS_TYPES_MQH
#define GENESIS_TYPES_MQH
#property strict
#include "GENESIS_Constants.mqh"

#define GENESIS_RATE_CI_Z GENESIS_CI_Z_95   // GENESIS.K0003 alias -- aliases GENESIS_Constants.mqh's own GENESIS_CI_Z_95 (INV-07: one meaning, one value, not a second literal 1.96 alongside C01_CI_Z)

//--- GENESIS.S#### a rate that carries its own evidence. value/ciLow/ciHigh
//--- are percentages [0,100]; isKnown=false means "not enough evidence to
//--- have an opinion," structurally distinct from "measured and happens to
//--- be low" (same EMPTY_VALUE-style honesty R01/C01 already established).
struct GENESIS_Rate {
    double value;
    int    n;
    double ciLow;
    double ciHigh;
    bool   isKnown;
};

//+-----------------------------------------------------------------------+
//| GENESIS.F0001 -- the honest "not yet measurable" rate. Never 0.0 or a  |
//| fabricated midpoint -- isKnown=false is the only field a caller needs  |
//| to check to refuse acting on it, same discipline as R01's EMPTY_VALUE. |
//+-----------------------------------------------------------------------+
GENESIS_Rate GENESIS_UnknownRate() {
    GENESIS_Rate r;
    r.value = EMPTY_VALUE; r.n = 0; r.ciLow = EMPTY_VALUE; r.ciHigh = EMPTY_VALUE; r.isKnown = false;
    return r;
}

//+-----------------------------------------------------------------------+
//| GENESIS.F0002 -- THE only way to construct a known rate. Divides by    |
//| the REAL n passed in -- there is no second code path anywhere in this  |
//| function, or this file, that could substitute a literal window size    |
//| instead (WARRANT#124's exact failure shape, made structurally          |
//| impossible to reproduce through this type: you cannot hold a           |
//| GENESIS_Rate whose value wasn't divided by its own attached n, because  |
//| the struct and this constructor are the only sanctioned way to produce |
//| one -- callers are not expected to build a GENESIS_Rate by hand).       |
//| n<=0 -> GENESIS_UnknownRate(): zero observations is never "0% rate",   |
//| it's "no basis for a rate claim at all."                              |
//| successes is clamped to [0,n] -- a caller passing a corrupt count      |
//| (e.g. more wins than trades) gets a refused/clamped result, not a      |
//| rate >100% or <0% silently propagated downstream.                     |
//+-----------------------------------------------------------------------+
GENESIS_Rate GENESIS_ComputeRate(int successes, int n) {
    if(n <= 0) return GENESIS_UnknownRate();
    int s = (int)MathMax(0, MathMin(n, successes));

    GENESIS_Rate r;
    r.n = n;
    double p = (double)s / (double)n;          // the real division this whole invariant exists to protect
    r.value = p * 100.0;
    r.isKnown = true;

    double se = MathSqrt(MathMax(0.0, p * (1.0 - p)) / (double)n);   // normal-approx standard error
    r.ciLow  = MathMax(0.0,   (p - GENESIS_RATE_CI_Z * se) * 100.0);
    r.ciHigh = MathMin(100.0, (p + GENESIS_RATE_CI_Z * se) * 100.0);
    return r;
}

//+-----------------------------------------------------------------------+
//| GENESIS.F0003 -- is this rate backed by enough evidence to be trusted  |
//| for a DIAGNOSTIC read (not yet a live-sizing decision -- see the       |
//| separate, higher GENESIS_TRADING_WEIGHT_FLOOR bar organs like A03/R04  |
//| already enforce for that). Reuses the one shared diagnostic-power-     |
//| floor concept (INV-07: no second definition of "enough to read").      |
//+-----------------------------------------------------------------------+
bool GENESIS_RateIsDiagnosticallyPowered(const GENESIS_Rate &r) {
    return r.isKnown && r.n >= (int)GENESIS_DIAGNOSTIC_POWER_FLOOR;
}

#endif // GENESIS_TYPES_MQH

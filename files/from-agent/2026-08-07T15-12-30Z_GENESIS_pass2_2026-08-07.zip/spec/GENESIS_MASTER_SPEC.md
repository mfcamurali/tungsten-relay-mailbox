# TUNGSTEN_LIMITLESS_QUANT
# GENESIS — Master Build Specification
## The Faultless Lab-Grown Build

**Precedent:** TUNGSTEN 10.28 / SLS(114) · 60,415 lines · 1,166 functions · 131 warrants of hard-won precedent
**This document:** 20 regression-locked invariants · 16 contracted organs · per-module acceptance tests before a line is written

> This is not a refactor. It is a clean-room successor built so that **not one failure in the entire precedent can recur** — each is converted into a permanent invariant the architecture makes structurally impossible. Every organ is designed once, contracted fully, and gated behind a test written before its code.

---

## 0 · Governing Doctrine

1. **The precedent is an oracle, never a template.** Not one line is copied forward. The old build supplies *intent* and *benchmark* only.
2. **Every logic is designed exactly once.** No organ may be patched into existence. Two mechanisms serving one intent are one organ, not two.
3. **Every past failure becomes a structural invariant.** A mistake that happened once must be made *impossible to compile*, not merely fixed.
4. **Test before code.** No module is written until its acceptance test exists and fails. Green is earned, never assumed.
5. **Walk-forward from birth.** No number is trusted in-sample. The single-split fitting that produced −37pp collapses does not exist in this codebase.
6. **The substrate is the climate.** The non-stationary search is built first; every organ is born expecting a moving edge.
7. **Honest or nothing.** A clean null is a first-class result. No mirage ever arms.

---

## 1 · The Invariant Ledger — every past mistake, permanently locked

Each invariant below traces to a real failure in the precedent (131 warrants + the 2026-08-06 live log). Each states the failure it forever prevents, the rule, the enforcement mechanism, and the regression test that proves it cannot return. **These are compile-time or CI-time guarantees, not guidelines.**

### INV-01 · No hardcoded win rate anywhere
- **Origin:** W#61
- **Failure forever prevented:** A win-rate function returned a constant (65%) after optimisation; every gate trusted fiction.
- **Invariant:** Every win-rate value is computed from observed outcomes with its sample size attached; a literal WR is a compile error.
- **Enforcement:** grep-lint bans numeric WR literals in signal paths; all WR carried as {value,n,ci}.
- **Regression test:** `test_no_wr_literal: source scan finds zero WR constants; unit asserts WR(n=0) returns UNKNOWN not a number.`

### INV-02 · Every stored field is read back
- **Origin:** W#116
- **Failure forever prevented:** SaveSystemState wrote g_CorrelationsLearned; LoadSystemState never read it — every restart shifted all later fields 4 bytes (root of the 595048703% WR).
- **Invariant:** Persistence is symmetric: a single serializer defines field order once; save and load share it. No field may be written without being read.
- **Enforcement:** One SERIALIZE(field) macro emits both directions; a schema hash is stored and verified on load.
- **Regression test:** `test_persistence_roundtrip: write→kill→load equality on every field; schema-hash mismatch aborts boot.`

### INV-03 · Win-rate denominators are never fixed
- **Origin:** W#124
- **Failure forever prevented:** recentWinRate divided by a hardcoded /20.0, understating WR for the first ~20 trades — feeding Kelly.
- **Invariant:** Every rate divides by its true observed count, never a constant window literal.
- **Enforcement:** Rate type requires an explicit n; division by literal is banned by lint.
- **Regression test:** `test_rate_denominator: recentWinRate(k trades) divides by k for all k<20; property test over k∈[1,50].`

### INV-04 · One hard risk floor, one chokepoint
- **Origin:** W#127
- **Failure forever prevented:** A range-trading order path bypassed the 7.5% ceiling entirely.
- **Invariant:** All orders route through a single PlaceOrder() chokepoint that clamps to HARD_FLOOR; no other code may call the broker.
- **Enforcement:** Broker API is private to one module; HARD_FLOOR is a compile-time const with no setter.
- **Regression test:** `test_hard_floor: fuzz every entry type × regime; assert realized risk ≤ HARD_FLOOR always; attempt-to-exceed test must throw.`

### INV-05 · Correct regime bracket, always
- **Origin:** W#123
- **Failure forever prevented:** Phase 2 signalPF used the wrong ATR bracket for 7 of 9 regimes.
- **Invariant:** The regime→bracket map is a single source of truth, asserted complete at compile time (all 9 regimes present, no duplicates).
- **Enforcement:** Static assert on map cardinality=9; bracket lookup is total, no default fallthrough.
- **Regression test:** `test_bracket_map: all 9 regimes resolve to distinct correct brackets; missing/duplicate regime fails build.`

### INV-06 · No Print-only decision path
- **Origin:** W#120/121/125/130
- **Failure forever prevented:** Retry-engine, calibration-verdict, and LE_Log were Print-only — invisible live; two 'is it frozen' scares; KEYS3 line never reached the feed.
- **Invariant:** Every decision/verdict routes through the one Logger spine to the live feed; raw Print is banned in decision code.
- **Enforcement:** Build-lint fails on Print( inside any function tagged @decision; Logger is the only sink.
- **Regression test:** `test_observability: static scan finds zero Print in decision paths; each verdict emits exactly one live-feed line.`

### INV-07 · No duplicate threshold floors
- **Origin:** W#119
- **Failure forever prevented:** Two fallback floors (50.0 and 18.0) for the same concept; the lower silently overwrote the higher.
- **Invariant:** Each concept has exactly one named constant; two constants for one meaning is a lint error.
- **Enforcement:** Named-constant registry; duplicate-value-same-domain check in CI.
- **Regression test:** `test_single_floor: registry has one floor per concept; grep finds no second literal in [18,50) for base threshold.`

### INV-08 · No duplicated magic numbers
- **Origin:** W#122/126
- **Failure forever prevented:** 19 duplicated 2.5/1.5 ATR-bracket literals could drift apart.
- **Invariant:** Every tunable is a single named constant referenced everywhere; repeated literals banned.
- **Enforcement:** Lint: numeric literals >1 occurrence in tuning domains must be constants.
- **Regression test:** `test_no_magic: scan asserts each ATR/threshold literal appears once, as a const definition.`

### INV-09 · Arm only on ≥30 OOS trades
- **Origin:** W-log P5/P6
- **Failure forever prevented:** ARMED on 1 OOS trade at a small-sample 'fake' 100% WR (train 29.2%→OOS 100%, +70.8pp).
- **Invariant:** Arming requires ≥30 independent OOS trades; ghost WR below that n is UNKNOWN, never a pass.
- **Enforcement:** armDecision() gates on n≥30 as a hard precondition; confidence scales with n.
- **Regression test:** `test_min_sample_arm: arm(n<30) always refuses regardless of WR; arm(n≥30, edge) permitted.`

### INV-10 · Every safety gate is blocking
- **Origin:** W-log Pre-Flight
- **Failure forever prevented:** Pre-Flight reported '1 gate incomplete — PROCEEDING'; the system armed despite a failed gate.
- **Invariant:** No proceed-anyway path exists. A failed safety gate stops the pipeline; WF-fragile blocks arming.
- **Enforcement:** Gate results are enum{PASS,BLOCK}; BLOCK halts; there is no override flag to compile.
- **Regression test:** `test_blocking_gates: any BLOCK halts pipeline in unit harness; assert no code path continues past BLOCK.`

### INV-11 · Evidence persists across restarts
- **Origin:** W#131
- **Failure forever prevented:** R-band win-rate evidence reset to zero every run.
- **Invariant:** All accumulated edge evidence is persisted with provenance and survives restart by construction.
- **Enforcement:** Evidence ledger is append-only, versioned, loaded on boot via INV-02 serializer.
- **Regression test:** `test_evidence_persist: accumulate→restart→evidence intact and monotonic; provenance non-null.`

### INV-12 · Confidence enters size exactly once
- **Origin:** forge-bestofboth
- **Failure forever prevented:** Stacked multipliers (Kelly×Slingshot×Sentinel) could multiply confidence more than once, cubing it.
- **Invariant:** size = kelly(edge) × confidence × dd_budget × (1/n_eff); confidence appears in exactly one factor.
- **Enforcement:** Single Size() function; static check that 'confidence' symbol is read once in the size expression.
- **Regression test:** `test_size_composition: symbolic check confidence-degree=1; DD and n_eff independent; min(size,FLOOR) applied last.`

### INV-13 · Correlated bets counted once
- **Origin:** charter-v2
- **Failure forever prevented:** Correlated micro-bets behaved as one bet; drawdown tripled at ρ=0.9.
- **Invariant:** Position count is n_eff derived from the live correlation matrix, not raw count.
- **Enforcement:** Size divides by n_eff; correlation matrix assumed ≥ measured (conservative).
- **Regression test:** `test_n_eff: at ρ→1, n_eff→1; DD bounded; conservative bias verified (n_eff ≤ raw n).`

### INV-14 · Walk-forward, never one split
- **Origin:** W-log P3B
- **Failure forever prevented:** One fixed in-sample→holdout split; gaps of −31 to −37pp; overfit passed.
- **Invariant:** Every edge is validated across independent rolling windows; single-split fitting does not exist in the codebase.
- **Enforcement:** Validator API only accepts a window sequence; a single-split call signature is not provided.
- **Regression test:** `test_walk_forward: edge accepted only if it survives ≥k disjoint windows; single-window acceptance impossible by API.`

### INV-15 · Match search to substrate
- **Origin:** W-log SYNTHESIS
- **Failure forever prevented:** Fixed-window linear search cannot capture time-varying structure (5/8 regimes, |t| up to 4.99) by design.
- **Invariant:** The substrate diagnostic selects the search: stationary→linear; time-varying→recency-weighted/curated-neural.
- **Enforcement:** Search method is dispatched on substrate class; no regime is searched with a mismatched method.
- **Regression test:** `test_substrate_dispatch: |t|>3 regimes route to time-aware search; stationary route to linear; mismatch impossible.`

### INV-16 · Every unattended script self-tests on boot
- **Origin:** infra
- **Failure forever prevented:** relay-listener dead 3 days (wrong pwsh path); watchdog missing; events feed broke silently for weeks.
- **Invariant:** Every daemon resolves paths dynamically, verifies feed freshness, confirms its backup, and self-tests before running.
- **Enforcement:** Boot self-test gate in each script; pwsh via Get-Command; freshness + backup asserted.
- **Regression test:** `test_daemon_selftest: each script's boot test fails fast on stale path/feed/backup; no silent-death path remains.`

### INV-17 · Champion auto-reverts on regression
- **Origin:** W#128/129
- **Failure forever prevented:** No auto-revert; a bad champion could persist; watchdog had no backup.
- **Invariant:** A new champion that underperforms the prior proven one auto-reverts; every champion has a backup.
- **Enforcement:** Champion register keeps last-known-good; revert is automatic on regression signal.
- **Regression test:** `test_auto_revert: inject regression → system reverts to prior champion; backup always exists.`

### INV-18 · 'No edge' is a first-class verdict
- **Origin:** W#118
- **Failure forever prevented:** Null results were ambiguous — human had to decide flat-signal vs uncapturable-structure by hand 3×.
- **Invariant:** Every 'no edge' verdict is auto-annotated with cause (genuinely flat vs time-varying-uncapturable) and its statistics.
- **Enforcement:** SynthesizeVerdict() emits cause + substrate stats natively on every regularized run.
- **Regression test:** `test_verdict_annotation: every no-edge output carries a cause enum and t-stat; no bare 'equal weights'.`

### INV-19 · Cost subtracted at measurement
- **Origin:** W-log P2
- **Failure forever prevented:** Cost was accounted with the wrong bracket; gross edge that dies to spread looked real.
- **Invariant:** Every edge number is net of the live spread/ATR cost at the point it is computed, per regime.
- **Enforcement:** Edge = grossEdge − cost(regime); no gross edge is ever surfaced.
- **Regression test:** `test_net_of_cost: reported edge always ≤ gross by cost; regime with cost>edge reports negative, never hidden.`

### INV-20 · One regime classifier, one taxonomy
- **Origin:** architecture
- **Failure forever prevented:** Three overlapping classifiers (BIAS/PATTERN/STRUCTURE) could disagree on the regime.
- **Invariant:** A single classifier owns the 9-regime taxonomy and emits a soft-membership vector; no second classifier exists.
- **Enforcement:** One RegimeState module; all consumers read its output; no parallel classifier compiles.
- **Regression test:** `test_single_classifier: only one module emits regime; soft-membership sums to 1; no consumer computes its own regime.`

---

## 2 · The Anatomy — five systems, sixteen organs

Same skeleton as the precedent; every organ redesigned once. Data flows **Perception → Cognition → Action**, policed by **Conscience**, all growing inside the **Substrate**.

```
           PERCEPTION (roots)  ──►  COGNITION (trunk)  ──►  ACTION (limbs)
                 │                       │                      │
                 └───────────►  CONSCIENCE (canopy)  ◄──────────┘
                            all growing within
                          SUBSTRATE (the climate)
```

---

## 3 · Organ Contracts — full specification per logic

Every organ is specified as a contract: **purpose · inputs · post-conditions (guarantees) · failure modes · invariants enforced · acceptance test.** No organ ships until its acceptance test is written first and passes on walk-forward data.

### Perception (The Roots)

#### O1 · RegimeState
- **Purpose:** Own the 9-regime taxonomy; emit soft-membership + confidence.
- **Inputs:** OHLC stream, ATR, session clock
- **Guarantees (post-conditions):** Returns p[9] summing to 1 with calibrated confidence; deterministic for a given bar.
- **Failure modes handled:** Ambiguous regime → returns max-entropy vector, never a guess; stale data → REFUSE.
- **Invariants enforced:** INV-20
- **Acceptance test (written first):** `Given labeled fixtures, argmax matches ≥ baseline; membership sums to 1±1e-9; stale bar → REFUSE.`

#### O2 · FeatureBank
- **Purpose:** Provide only features with proven out-of-sample separation.
- **Inputs:** RegimeState, price features
- **Guarantees (post-conditions):** Every feature exposes live OOS AUC; AUC<0.52 → auto-retired.
- **Failure modes handled:** A degrading feature is retired mid-run, not trusted; no feature is assumed discriminative.
- **Invariants enforced:** INV-01
- **Acceptance test (written first):** `Inject a noise feature → retired within window; AUC computed OOS only; retired features never feed Cognition.`

#### O3 · CostModel
- **Purpose:** Report net-of-spread edge per regime.
- **Inputs:** live spread, ATR, regime
- **Guarantees (post-conditions):** edge_net = edge_gross − cost(regime); always ≤ gross.
- **Failure modes handled:** Wrong bracket impossible (map asserted complete); cost>edge → negative surfaced.
- **Invariants enforced:** INV-05, INV-19
- **Acceptance test (written first):** `All 9 brackets distinct+present; reported edge ≤ gross; high-cost regime reports negative openly.`

### Cognition (The Trunk)

#### O4 · EdgeAdjudicator
- **Purpose:** Decide per regime whether a durable edge exists, with CI.
- **Inputs:** FeatureBank, CostModel, WalkForward windows
- **Guarantees (post-conditions):** Returns {edge, ci, verdict∈{EDGE,NONE}} scored OOS only.
- **Failure modes handled:** In-sample-only acceptance impossible (API takes windows); NONE is first-class.
- **Invariants enforced:** INV-14, INV-18
- **Acceptance test (written first):** `Overfit fixture → NONE with cause; durable fixture → EDGE surviving k windows; single-split call won't compile.`

#### O5 · OverfitImmune
- **Purpose:** One unified trust score from WF-gap, resample, CSCV.
- **Inputs:** candidate weights, windows
- **Guarantees (post-conditions):** Returns trust∈[0,1]; trust<τ → reject to equal weights.
- **Failure modes handled:** Any single guard failing lowers trust; no candidate bypasses all three.
- **Invariants enforced:** INV-14
- **Acceptance test (written first):** `PBO>0.5 or gap>8pp or resample-divergent → trust<τ → rejected; healthy candidate passes all three.`

#### O6 · EvidenceLedger
- **Purpose:** Persist per-regime edge evidence across restarts.
- **Inputs:** adjudicated outcomes
- **Guarantees (post-conditions):** Append-only, versioned, provenance-tagged; survives restart.
- **Failure modes handled:** Never resets; corruption caught by schema hash (INV-02).
- **Invariants enforced:** INV-11, INV-02
- **Acceptance test (written first):** `Accumulate→kill→reload intact+monotonic; tampered ledger fails schema hash and refuses load.`

### Action (The Limbs)

#### O7 · SizeEngine
- **Purpose:** Compose position size; confidence exactly once.
- **Inputs:** edge, confidence, dd_budget, n_eff
- **Guarantees (post-conditions):** size = kelly(edge)×confidence×dd_budget×(1/n_eff), then min(size,FLOOR).
- **Failure modes handled:** Confidence-degree>1 impossible (checked); size never exceeds FLOOR.
- **Invariants enforced:** INV-12, INV-13, INV-04
- **Acceptance test (written first):** `Symbolic confidence-degree=1; ρ→1 ⇒ n_eff→1; size ≤ FLOOR under fuzz.`

#### O8 · OrderGate
- **Purpose:** The single broker chokepoint; enforce HARD_FLOOR.
- **Inputs:** sized order
- **Guarantees (post-conditions):** Clamps to HARD_FLOOR; is the only code that calls the broker.
- **Failure modes handled:** No other path to broker compiles; over-floor attempt throws.
- **Invariants enforced:** INV-04
- **Acceptance test (written first):** `Every entry type routes here; realized risk ≤ FLOOR always; direct-broker call elsewhere fails build.`

#### O9 · GraduatedDeploy
- **Purpose:** Trade micro from bar 1, scaled by accumulated confidence.
- **Inputs:** EvidenceLedger, SizeEngine
- **Guarantees (post-conditions):** Deployment size = smooth f(confidence); no binary stand-down.
- **Failure modes handled:** Zero-evidence → micro probe only, never full; never all-or-nothing.
- **Invariants enforced:** INV-12
- **Acceptance test (written first):** `From cold start, size rises smoothly with evidence; no step discontinuity; never full-size on n<30.`

### Conscience (The Canopy)

#### O10 · ArmController
- **Purpose:** Arm only on real, sufficient, durable evidence.
- **Inputs:** OOS trade count, ghost WR, WF-fragility
- **Guarantees (post-conditions):** Arms iff n≥30 AND durable AND not WF-fragile.
- **Failure modes handled:** n<30 → never arms; WF-fragile → blocks; small-n WR → UNKNOWN.
- **Invariants enforced:** INV-09, INV-10
- **Acceptance test (written first):** `arm(n<30)→refuse; arm(WF-fragile)→block; arm(n≥30,durable)→permit.`

#### O11 · GateBus
- **Purpose:** All safety gates, blocking, no override.
- **Inputs:** gate results
- **Guarantees (post-conditions):** Any BLOCK halts pipeline; no proceed-anyway path exists.
- **Failure modes handled:** Override flag cannot be compiled; incomplete gate = BLOCK.
- **Invariants enforced:** INV-10
- **Acceptance test (written first):** `Injected BLOCK halts; search for override path returns nothing; incomplete gate treated as BLOCK.`

#### O12 · Logger
- **Purpose:** The one observability spine.
- **Inputs:** any decision event
- **Guarantees (post-conditions):** Every verdict emits exactly one live-feed line; Print banned in decisions.
- **Failure modes handled:** A silent decision cannot exist; build fails on raw Print in @decision.
- **Invariants enforced:** INV-06
- **Acceptance test (written first):** `Every @decision emits one line; static scan finds zero Print; feed shows all verdicts live.`

#### O13 · SelfDiagnosis
- **Purpose:** Annotate every null with its cause.
- **Inputs:** adjudication result, substrate stats
- **Guarantees (post-conditions):** 'No edge' carries cause∈{FLAT,TIME-VARYING} + t-stat.
- **Failure modes handled:** No bare 'equal weights' output; cause always present.
- **Invariants enforced:** INV-18
- **Acceptance test (written first):** `Every no-edge line carries cause+stat; flat vs time-varying correctly distinguished on fixtures.`

### Substrate (The Climate)

#### O14 · SubstrateDiagnostic
- **Purpose:** Classify each regime's stationarity.
- **Inputs:** per-regime window series
- **Guarantees (post-conditions):** Emits class∈{STATIONARY,TIME-VARYING,UNKNOWN} + flips + |t|.
- **Failure modes handled:** Drives search dispatch; UNKNOWN handled explicitly, never assumed stationary.
- **Invariants enforced:** INV-15, INV-18
- **Acceptance test (written first):** `Sign-flip fixture→TIME-VARYING; stable→STATIONARY; sparse→UNKNOWN; feeds dispatch.`

#### O15 · SearchDispatcher
- **Purpose:** Choose the search method per substrate class.
- **Inputs:** SubstrateDiagnostic, candidate space
- **Guarantees (post-conditions):** STATIONARY→linear; TIME-VARYING→recency/curated-neural; deterministic mapping.
- **Failure modes handled:** Mismatched method impossible; every regime searched with the right tool.
- **Invariants enforced:** INV-15
- **Acceptance test (written first):** `Dispatch table total over classes; |t|>3 never linear-searched; audited per run.`

#### O16 · TimeAwareSizing
- **Purpose:** Size into a fresh edge, decay as it ages.
- **Inputs:** EvidenceLedger freshness, dwell
- **Guarantees (post-conditions):** size scales with edge freshness; decays with evidence age.
- **Failure modes handled:** Never a full regime behind; stale edge → shrinking size.
- **Invariants enforced:** INV-12, INV-11
- **Acceptance test (written first):** `Freshness↑→size↑; age↑→size↓; estimator lag bounded below one dwell.`

---

## 4 · Build Order — the seven movements

The successor is constructed in one coherent pass, in this exact order, because each stage's contracts depend on the prior stage's guarantees:

1. **Exhume intent** — extract the striving-for behind every precedent organ (done: the intent map).
2. **Draw the skeleton** — fix the five systems and their interface contracts before any organ body is written.
3. **Wire the Substrate first** — O14/O15/O16, so every downstream organ is born expecting a moving edge (INV-15).
4. **Build Perception** — O1–O3, the honest read (INV-01/05/19/20).
5. **Build Cognition** — O4–O6, adjudication on walk-forward only (INV-14/18/11/02).
6. **Build Action** — O7–O9, continuous sizing through one chokepoint (INV-12/13/04).
7. **Make Conscience structural** — O10–O13 woven into the skeleton, not bolted on (INV-06/09/10/18).

Each movement ends with its acceptance tests green on independent windows, and a regression run against the precedent (§6).

---

## 5 · Test-First Protocol

For **every** module, in order, no exceptions:

```
1. WRITE the acceptance test from the contract's guarantees + failure modes.
2. RUN it — it must FAIL (red). A test that passes before code is a broken test.
3. WRITE the minimal organ body to its single coherent spec.
4. RUN — green on walk-forward fixtures, not in-sample.
5. ATTACH the invariant regression tests (§1) that this organ touches.
6. RATCHET — lock; any future change must keep every attached test green.
```

**A module without a failing-first test does not get written.** This is the mechanism by which no mistake repeats: the test for each historical failure exists before the code that could reintroduce it.

---

## 6 · Acceptance Against the Precedent

The old build is the benchmark. Genesis ships an organ only when it **matches or beats the precedent's proven behavior with a fraction of the surface area.** Regression against 10.28 is the final gate:

- **Behavioral parity:** on identical historical bars, Genesis's verdicts are at least as conservative and as accurate as 10.28's on every gate it already passed.
- **Invariant superiority:** every one of the 20 invariants holds in Genesis and is *demonstrably violable* in 10.28 (the test that fails on the old build passes on the new).
- **Surface reduction:** ~1,166 functions and ~529 globals collapse toward the 16 contracted organs; every remaining function traces to exactly one organ.

---

## 7 · Definition of Done

Genesis is complete for a cycle when:
- All 20 invariants are enforced at compile/CI time, each with a green regression test that fails on the precedent.
- All 16 organs pass their acceptance tests on independent walk-forward windows.
- Arming is impossible below 30 OOS trades; no safety gate is advisory; the hard floor is uncrossable from every path.
- The Substrate dispatches search by stationarity class; no time-varying regime is linear-searched.
- Every decision is on the live feed; zero Print-only paths; every daemon self-tests on boot.
- A regression run against 10.28 shows behavioral parity-or-better with a fraction of the surface area.

Until every invariant test is green **and** one root phase shows a durable walk-forward edge, Genesis is *structurally perfect but not yet proven profitable* — and it will say so, honestly, in its own feed. Perfection of construction is the promise. The edge remains the market's to give.

---

*TUNGSTEN_LIMITLESS_QUANT · GENESIS · the faultless lab-grown build · built from the precedent of TUNGSTEN 10.28 / SLS(114) · same skeleton, top-1% organs, every logic designed once, not one mistake repeated.*
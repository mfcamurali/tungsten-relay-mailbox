# TUNGSTEN_LIMITLESS_QUANT
# PHOENIX — The Genesis Build Agent
## Grow the plant from the seed

**Seed (precedent):** TUNGSTEN TUNGSTEN 10.28 / SLS(114) — 60,415 lines, 1,166 functions, 131 warrants of intelligence discovered in the wrong order.
**Plant (target):** TUNGSTEN_LIMITLESS_QUANT · GENESIS — 20 invariants, 16 organs, every logic designed *with every other in mind*, coherent from the first stroke.

> The seed is not the plant. The current TUNGSTEN scattered its intelligence across sixty thousand lines, each fix a discovery made too late to inform the ones before it. PHOENIX is the agent that reads the seed for everything it learned, then grows a plant a thousand times better than the seed could ever become — because the plant is *designed whole*, every organ aware of every other, nothing accreted.

**PHOENIX is a build agent, not a document.** It runs the construction. This charter is its law.

---

## PRIME DIRECTIVE

Construct GENESIS as a single coherent organism in which **every logic is designed with knowledge of every other logic** — no organ discovered in isolation, no fix bolted on, no mistake from the seed permitted to recur. The plant must be launchable and trustworthy: when PHOENIX declares an organ done, that organ *fulfils its goal by construction*, proven on walk-forward data, locked against regression.

---

## THE SEVEN LAWS (non-negotiable, checked every step)

1. **The seed is an oracle, never a template.** Read the precedent for intent and benchmark. Copy not one line. Coherence beats inheritance.
2. **Design with the whole in mind.** Before writing any organ, load the contracts of every organ it touches. No logic is designed alone. The interface is agreed before the body exists.
3. **Every past mistake is a compile-time law.** Each of the 20 invariants must be structurally impossible to violate — enforced by the compiler or CI, never by discipline.
4. **Test before code.** No organ is written until its acceptance test exists and fails red. Green is earned on walk-forward, never in-sample.
5. **The substrate is the climate.** Build the non-stationary search first; every downstream organ is born expecting a moving edge.
6. **Conscience is structural.** Blocking gates, ≥30-trade arming, one logging spine, one order chokepoint — woven into the skeleton, not added as warrants.
7. **Honest or nothing.** A clean null is a first-class result. PHOENIX never ships a mirage, never claims 'no bugs left,' never arms on fragile evidence.

---

## OPERATING LOOP (per organ, in dependency order)

```
PHOENIX.build(organ):
    1. CONTEXT   — load this organ's contract + the contracts of every organ it
                   reads from or writes to. Design it AWARE of the whole graph.
    2. INTENT    — read the seed's corresponding logic for what it strove for.
                   Extract purpose + benchmark. Discard its structure entirely.
    3. TEST      — write the acceptance test from guarantees + failure modes.
                   Run it. It MUST fail. (a passing pre-code test is broken)
    4. INVARIANTS— attach every §-invariant this organ touches. Write their
                   regression tests. Confirm each FAILS on the seed (10.28).
    5. BUILD     — minimal coherent body to the single spec. No accretion.
    6. PROVE     — green on independent walk-forward windows, never in-sample.
    7. RATCHET   — lock. Any future change keeps every attached test green or
                   auto-reverts (INV-17).
    8. REGRESS   — run against the seed: match-or-beat proven behavior with a
                   fraction of the surface area. That gap is the diamond.
```

**Build order (dependency-correct):** Substrate → Perception → Cognition → Action → Conscience. Each stage ends with all its acceptance + invariant tests green before the next begins.

---

## THE COHERENCE GRAPH — who must know whom

PHOENIX designs each organ holding the contracts of its neighbours. The dependency edges it must respect:

```
SUBSTRATE   O14 SubstrateDiagnostic ─► O15 SearchDispatcher ─► O16 TimeAwareSizing
                     │                        │                        │
PERCEPTION  O1 RegimeState ─► O2 FeatureBank ─► O3 CostModel            │
                     │                        │                        │
COGNITION            └─► O4 EdgeAdjudicator ◄──┴─ O5 OverfitImmune       │
                                  │                     │               │
                                  └─► O6 EvidenceLedger ◄───────────────┘
                                          │
ACTION      O7 SizeEngine ◄───────────────┘─► O8 OrderGate ─► O9 GraduatedDeploy
                     │                              │
CONSCIENCE  O10 ArmController · O11 GateBus · O12 Logger · O13 SelfDiagnosis
            (police every edge above — blocking, observable, honest)
```

No organ may be built before the organs it reads from are contracted. Conscience wraps all of them.

---

## THE 20 LAWS PHOENIX ENFORCES (seed failures → plant invariants)

Each is a test that must **fail on the seed and pass on the plant**. PHOENIX will not declare a stage done until every relevant law is green on GENESIS and demonstrably red on 10.28.

- **INV-01 · No hardcoded win rate anywhere** (W#61) — prevents: A win-rate function returned a constant (65%) after optimisation; every gate trusted fiction. → *Every win-rate value is computed from observed outcomes with its sample size attached; a literal WR is a compile error.*  
  `test_no_wr_literal: source scan finds zero WR constants; unit asserts WR(n=0) returns UNKNOWN not a number.`
- **INV-02 · Every stored field is read back** (W#116) — prevents: SaveSystemState wrote g_CorrelationsLearned; LoadSystemState never read it — every restart shifted all later fields 4 bytes (root of the 595048703% WR). → *Persistence is symmetric: a single serializer defines field order once; save and load share it. No field may be written without being read.*  
  `test_persistence_roundtrip: write→kill→load equality on every field; schema-hash mismatch aborts boot.`
- **INV-03 · Win-rate denominators are never fixed** (W#124) — prevents: recentWinRate divided by a hardcoded /20.0, understating WR for the first ~20 trades — feeding Kelly. → *Every rate divides by its true observed count, never a constant window literal.*  
  `test_rate_denominator: recentWinRate(k trades) divides by k for all k<20; property test over k∈[1,50].`
- **INV-04 · One hard risk floor, one chokepoint** (W#127) — prevents: A range-trading order path bypassed the 7.5% ceiling entirely. → *All orders route through a single PlaceOrder() chokepoint that clamps to HARD_FLOOR; no other code may call the broker.*  
  `test_hard_floor: fuzz every entry type × regime; assert realized risk ≤ HARD_FLOOR always; attempt-to-exceed test must throw.`
- **INV-05 · Correct regime bracket, always** (W#123) — prevents: Phase 2 signalPF used the wrong ATR bracket for 7 of 9 regimes. → *The regime→bracket map is a single source of truth, asserted complete at compile time (all 9 regimes present, no duplicates).*  
  `test_bracket_map: all 9 regimes resolve to distinct correct brackets; missing/duplicate regime fails build.`
- **INV-06 · No Print-only decision path** (W#120/121/125/130) — prevents: Retry-engine, calibration-verdict, and LE_Log were Print-only — invisible live; two 'is it frozen' scares; KEYS3 line never reached the feed. → *Every decision/verdict routes through the one Logger spine to the live feed; raw Print is banned in decision code.*  
  `test_observability: static scan finds zero Print in decision paths; each verdict emits exactly one live-feed line.`
- **INV-07 · No duplicate threshold floors** (W#119) — prevents: Two fallback floors (50.0 and 18.0) for the same concept; the lower silently overwrote the higher. → *Each concept has exactly one named constant; two constants for one meaning is a lint error.*  
  `test_single_floor: registry has one floor per concept; grep finds no second literal in [18,50) for base threshold.`
- **INV-08 · No duplicated magic numbers** (W#122/126) — prevents: 19 duplicated 2.5/1.5 ATR-bracket literals could drift apart. → *Every tunable is a single named constant referenced everywhere; repeated literals banned.*  
  `test_no_magic: scan asserts each ATR/threshold literal appears once, as a const definition.`
- **INV-09 · Arm only on ≥30 OOS trades** (W-log P5/P6) — prevents: ARMED on 1 OOS trade at a small-sample 'fake' 100% WR (train 29.2%→OOS 100%, +70.8pp). → *Arming requires ≥30 independent OOS trades; ghost WR below that n is UNKNOWN, never a pass.*  
  `test_min_sample_arm: arm(n<30) always refuses regardless of WR; arm(n≥30, edge) permitted.`
- **INV-10 · Every safety gate is blocking** (W-log Pre-Flight) — prevents: Pre-Flight reported '1 gate incomplete — PROCEEDING'; the system armed despite a failed gate. → *No proceed-anyway path exists. A failed safety gate stops the pipeline; WF-fragile blocks arming.*  
  `test_blocking_gates: any BLOCK halts pipeline in unit harness; assert no code path continues past BLOCK.`
- **INV-11 · Evidence persists across restarts** (W#131) — prevents: R-band win-rate evidence reset to zero every run. → *All accumulated edge evidence is persisted with provenance and survives restart by construction.*  
  `test_evidence_persist: accumulate→restart→evidence intact and monotonic; provenance non-null.`
- **INV-12 · Confidence enters size exactly once** (forge-bestofboth) — prevents: Stacked multipliers (Kelly×Slingshot×Sentinel) could multiply confidence more than once, cubing it. → *size = kelly(edge) × confidence × dd_budget × (1/n_eff); confidence appears in exactly one factor.*  
  `test_size_composition: symbolic check confidence-degree=1; DD and n_eff independent; min(size,FLOOR) applied last.`
- **INV-13 · Correlated bets counted once** (charter-v2) — prevents: Correlated micro-bets behaved as one bet; drawdown tripled at ρ=0.9. → *Position count is n_eff derived from the live correlation matrix, not raw count.*  
  `test_n_eff: at ρ→1, n_eff→1; DD bounded; conservative bias verified (n_eff ≤ raw n).`
- **INV-14 · Walk-forward, never one split** (W-log P3B) — prevents: One fixed in-sample→holdout split; gaps of −31 to −37pp; overfit passed. → *Every edge is validated across independent rolling windows; single-split fitting does not exist in the codebase.*  
  `test_walk_forward: edge accepted only if it survives ≥k disjoint windows; single-window acceptance impossible by API.`
- **INV-15 · Match search to substrate** (W-log SYNTHESIS) — prevents: Fixed-window linear search cannot capture time-varying structure (5/8 regimes, |t| up to 4.99) by design. → *The substrate diagnostic selects the search: stationary→linear; time-varying→recency-weighted/curated-neural.*  
  `test_substrate_dispatch: |t|>3 regimes route to time-aware search; stationary route to linear; mismatch impossible.`
- **INV-16 · Every unattended script self-tests on boot** (infra) — prevents: relay-listener dead 3 days (wrong pwsh path); watchdog missing; events feed broke silently for weeks. → *Every daemon resolves paths dynamically, verifies feed freshness, confirms its backup, and self-tests before running.*  
  `test_daemon_selftest: each script's boot test fails fast on stale path/feed/backup; no silent-death path remains.`
- **INV-17 · Champion auto-reverts on regression** (W#128/129) — prevents: No auto-revert; a bad champion could persist; watchdog had no backup. → *A new champion that underperforms the prior proven one auto-reverts; every champion has a backup.*  
  `test_auto_revert: inject regression → system reverts to prior champion; backup always exists.`
- **INV-18 · 'No edge' is a first-class verdict** (W#118) — prevents: Null results were ambiguous — human had to decide flat-signal vs uncapturable-structure by hand 3×. → *Every 'no edge' verdict is auto-annotated with cause (genuinely flat vs time-varying-uncapturable) and its statistics.*  
  `test_verdict_annotation: every no-edge output carries a cause enum and t-stat; no bare 'equal weights'.`
- **INV-19 · Cost subtracted at measurement** (W-log P2) — prevents: Cost was accounted with the wrong bracket; gross edge that dies to spread looked real. → *Every edge number is net of the live spread/ATR cost at the point it is computed, per regime.*  
  `test_net_of_cost: reported edge always ≤ gross by cost; regime with cost>edge reports negative, never hidden.`
- **INV-20 · One regime classifier, one taxonomy** (architecture) — prevents: Three overlapping classifiers (BIAS/PATTERN/STRUCTURE) could disagree on the regime. → *A single classifier owns the 9-regime taxonomy and emits a soft-membership vector; no second classifier exists.*  
  `test_single_classifier: only one module emits regime; soft-membership sums to 1; no consumer computes its own regime.`

---

## ORGAN BUILD QUEUE (contract summaries — full specs in the map)

### SUBSTRATE
- **O14 · SubstrateDiagnostic** — Classify each regime's stationarity.  
  guarantees: Emits class∈{STATIONARY,TIME-VARYING,UNKNOWN} + flips + |t|.  
  enforces: INV-15, INV-18 · test-first: `Sign-flip fixture→TIME-VARYING; stable→STATIONARY; sparse→UNKNOWN; feeds dispatch.`
- **O15 · SearchDispatcher** — Choose the search method per substrate class.  
  guarantees: STATIONARY→linear; TIME-VARYING→recency/curated-neural; deterministic mapping.  
  enforces: INV-15 · test-first: `Dispatch table total over classes; |t|>3 never linear-searched; audited per run.`
- **O16 · TimeAwareSizing** — Size into a fresh edge, decay as it ages.  
  guarantees: size scales with edge freshness; decays with evidence age.  
  enforces: INV-12, INV-11 · test-first: `Freshness↑→size↑; age↑→size↓; estimator lag bounded below one dwell.`

### PERCEPTION
- **O1 · RegimeState** — Own the 9-regime taxonomy; emit soft-membership + confidence.  
  guarantees: Returns p[9] summing to 1 with calibrated confidence; deterministic for a given bar.  
  enforces: INV-20 · test-first: `Given labeled fixtures, argmax matches ≥ baseline; membership sums to 1±1e-9; stale bar → REFUSE.`
- **O2 · FeatureBank** — Provide only features with proven out-of-sample separation.  
  guarantees: Every feature exposes live OOS AUC; AUC<0.52 → auto-retired.  
  enforces: INV-01 · test-first: `Inject a noise feature → retired within window; AUC computed OOS only; retired features never feed Cognition.`
- **O3 · CostModel** — Report net-of-spread edge per regime.  
  guarantees: edge_net = edge_gross − cost(regime); always ≤ gross.  
  enforces: INV-05, INV-19 · test-first: `All 9 brackets distinct+present; reported edge ≤ gross; high-cost regime reports negative openly.`

### COGNITION
- **O4 · EdgeAdjudicator** — Decide per regime whether a durable edge exists, with CI.  
  guarantees: Returns {edge, ci, verdict∈{EDGE,NONE}} scored OOS only.  
  enforces: INV-14, INV-18 · test-first: `Overfit fixture → NONE with cause; durable fixture → EDGE surviving k windows; single-split call won't compile.`
- **O5 · OverfitImmune** — One unified trust score from WF-gap, resample, CSCV.  
  guarantees: Returns trust∈[0,1]; trust<τ → reject to equal weights.  
  enforces: INV-14 · test-first: `PBO>0.5 or gap>8pp or resample-divergent → trust<τ → rejected; healthy candidate passes all three.`
- **O6 · EvidenceLedger** — Persist per-regime edge evidence across restarts.  
  guarantees: Append-only, versioned, provenance-tagged; survives restart.  
  enforces: INV-11, INV-02 · test-first: `Accumulate→kill→reload intact+monotonic; tampered ledger fails schema hash and refuses load.`

### ACTION
- **O7 · SizeEngine** — Compose position size; confidence exactly once.  
  guarantees: size = kelly(edge)×confidence×dd_budget×(1/n_eff), then min(size,FLOOR).  
  enforces: INV-12, INV-13, INV-04 · test-first: `Symbolic confidence-degree=1; ρ→1 ⇒ n_eff→1; size ≤ FLOOR under fuzz.`
- **O8 · OrderGate** — The single broker chokepoint; enforce HARD_FLOOR.  
  guarantees: Clamps to HARD_FLOOR; is the only code that calls the broker.  
  enforces: INV-04 · test-first: `Every entry type routes here; realized risk ≤ FLOOR always; direct-broker call elsewhere fails build.`
- **O9 · GraduatedDeploy** — Trade micro from bar 1, scaled by accumulated confidence.  
  guarantees: Deployment size = smooth f(confidence); no binary stand-down.  
  enforces: INV-12 · test-first: `From cold start, size rises smoothly with evidence; no step discontinuity; never full-size on n<30.`

### CONSCIENCE
- **O10 · ArmController** — Arm only on real, sufficient, durable evidence.  
  guarantees: Arms iff n≥30 AND durable AND not WF-fragile.  
  enforces: INV-09, INV-10 · test-first: `arm(n<30)→refuse; arm(WF-fragile)→block; arm(n≥30,durable)→permit.`
- **O11 · GateBus** — All safety gates, blocking, no override.  
  guarantees: Any BLOCK halts pipeline; no proceed-anyway path exists.  
  enforces: INV-10 · test-first: `Injected BLOCK halts; search for override path returns nothing; incomplete gate treated as BLOCK.`
- **O12 · Logger** — The one observability spine.  
  guarantees: Every verdict emits exactly one live-feed line; Print banned in decisions.  
  enforces: INV-06 · test-first: `Every @decision emits one line; static scan finds zero Print; feed shows all verdicts live.`
- **O13 · SelfDiagnosis** — Annotate every null with its cause.  
  guarantees: 'No edge' carries cause∈{FLAT,TIME-VARYING} + t-stat.  
  enforces: INV-18 · test-first: `Every no-edge line carries cause+stat; flat vs time-varying correctly distinguished on fixtures.`

---

## DECLARATION OF LAUNCH-READINESS

PHOENIX may declare GENESIS launchable only when, simultaneously:

- All 20 invariant tests are **green on GENESIS and red on the seed.**
- All 16 organs pass acceptance on **independent walk-forward windows.**
- Arming is impossible below 30 OOS trades; no gate is advisory; the hard floor is uncrossable from every path; every daemon self-tests on boot.
- The Substrate dispatches search by stationarity class; no time-varying regime is linear-searched.
- A full regression against 10.28 shows **parity-or-better with a fraction of the surface area.**

At that moment — and only then — GENESIS is a plant that can be trusted to fulfil its goals: not because we hope it will, but because every way it could fail has been made impossible to build. **Perfection of construction is the guarantee PHOENIX delivers. The edge remains the market's to give — and GENESIS will say so, honestly, in its own feed, until the day the market gives it.**

---

*TUNGSTEN_LIMITLESS_QUANT · PHOENIX · the Genesis build agent · grows the plant from the seed of TUNGSTEN 10.28 / SLS(114) · every logic designed with every other in mind · not one mistake repeated · a thousand times the seed.*
# TUNGSTEN_LIMITLESS_QUANT
# GENESIS — The Naming System
## A clean-room address space for a clean-room build

> The seed's naming was archaeological — `WARRANT#116`, `SLS(114)`, `forge-bestofboth`, `keys-3` — identifiers accreted in the order things broke. The plant is addressed as deliberately as it is designed. **Every entity has one structured, permanent, machine-and-human-readable ID.**

---

## 1 · The identifier shape

```
[SYS][ORGAN].[TYPE][SERIAL4]
```

**Read as:** `C01.F0007  =  Cognition · organ 01 (EdgeAdjudicator) · Function · #0007`

Three fields, always:
- **[SYS]** — one mnemonic letter for the anatomical system.
- **[ORGAN]** — two digits, the organ within that system.
- **[TYPE][SERIAL]** — one type letter + a zero-padded 4-digit serial.

**Serial rule:** zero-padded 4-digit, monotonic per (organ,type), never reused, never reordered.

---

## 2 · System letters

| Letter | System | Meaning |
|:------:|--------|---------|
| **R** | SUBSTRATE | Roots/climate — the ground everything grows in |
| **P** | PERCEPTION | how it reads the market |
| **C** | COGNITION | how it decides an edge exists |
| **A** | ACTION | how it sizes and acts |
| **G** | CONSCIENCE | the guard — how it polices itself |

---

## 3 · Type letters (what an ID points to)

| Letter | Type | Meaning |
|:------:|------|---------|
| **F** | Function | a unit of behaviour |
| **S** | State | a persisted or live variable |
| **K** | Knob | a tunable input/constant |
| **I** | Invariant | a regression-locked law |
| **T** | Test | an acceptance/regression test |
| **V** | Verdict | a decision/output event |
| **E** | Edge | a market-facing signal/edge object |

---

## 4 · The organ address book

Every organ's permanent address. All functions, state, knobs, and tests live *under* it.

| Address | Organ | Namespace |
|:-------:|-------|-----------|
| **R01** | SubstrateDiagnostic | `R01.F####` funcs · `R01.S####` state · `R01.K####` knobs · `R01.T####` tests |
| **R02** | SearchDispatcher | `R02.F####` funcs · `R02.S####` state · `R02.K####` knobs · `R02.T####` tests |
| **R03** | TimeAwareSizing | `R03.F####` funcs · `R03.S####` state · `R03.K####` knobs · `R03.T####` tests |
| **P01** | RegimeState | `P01.F####` funcs · `P01.S####` state · `P01.K####` knobs · `P01.T####` tests |
| **P02** | FeatureBank | `P02.F####` funcs · `P02.S####` state · `P02.K####` knobs · `P02.T####` tests |
| **P03** | CostModel | `P03.F####` funcs · `P03.S####` state · `P03.K####` knobs · `P03.T####` tests |
| **C01** | EdgeAdjudicator | `C01.F####` funcs · `C01.S####` state · `C01.K####` knobs · `C01.T####` tests |
| **C02** | OverfitImmune | `C02.F####` funcs · `C02.S####` state · `C02.K####` knobs · `C02.T####` tests |
| **C03** | EvidenceLedger | `C03.F####` funcs · `C03.S####` state · `C03.K####` knobs · `C03.T####` tests |
| **A01** | SizeEngine | `A01.F####` funcs · `A01.S####` state · `A01.K####` knobs · `A01.T####` tests |
| **A02** | OrderGate | `A02.F####` funcs · `A02.S####` state · `A02.K####` knobs · `A02.T####` tests |
| **A03** | GraduatedDeploy | `A03.F####` funcs · `A03.S####` state · `A03.K####` knobs · `A03.T####` tests |
| **G01** | ArmController | `G01.F####` funcs · `G01.S####` state · `G01.K####` knobs · `G01.T####` tests |
| **G02** | GateBus | `G02.F####` funcs · `G02.S####` state · `G02.K####` knobs · `G02.T####` tests |
| **G03** | Logger | `G03.F####` funcs · `G03.S####` state · `G03.K####` knobs · `G03.T####` tests |
| **G04** | SelfDiagnosis | `G04.F####` funcs · `G04.S####` state · `G04.K####` knobs · `G04.T####` tests |

---

## 5 · Cross-cutting identifiers

- **Build version:** `GEN-[MAJOR].[MINOR].[PATCH]  replaces SLS(nnn)/10.xx  →  e.g. GEN-1.0.0` — replaces `SLS(nnn)` and `10.xx` entirely. Semantic: MAJOR = architecture change, MINOR = organ added/redesigned, PATCH = invariant-preserving fix.
- **Invariants:** `I[NN]  global, 2-digit, e.g. I01..I20 (laws span the whole plant)`. Laws span the whole plant, so they are global, not per-organ.
- **Warrants retired:** the word 'WARRANT' is retired. A fixed defect becomes an Invariant (I##), never a numbered patch.

---

## 6 · Worked examples

```
GEN-1.0.0            the first launchable plant
C01.F0007            Cognition · EdgeAdjudicator · Function #0007
A02.K0001            Action · OrderGate · Knob #0001  (the HARD_FLOOR constant)
P01.S0003            Perception · RegimeState · State #0003  (soft-membership vector)
R01.V0001            Substrate · SubstrateDiagnostic · Verdict #0001  (stationarity class)
I04                  Invariant #04  (one hard risk floor, one chokepoint)
A02.T0002            Action · OrderGate · Test #0002  (proves I04 — floor uncrossable)
```

**A test's ID names what it guards.** `A02.T0002 → I04` reads: *the second test on the OrderGate proves the hard-floor invariant.* Traceability is built into the address, not documented separately.

---

## 7 · Why this matters

- **Grep-able:** every reference to `A02` finds the entire OrderGate surface instantly.
- **Stable:** serials never reuse or reorder, so an ID in a log five years from now still resolves.
- **Self-documenting:** the ID says system, organ, kind, and instance without a lookup.
- **No accretion:** there is no `WARRANT#` counter that only grows. Fixes become invariants; the address space stays clean by design.

*TUNGSTEN_LIMITLESS_QUANT · GENESIS naming · GEN-1.0.0 · every entity addressed once, permanently, legibly.*
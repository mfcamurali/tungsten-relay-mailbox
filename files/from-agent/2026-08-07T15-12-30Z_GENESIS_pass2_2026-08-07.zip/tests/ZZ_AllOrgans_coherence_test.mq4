//+----------------------------------------------------------------------+
//| ZZ.T0001 -- whole-codebase coherence check, pass_1 close-out         |
//|                                                                      |
//| Includes every GENESIS organ built this pass in ONE translation unit.|
//| Each organ compiled clean in isolation (paired only with its own     |
//| dependencies) -- this is the first time all of them exist together in|
//| the same namespace at once, which is the only way to catch a symbol  |
//| collision (two organs accidentally defining the same function/macro/ |
//| struct name) that isolated per-organ compiles cannot see.            |
//+----------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Substrate\R01_SubstrateDiagnostic.mqh"
#include "..\src\Substrate\R02_SearchDispatcher.mqh"
#include "..\src\Substrate\R03_TimeAwareSizing.mqh"
#include "..\src\Substrate\R04_CuratedNeuralNet.mqh"
#include "..\src\Perception\P01_RegimeState.mqh"
#include "..\src\Perception\P02_FeatureBank.mqh"
#include "..\src\Perception\P03_CostModel.mqh"
#include "..\src\Cognition\C01_EdgeAdjudicator.mqh"
#include "..\src\Cognition\C02_OverfitImmune.mqh"
#include "..\src\Cognition\C03_EvidenceLedger.mqh"
#include "..\src\Action\A01_SizeEngine.mqh"
#include "..\src\Action\A02_OrderGate.mqh"
#include "..\src\Action\A03_GraduatedDeploy.mqh"
#include "..\src\Conscience\G01_ArmController.mqh"
#include "..\src\Conscience\G02_GateBus.mqh"
#include "..\src\Conscience\G03_Logger.mqh"
#include "..\src\Conscience\G04_SelfDiagnosis.mqh"

//+--------------------------------------------------------------------+
//| A minimal end-to-end smoke composition: wires every system's real  |
//| entry point into one flow (Substrate -> Perception -> Cognition -> |
//| Action, policed by Conscience) to prove the interfaces genuinely   |
//| compose, not just that each file compiles standalone. This is NOT a|
//| claim of a validated trading decision -- fixture data, not real    |
//| market data -- it proves the PLUMBING is coherent end to end.      |
//+--------------------------------------------------------------------+
void OnStart() {
    Print("=== ZZ.T0001 whole-codebase coherence smoke test -- start ===");

    // SUBSTRATE: classify a synthetic time-varying series, dispatch a search method.
    R01_Series series; R01_ZeroSeries(series);
    double subMean[5] = { 0.3, -0.3, 0.3, -0.3, 0.3 };
    for(int w = 0; w < 5; w++) for(int i = 0; i < 40; i++) R01_Accumulate(series, subMean[w], w);
    R01_Verdict substrateVerdict = R01_Classify(series, 0.0);
    R02_SearchMethod method = R02_Dispatch(substrateVerdict);
    PrintFormat("  Substrate: class=%s flips=%d method=%s", R01_ClassName(substrateVerdict.classOut), substrateVerdict.flips, R02_MethodName(method));

    // PERCEPTION: a regime belief update and a cost-net edge.
    P01_BeliefVector prior = P01_UniformBelief();
    double lr[9] = {2,1,1,1,1,1,1,1,1};
    P01_Verdict regimeVerdict = P01_Classify(prior, lr, 0.85, true);
    P03_ResetBracketMap();
    string bErr; for(int r = 0; r < 9; r++) P03_SetBracket(r, 1.5, 2.5, bErr);
    P03_CostReport cost = P03_NetEdge(0.4, 10.0, 0.0001, 0.0020);
    PrintFormat("  Perception: dominant regime=%d conf=%.3f netEdge=%.4f", regimeVerdict.dominant, regimeVerdict.confidence, cost.edgeNet);

    // COGNITION: adjudicate a durable-looking multi-window edge, screen it for overfit.
    C01_WindowResult windows[5];
    windows[0].meanReturnATR = 0.35; windows[0].n = 40;
    windows[1].meanReturnATR = 0.30; windows[1].n = 45;
    windows[2].meanReturnATR = 0.40; windows[2].n = 38;
    windows[3].meanReturnATR = 0.32; windows[3].n = 42;
    windows[4].meanReturnATR = 0.38; windows[4].n = 41;
    C01_Adjudication adjudication = C01_Adjudicate(windows);
    C02_TrustResult trust = C02_Evaluate(3.0, false, 0.15);
    PrintFormat("  Cognition: verdict=%d edge=%.4f trust=%.3f rejected=%s", adjudication.verdict, adjudication.edge, trust.trust, trust.rejected ? "true":"false");

    // CONSCIENCE, on the cognition output: diagnose if NONE, gate the pipeline, log it.
    G04_Diagnosis diag = G04_Diagnose(adjudication, substrateVerdict);
    G02_Gate gates[2];
    gates[0].name = "overfit-immune"; gates[0].result = trust.rejected ? G02_GATE_BLOCK : G02_PASS;
    gates[1].name = "edge-adjudicator"; gates[1].result = (adjudication.verdict == C01_EDGE) ? G02_PASS : G02_GATE_BLOCK;
    G02_BusVerdict busVerdict = G02_Evaluate(gates);
    G03_LogVerdict("ZZ.SmokeTest", StringFormat("pipeline verdict=%s diag=%s", busVerdict.allPass ? "PASS":"BLOCKED", diag.narrative));

    // ACTION, only reached conceptually here (not gated by a real ArmController
    // decision in this smoke test -- that needs G01, exercised next).
    string armReason;
    G01_ArmVerdict armVerdict = G01_EvaluateArming(150, 62.0, adjudication.verdict == C01_EDGE, trust.rejected, armReason);
    double deployFactor = A03_DeploymentFactor(150);
    double size = A01_ComposeSize(MathMax(0.0, cost.edgeNet), 0.01, regimeVerdict.confidence * deployFactor, 1.0, 1, 0.0);
    A02_GateDecision orderGate = A02_Gate(size);
    PrintFormat("  Conscience+Action: arm=%d deployFactor=%.4f composedSize=%.4f gatedSize=%.4f",
                armVerdict, deployFactor, size, orderGate.approvedRiskPercent);

    Print("=== ZZ.T0001 GREEN if this compiled and ran without error -- full Substrate->Perception->Cognition->Action->Conscience plumbing is coherent end to end (fixture data, not a validated trading result) ===");
}

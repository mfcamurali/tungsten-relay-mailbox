//+------------------------------------------------------------------+
//| R03.T0001 -- acceptance test for R03 TimeAwareSizing             |
//| GENESIS test-first protocol (GENESIS_MASTER_SPEC.md sec.5)       |
//|                                                                  |
//| Contract under test (GENESIS_MASTER_SPEC.md O16):                |
//|   "Freshness up -> size up; age up -> size down; estimator lag   |
//|    bounded below one dwell."                                     |
//|                                                                  |
//| Read-only diagnostic script, same posture as R01.T0001/R02.T0001.|
//+------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Substrate\R03_TimeAwareSizing.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  R03.T0001  ", name); }
    else     { g_fail++; Print("FAIL  R03.T0001  ", name, "  -- ", detail); }
}

//+---------------------------------------------------------------------+
//| "age up -> size down": monotonic decay as evidence ages, for a fixed|
//| dwell and base confidence.                                          |
//+---------------------------------------------------------------------+
void Test_AgeUpSizeDown() {
    double baseConf = 1.0, dwell = 100.0;
    double sPrev = R03_ApplyFreshnessDecay(baseConf, 0.0, dwell);
    bool monotonic = true;
    double ages[5] = { 10, 25, 50, 100, 200 };
    for(int i = 0; i < 5; i++) {
        double s = R03_ApplyFreshnessDecay(baseConf, ages[i], dwell);
        if(s > sPrev + 1e-12) monotonic = false;   // must never increase as age increases
        sPrev = s;
    }
    Check("size strictly non-increasing as age increases (fixed dwell)",
          monotonic, "a later (older) age produced a larger sized output than an earlier one");

    double sFresh = R03_ApplyFreshnessDecay(baseConf, 0.0, dwell);
    double sStale = R03_ApplyFreshnessDecay(baseConf, 200.0, dwell);
    Check("stale evidence (age=200, dwell=100) sizes strictly below fresh evidence",
          sStale < sFresh, StringFormat("fresh=%.4f stale=%.4f", sFresh, sStale));
}

//+----------------------------------------------------------------------+
//| "Freshness up -> size up": freshness is the inverse of age at a fixed|
//| dwell -- confirm the same relationship from the other direction, and |
//| confirm a fixed age against different dwells (relatively fresher, in |
//| dwell-normalised terms, when dwell is longer) sizes higher too.      |
//+----------------------------------------------------------------------+
void Test_FreshnessUpSizeUp() {
    double baseConf = 1.0, fixedAge = 20.0;
    // Longer dwell at the same absolute age = relatively fresher (less of
    // the state's natural cycle has elapsed) -> should size higher.
    double sShortDwell = R03_ApplyFreshnessDecay(baseConf, fixedAge, 40.0);
    double sLongDwell  = R03_ApplyFreshnessDecay(baseConf, fixedAge, 400.0);
    Check("same absolute age is sized higher against a longer (relatively fresher) dwell",
          sLongDwell > sShortDwell,
          StringFormat("short-dwell=%.4f long-dwell=%.4f", sShortDwell, sLongDwell));

    double sZeroAge = R03_ApplyFreshnessDecay(baseConf, 0.0, 100.0);
    Check("zero-age (maximally fresh) evidence sizes at full base confidence",
          MathAbs(sZeroAge - baseConf) < 1e-9,
          StringFormat("got %.6f, expected %.6f", sZeroAge, baseConf));
}

//+----------------------------------------------------------------------+
//| "estimator lag bounded below one dwell": the half-life itself (F0002)|
//| must be strictly less than the dwell period for any positive dwell,  |
//| and evidence exactly one dwell old must already be discounted well   |
//| below full trust -- "never a full regime behind."                    |
//+----------------------------------------------------------------------+
void Test_LagBoundedBelowOneDwell() {
    double dwells[4] = { 10.0, 50.0, 100.0, 1000.0 };
    bool allBounded = true;
    for(int i = 0; i < 4; i++) {
        double lag = R03_EstimatorLag(dwells[i]);
        if(!(lag < dwells[i])) allBounded = false;
    }
    Check("estimator lag (half-life) is strictly below one dwell period, for every tested dwell",
          allBounded, "at least one dwell produced a lag >= the dwell itself");

    double sOneDwellOld = R03_ApplyFreshnessDecay(1.0, 100.0, 100.0);
    Check("evidence exactly one dwell old is discounted well below full trust (<=0.30)",
          sOneDwellOld <= 0.30,
          StringFormat("got %.4f -- a full dwell behind is not being treated as stale", sOneDwellOld));
}

//+-----------------------------------------------------------------+
//| Failure mode: no valid dwell estimate must never be treated as  |
//| "assume fresh" -- fails toward zero, not toward full confidence.|
//+-----------------------------------------------------------------+
void Test_NoDwellFailsTowardZero() {
    double s = R03_ApplyFreshnessDecay(1.0, 0.0, 0.0);   // dwell<=0: no basis for a freshness claim
    Check("missing dwell estimate (dwell<=0) fails toward zero confidence, never full trust",
          s == 0.0, StringFormat("got %.6f", s));
}

void OnStart() {
    Print("=== R03.T0001 TimeAwareSizing acceptance test -- start ===");
    Test_AgeUpSizeDown();
    Test_FreshnessUpSizeUp();
    Test_LagBoundedBelowOneDwell();
    Test_NoDwellFailsTowardZero();
    PrintFormat("=== R03.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("R03.T0001 GREEN -- O16 TimeAwareSizing meets its acceptance contract.");
    else            Print("R03.T0001 RED -- see FAIL lines above.");
}

//+-------------------------------------------------------------------+
//| A01.T0001 -- acceptance test for A01 SizeEngine                   |
//| Contract under test (GENESIS_MASTER_SPEC.md O7):                  |
//|   "Symbolic confidence-degree=1; rho->1 => n_eff->1; size <= FLOOR|
//|    under fuzz."                                                   |
//| Read-only diagnostic script, same posture as prior GENESIS tests. |
//+-------------------------------------------------------------------+
#property strict
#property script_show_confirm false

#include "..\src\Action\A01_SizeEngine.mqh"

int g_pass = 0, g_fail = 0;

void Check(string name, bool cond, string detail) {
    if(cond) { g_pass++; Print("PASS  A01.T0001  ", name); }
    else     { g_fail++; Print("FAIL  A01.T0001  ", name, "  -- ", detail); }
}

//+-----------------------------------------------------------------------+
//| "confidence-degree=1": since MQL4 offers no symbolic algebra, this is |
//| tested the honest empirical equivalent -- size scales EXACTLY         |
//| linearly with confidence (doubling confidence exactly doubles size,   |
//| all else fixed), which is only true if confidence appears to the      |
//| first power exactly once, not squared/cubed by a hidden second factor.|
//+-----------------------------------------------------------------------+
void Test_ConfidenceDegreeOne() {
    double edge = 0.5, variance = 0.01, ddBudget = 1.0; int rawN = 1; double corr = 0.0;
    double sizeAtHalf = A01_ComposeSize(edge, variance, 0.20, ddBudget, rawN, corr);
    double sizeAtFull = A01_ComposeSize(edge, variance, 0.40, ddBudget, rawN, corr);
    Check("doubling confidence (0.20->0.40) exactly doubles size (confidence enters to the first power, once)",
          MathAbs(sizeAtFull - 2.0 * sizeAtHalf) < 1e-9,
          StringFormat("sizeAtHalf=%.6f sizeAtFull=%.6f ratio=%.4f", sizeAtHalf, sizeAtFull, sizeAtFull / MathMax(1e-9, sizeAtHalf)));

    double sizeAtQuarter = A01_ComposeSize(edge, variance, 0.10, ddBudget, rawN, corr);
    Check("confidence scaling is linear across 3 points (0.10/0.20/0.40), not quadratic",
          MathAbs(sizeAtHalf - 2.0 * sizeAtQuarter) < 1e-9,
          StringFormat("sizeAtQuarter=%.6f sizeAtHalf=%.6f", sizeAtQuarter, sizeAtHalf));
}

//+---------------------------------------------------------------------+
//| "rho->1 => n_eff->1": as average correlation approaches 1, effective|
//| bet count collapses to 1 regardless of raw N.                       |
//+---------------------------------------------------------------------+
void Test_RhoToOneCollapsesNEff() {
    double nEffLowCorr  = A01_EffectiveN(10, 0.0);
    double nEffHighCorr = A01_EffectiveN(10, 1.0);
    Check("rho=0 (independent) gives n_eff==raw N",
          MathAbs(nEffLowCorr - 10.0) < 1e-9, StringFormat("n_eff=%.4f", nEffLowCorr));
    Check("rho=1 (fully correlated) collapses n_eff to 1, regardless of raw N=10",
          MathAbs(nEffHighCorr - 1.0) < 1e-9, StringFormat("n_eff=%.4f", nEffHighCorr));

    double nEffN50HighCorr = A01_EffectiveN(50, 1.0);
    Check("rho=1 collapses n_eff to 1 even for a much larger raw N=50",
          MathAbs(nEffN50HighCorr - 1.0) < 1e-9, StringFormat("n_eff=%.4f", nEffN50HighCorr));

    Check("n_eff is always <= raw N (conservative bias) across a grid of N/rho",
          A01_EffectiveN(20, 0.3) <= 20.0 + 1e-9 && A01_EffectiveN(5, 0.7) <= 5.0 + 1e-9,
          "n_eff exceeded raw N for at least one combination");
}

//+--------------------------------------------------------------------+
//| "size <= FLOOR under fuzz": across a wide grid of inputs, including|
//| deliberately extreme/adversarial ones, size must never exceed the  |
//| hard floor.                                                        |
//+--------------------------------------------------------------------+
void Test_SizeNeverExceedsFloorUnderFuzz() {
    double edges[4]      = { 0.01, 0.5, 5.0, 100.0 };
    double variances[4]  = { 0.0001, 0.001, 0.01, 1.0 };
    double confidences[3]= { 0.1, 0.5, 1.0 };
    double ddBudgets[3]  = { 0.0, 0.5, 1.0 };
    int    rawNs[3]      = { 1, 5, 50 };
    double corrs[3]      = { 0.0, 0.5, 1.0 };

    bool allWithinFloor = true;
    double worst = 0.0;
    for(int a=0;a<4;a++) for(int b=0;b<4;b++) for(int c=0;c<3;c++)
    for(int d=0;d<3;d++) for(int e=0;e<3;e++) for(int f=0;f<3;f++) {
        double size = A01_ComposeSize(edges[a], variances[b], confidences[c], ddBudgets[d], rawNs[e], corrs[f]);
        if(size > A01_HARD_FLOOR_PERCENT + 1e-9) { allWithinFloor = false; if(size > worst) worst = size; }
    }
    Check("size never exceeds HARD_FLOOR across a full fuzz grid (incl. extreme edge/variance combos)",
          allWithinFloor, StringFormat("worst observed size=%.4f, floor=%.4f", worst, A01_HARD_FLOOR_PERCENT));
}

void Test_NeverNegative() {
    double size = A01_ComposeSize(-5.0, 0.01, 0.5, 1.0, 1, 0.0);   // negative edge
    Check("negative edge never produces a negative size (kelly abstains, size floors at 0)",
          size >= 0.0, StringFormat("size=%.6f", size));
}

void OnStart() {
    Print("=== A01.T0001 SizeEngine acceptance test -- start ===");
    Test_ConfidenceDegreeOne();
    Test_RhoToOneCollapsesNEff();
    Test_SizeNeverExceedsFloorUnderFuzz();
    Test_NeverNegative();
    PrintFormat("=== A01.T0001 result: %d passed, %d failed ===", g_pass, g_fail);
    if(g_fail == 0) Print("A01.T0001 GREEN -- O7 SizeEngine meets its acceptance contract.");
    else            Print("A01.T0001 RED -- see FAIL lines above.");
}

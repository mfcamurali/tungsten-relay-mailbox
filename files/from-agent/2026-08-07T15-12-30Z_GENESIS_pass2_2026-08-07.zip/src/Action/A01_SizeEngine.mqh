//+-----------------------------------------------------------------------+
//| A01 · SizeEngine                                                      |
//| GENESIS · ACTION system · organ 01                                    |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                    |
//+-----------------------------------------------------------------------+
//| Purpose (GENESIS_MASTER_SPEC.md O7):                                  |
//|   Compose position size; confidence exactly once.                     |
//|   size = kelly(edge) x confidence x dd_budget x (1/n_eff),            |
//|   then min(size, FLOOR).                                              |
//| Invariants enforced: INV-12 (confidence enters size exactly once),    |
//|                       INV-13 (correlated bets counted once),          |
//|                       INV-04 (one hard risk floor, one chokepoint).   |
//|                                                                       |
//| Intent, extracted from the precedent (read directly, not copied):     |
//| LE_ComputeCappedKellySize (~line 38122, WARRANT#44) is a real, sound  |
//| capped-fractional-Kelly formula: f = kappa*edge/variance, bounded     |
//| [0,cap] -- kept verbatim as this organ's kelly() sub-function, since  |
//| the math itself was never the problem. The problem WARRANT#109        |
//| (2026-08-02, forge-bestofboth) found and fixed: a SEPARATE confidence |
//| multiplier stack (regime/conviction/memory/predictive/validation/     |
//| awareness signals, bounded [0.50,2.50]) multiplied riskAmount AGAIN,  |
//| downstream of the already-Kelly-sized base risk, with neither stack   |
//| aware of the other -- worst case 7.5% x 2.5 = 18.75% realized risk    |
//| under legitimate in-range operation, silently exceeding the documented|
//| 7.5% ceiling. That is INV-12's own named origin, verbatim.            |
//| INV-13 (correlated bets counted once) traces to forge-bestofboth's own|
//| charter-v2 concept, not yet built anywhere in the precedent -- a      |
//| standard, citable effective-N-under-equicorrelation formula           |
//| (n_eff = N/(1+(N-1)*rho)) is used here, not invented.                 |
//|                                                                       |
//| What changed, and why (Law 1: intent kept, structure discarded):      |
//|   ONE function signature (A01_ComposeSize) with EXACTLY ONE           |
//|   confidence parameter, multiplied in EXACTLY ONE place in the        |
//|   formula -- there is no second parameter anywhere in this organ's    |
//|   API a caller could mistake for a second confidence signal to stack. |
//|   Whatever fed WARRANT#109's confidence-multiplier stack (regime/     |
//|   conviction/memory/predictive/validation/awareness) must be composed |
//|   INTO that one confidence value BEFORE calling this organ (same      |
//|   "compose upstream, never add a second factor here" discipline R03   |
//|   TimeAwareSizing's own header already establishes for freshness      |
//|   decay).                                                             |
//+-----------------------------------------------------------------------+
#property strict

//--- A01.K#### -- HARD_FLOOR is conceptually O8 OrderGate's own knob
//--- (A02.K0001 per GENESIS_NAMING_SYSTEM.md's worked example -- OrderGate
//--- is the single chokepoint that must enforce it on every path to the
//--- broker) -- but O7 SizeEngine's OWN contract also requires
//--- "min(size,FLOOR) applied last" as its final composition step, and a
//--- caller of THIS organ may never reach O8 at all if it discards O7's
//--- output early (e.g. a dry-run/diagnostic caller). Defining the
//--- constant here, once, and having A02_OrderGate.mqh #include this file
//--- to reuse the identical value (rather than redefining it) keeps
//--- INV-08 (no duplicated magic numbers) intact while still satisfying
//--- BOTH organs' own literal contracts -- a deliberate, documented
//--- deviation from the naming doc's implied file location, made for a
//--- concrete technical reason (avoiding two independent #define sites   |
//--- for the one number that must never drift apart).                   |
#define A01_HARD_FLOOR_PERCENT 7.5   // A02.K0001 -- matches this project's own documented, real ceiling (WARRANT#109)

//--- A01.K#### kelly sub-function knobs, matching the precedent's own
//--- proven defaults (KellyFraction=0.25 quarter-Kelly, cap language).
#define A01_KELLY_KAPPA_DEFAULT 0.25   // A01.K0001
#define A01_KELLY_CAP_DEFAULT   0.05   // A01.K0002 -- fraction of capital, matches precedent's LE_ComputeCappedKellySize default cap
#define A01_MIN_VARIANCE        0.0001 // A01.K0003 -- below this, kelly abstains (returns 0) rather than dividing by near-zero

//+----------------------------------------------------------------------+
//| A01.F0001 -- capped fractional-Kelly, kept from the precedent's real,|
//| sound formula verbatim (see header). Never negative -- an edge below |
//| zero returns 0, this never sizes a bet against its own measured      |
//| direction.                                                           |
//+----------------------------------------------------------------------+
double A01_Kelly(double edge, double varianceProxy, double kappa = A01_KELLY_KAPPA_DEFAULT, double cap = A01_KELLY_CAP_DEFAULT) {
    if(varianceProxy <= A01_MIN_VARIANCE) return 0.0;
    if(edge <= 0.0) return 0.0;
    double f = kappa * edge / varianceProxy;
    return MathMax(0.0, MathMin(cap, f));
}

//+----------------------------------------------------------------------+
//| A01.F0002 -- effective independent bet count under average pairwise  |
//| correlation rho, for N (raw, simultaneously-open) positions. Standard|
//| equicorrelation effective-N: n_eff = N/(1+(N-1)*rho).                |
//| rho is clamped to [0,1] -- a negative measured correlation is treated|
//| as zero here rather than allowed to INFLATE n_eff past N, which is   |
//| what "conservative bias" (n_eff<=N always) requires.                 |
//+----------------------------------------------------------------------+
double A01_EffectiveN(int rawN, double avgCorrelation) {
    if(rawN <= 0) return 0.0;
    double rho = MathMax(0.0, MathMin(1.0, avgCorrelation));
    double denom = 1.0 + (rawN - 1.0) * rho;
    double nEff = (denom > 1e-9) ? (rawN / denom) : (double)rawN;
    return MathMax(1.0, MathMin((double)rawN, nEff));
}

//+-----------------------------------------------------------------+
//| A01.F0003 -- drawdown-budget factor: fades linearly from 1.0 (no|
//| drawdown) to 0.0 as currentDDPercent approaches ddBudgetCeiling,|
//| matching the precedent's own documented KellyDDBudget behaviour |
//| ("drawdown %% at which risk fades to ~0").                      |
//+-----------------------------------------------------------------+
double A01_DDBudgetFactor(double currentDDPercent, double ddBudgetCeiling) {
    if(ddBudgetCeiling <= 0.0) return 0.0;
    double frac = 1.0 - (MathMax(0.0, currentDDPercent) / ddBudgetCeiling);
    return MathMax(0.0, MathMin(1.0, frac));
}

//+---------------------------------------------------------------------+
//| A01.F0004 -- the organ's one entry point. confidence appears in this|
//| expression EXACTLY ONCE, as a single multiplicative factor -- there |
//| is no second confidence-shaped parameter anywhere in this signature |
//| to accidentally stack (INV-12's structural guarantee: not policed by|
//| a later audit, made impossible by having only one place to put it). |
//| min(size,FLOOR) is applied as the LAST step, per the contract's own |
//| explicit ordering.                                                  |
//+---------------------------------------------------------------------+
double A01_ComposeSize(double edge, double varianceProxy, double confidence, double ddBudget, int rawN, double avgCorrelation,
                        double kappa = A01_KELLY_KAPPA_DEFAULT, double kellyCap = A01_KELLY_CAP_DEFAULT) {
    double kellySize   = A01_Kelly(edge, varianceProxy, kappa, kellyCap);
    double confClamped = MathMax(0.0, MathMin(1.0, confidence));
    double nEff         = A01_EffectiveN(rawN, avgCorrelation);
    double invNEff       = (nEff > 1e-9) ? (1.0 / nEff) : 0.0;

    double size = kellySize * confClamped * ddBudget * invNEff;
    return MathMax(0.0, MathMin(A01_HARD_FLOOR_PERCENT, size));
}

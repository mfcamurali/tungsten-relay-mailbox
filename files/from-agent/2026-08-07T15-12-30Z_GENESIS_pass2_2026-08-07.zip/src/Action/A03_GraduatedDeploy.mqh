//+-------------------------------------------------------------------------+
//| A03 · GraduatedDeploy                                                   |
//| GENESIS · ACTION system · organ 03                                      |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                      |
//+-------------------------------------------------------------------------+
//| Purpose (GENESIS_MASTER_SPEC.md O9):                                    |
//|   Trade micro from bar 1, scaled by accumulated confidence.             |
//|   Deployment size = smooth f(confidence); no binary stand-down.         |
//|   Zero-evidence -> micro probe only, never full; never all-or-nothing.  |
//| Invariant enforced: INV-12 (confidence enters size exactly once).       |
//|                                                                         |
//| Intent, extracted from the precedent (read directly, not copied):       |
//| the precedent's ENTIRE calibration history is a binary gate -- every    |
//| single completed run this project has ever logged ends either           |
//| "STAND DOWN" or "ARMED," nothing between (tungsten_live_run_diagnosis,  |
//| forge_cleanup3_seam_audit_session, tungsten_warrant80_bracket_fallback  |
//| memories, dozens of runs, always one of exactly two states). WARRANT#131|
//| (2026-08-06) took a real step toward the alternative: persistent,       |
//| restart-surviving accumulation of Keys-3 R-band win-rate evidence "so   |
//| thin per-run ghost-trade counts (1-10 typical) can eventually build     |
//| into a real sample instead of resetting every run" -- but nothing in    |
//| the precedent ever turned accumulated evidence into a CONTINUOUSLY      |
//| scaled deployment size; the live/dormant decision itself stayed         |
//| binary throughout.                                                      |
//|                                                                         |
//| What changed, and why (Law 1: intent kept, structure discarded):        |
//|   A03_DeploymentFactor(evidenceN) is a smoothstep (Hermite) ramp from   |
//|   a nonzero micro-probe floor at n=0 to full deployment at n>=500       |
//|   (the same trading-weight floor this project has used since its own    |
//|   "Prohibition #5") -- continuous and zero-derivative at both ends, so  |
//|   there is NO n value anywhere, including the precedent's old n=30      |
//|   diagnostic threshold, where deployment jumps discontinuously. This    |
//|   is the concrete, structural replacement for "STAND DOWN vs ARMED":    |
//|   the system is always trading SOMETHING (a real probe, never zero)     |
//|   and always scaling UP smoothly as real evidence accumulates, never    |
//|   waiting for one all-or-nothing gate to flip.                          |
//|                                                                         |
//|   INV-12 discipline: this organ's output is ONE CANDIDATE INPUT to a    |
//|   caller's single composed confidence value (same "compose upstream,    |
//|   feed the one confidence slot" pattern R03 TimeAwareSizing's own       |
//|   header already establishes) -- it is NOT a second multiplier          |
//|   applied on top of A01 SizeEngine's own confidence parameter. A        |
//|   caller multiplies this factor into whatever else composes             |
//|   confidence ONCE, upstream, before ever calling A01_ComposeSize.       |
//+-------------------------------------------------------------------------+
#property strict

#define A03_MICRO_PROBE_FLOOR   0.02    // A03.K0001 -- "trade micro from bar 1": never a true zero, even at n=0
#define A03_FULL_CONFIDENCE_N 500.0     // A03.K0002 -- matches this project's own established n>=500 trading-weight floor

//+-----------------------------------------------------------------------+
//| A03.F0001 -- classic Hermite smoothstep, 3t^2-2t^3, clamped to [0,1]. |
//| Standard, well-known interpolation curve (not invented here) chosen   |
//| specifically because its derivative is exactly zero at both edge0 and |
//| edge1 -- there is no kink anywhere along the curve, which is what     |
//| "no step discontinuity" requires structurally, not just approximately.|
//+-----------------------------------------------------------------------+
double A03_SmoothStep(double edge0, double edge1, double x) {
    if(edge1 <= edge0) return (x >= edge1) ? 1.0 : 0.0;
    double t = (x - edge0) / (edge1 - edge0);
    t = MathMax(0.0, MathMin(1.0, t));
    return t * t * (3.0 - 2.0 * t);
}

//+---------------------------------------------------------------------+
//| A03.F0002 -- the organ's one entry point. A smooth ramp from the    |
//| micro-probe floor (evidenceN=0) to full deployment (evidenceN>=500),|
//| continuous and monotonic non-decreasing everywhere in between.      |
//+---------------------------------------------------------------------+
double A03_DeploymentFactor(int evidenceN) {
    double n = (double)MathMax(0, evidenceN);
    double ramp = A03_SmoothStep(0.0, A03_FULL_CONFIDENCE_N, n);
    return A03_MICRO_PROBE_FLOOR + (1.0 - A03_MICRO_PROBE_FLOOR) * ramp;
}

//+-----------------------------------------------------------------------+
//| P03 · CostModel                                                       |
//| GENESIS · PERCEPTION system · organ 03                                |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                    |
//+-----------------------------------------------------------------------+
//| Purpose (GENESIS_MASTER_SPEC.md O3):                                  |
//|   Report net-of-spread edge per regime. edge_net = edge_gross -       |
//|   cost(regime); always <= gross. Wrong bracket impossible (map        |
//|   asserted complete); cost>edge -> negative surfaced openly.          |
//| Invariants enforced: INV-05 (correct regime bracket, always),         |
//|                       INV-19 (cost subtracted at measurement).        |
//|                                                                       |
//| Intent, extracted from the precedent (read directly, not copied):     |
//| g_RegimeOptimalSLMult[9]/g_RegimeOptimalTPMult[9] (~line 2092-2096)   |
//| are the real, Phase-3C-calibrated per-regime bracket -- but every one |
//| of 17+ call sites reads them through its OWN inline fallback pattern  |
//| ("(g_RegimeOptimalSLMult[r]>0) ? real : 1.5"), independently repeated |
//| rather than going through a single, asserted-complete accessor. This  |
//| is INV-08's own documented "duplicated truth" defect class (fixed     |
//| only partially, WARRANT#101/102, 3 of 17+ sites) AND the concrete     |
//| shape of INV-05's origin (W#123: Phase 2's signalPF used the wrong    |
//| bracket for 7 of 9 regimes) -- a silent fallback-to-default is exactly|
//| how "the wrong bracket" becomes possible without anyone choosing it.  |
//|                                                                       |
//| What changed, and why (Law 1: intent kept, structure discarded):      |
//|   ONE bracket map with ONE accessor (P03_GetBracket) that REFUSES to  |
//|   return anything -- for any regime, even a correctly-populated one --|
//|   until every one of the 9 slots is confirmed populated exactly once. |
//|   MQL4 has no true compile-time static assert, so this organ owns a   |
//|   construction-time completeness check instead: the honest, checkable |
//|   equivalent available in this environment (documented in             |
//|   genesis-phoenix's "honest constraint" section). No silent 1.5/2.5   |
//|   fallback exists anywhere in this organ's API.                       |
//+-----------------------------------------------------------------------+
#property strict

#define P03_REGIME_COUNT 9   // P03.K0001 -- same taxonomy width as P01; every bracket map traces to it

//--- P03.S#### one regime's calibrated bracket, plus whether it has ever
//--- actually been set (vs. a zero-initialised slot that only LOOKS set).
struct P03_Bracket {
    double slATR;
    double tpATR;
    bool   populated;
};

//--- P03.S#### the single source of truth for all 9 regimes' brackets.
//--- This organ legitimately owns persistent module state (unlike the
//--- pure-function Substrate organs) because "is the map complete" is
//--- inherently a cross-call, construction-time question -- deliberately
//--- not modelled as a pure function, and documented as such rather than
//--- forced into a shape that doesn't fit.
P03_Bracket g_P03_Map[P03_REGIME_COUNT];

//+--------------------------------------------------------------+
//| P03.F0001 -- clear the map (start a fresh construction pass).|
//+--------------------------------------------------------------+
void P03_ResetBracketMap() {
    for(int i = 0; i < P03_REGIME_COUNT; i++) { g_P03_Map[i].slATR = 0.0; g_P03_Map[i].tpATR = 0.0; g_P03_Map[i].populated = false; }
}

//+----------------------------------------------------------------------+
//| P03.F0002 -- set exactly one regime's bracket. Refuses (returns      |
//| false) on an out-of-range regime or a SECOND attempt to set a regime |
//| already populated -- "no duplicates" is enforced here, at write time,|
//| not discovered later by an inconsistency between two reads.          |
//+----------------------------------------------------------------------+
bool P03_SetBracket(int regime, double slATR, double tpATR, string &errorOut) {
    if(regime < 0 || regime >= P03_REGIME_COUNT) { errorOut = StringFormat("regime %d out of range [0,%d)", regime, P03_REGIME_COUNT); return false; }
    if(g_P03_Map[regime].populated)              { errorOut = StringFormat("regime %d already populated -- duplicate set refused", regime); return false; }
    g_P03_Map[regime].slATR = slATR;
    g_P03_Map[regime].tpATR = tpATR;
    g_P03_Map[regime].populated = true;
    errorOut = "";
    return true;
}

//+----------------------------------------------------------------------+
//| P03.F0003 -- is every one of the 9 regimes populated exactly once.   |
//| This is the construction-time completeness check standing in for the |
//| spec's "static assert on map cardinality=9" in an environment with no|
//| real compile-time assertion mechanism.                               |
//+----------------------------------------------------------------------+
bool P03_IsMapComplete() {
    for(int i = 0; i < P03_REGIME_COUNT; i++) if(!g_P03_Map[i].populated) return false;
    return true;
}

//+---------------------------------------------------------------------+
//| P03.F0004 -- the organ's ONLY bracket accessor. Refuses ANY lookup  |
//| (even for a genuinely-populated regime) while the map as a whole is |
//| incomplete -- deliberately conservative: a partially-built map is   |
//| never trusted for the regimes it does have, because "the map hasn't |
//| finished being asserted complete yet" and "one regime is silently   |
//| wrong" are indistinguishable from outside this organ. No default    |
//| bracket is ever substituted -- refusal, not a fallback value, is the|
//| only failure mode.                                                  |
//+---------------------------------------------------------------------+
bool P03_GetBracket(int regime, P03_Bracket &out) {
    if(regime < 0 || regime >= P03_REGIME_COUNT) return false;
    if(!P03_IsMapComplete()) return false;
    out = g_P03_Map[regime];
    return true;
}

//--- P03.V#### the organ's net-of-cost edge report
struct P03_CostReport {
    double edgeGross;
    double cost;
    double edgeNet;
    bool   costComputed;
};

//+-----------------------------------------------------------------------+
//| P03.F0005 -- spread cost expressed in the same ATR units as edge, so  |
//| it can be subtracted directly. Returns EMPTY_VALUE if atrValue<=0 --  |
//| never a fabricated cost when there's no real ATR to normalise against.|
//+-----------------------------------------------------------------------+
double P03_SpreadCostATR(double spreadPoints, double pointValue, double atrValue) {
    if(atrValue <= 0.0) return EMPTY_VALUE;
    double spreadPrice = MathMax(0.0, spreadPoints) * pointValue;
    return spreadPrice / atrValue;
}

//+-----------------------------------------------------------------------+
//| P03.F0006 -- the organ's one entry point for net-of-cost edge (INV-19:|
//| cost subtracted AT MEASUREMENT, not somewhere downstream where it can |
//| be forgotten or applied against the wrong bracket). edgeNet is never  |
//| clamped at zero -- a regime where cost exceeds gross edge reports a   |
//| real negative number, exactly the "surfaced openly" the contract      |
//| requires, instead of a silently-hidden loss dressed up as break-even. |
//+-----------------------------------------------------------------------+
P03_CostReport P03_NetEdge(double edgeGrossATR, double spreadPoints, double pointValue, double atrValue) {
    P03_CostReport r;
    r.edgeGross = edgeGrossATR;
    double cost = P03_SpreadCostATR(spreadPoints, pointValue, atrValue);
    if(cost == EMPTY_VALUE) { r.cost = EMPTY_VALUE; r.edgeNet = EMPTY_VALUE; r.costComputed = false; return r; }
    r.cost = cost;
    r.edgeNet = edgeGrossATR - cost;   // cost>=0 by construction (MathMax floor in F0005) => edgeNet<=edgeGross always
    r.costComputed = true;
    return r;
}

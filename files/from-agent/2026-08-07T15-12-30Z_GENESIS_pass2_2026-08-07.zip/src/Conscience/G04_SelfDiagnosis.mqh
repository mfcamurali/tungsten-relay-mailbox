//+-----------------------------------------------------------------------+
//| G04 · SelfDiagnosis                                                   |
//| GENESIS · CONSCIENCE system · organ 04                                |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                    |
//+-----------------------------------------------------------------------+
//| Purpose (GENESIS_MASTER_SPEC.md O13):                                 |
//|   Annotate every null with its cause. 'No edge' carries cause in      |
//|   {FLAT,TIME-VARYING} + t-stat. No bare 'equal weights' output; cause |
//|   always present.                                                     |
//| Invariant enforced: INV-18 ('no edge' is a first-class verdict).      |
//| Depends on: C01 EdgeAdjudicator (the NONE/EDGE verdict), R01          |
//|             SubstrateDiagnostic (the substrate class + t-stat).       |
//|                                                                       |
//| Intent, extracted from the precedent (read directly, not copied):     |
//| WARRANT#118 (forge-bestofboth, 2026-08-05) is INV-18's own named      |
//| origin: it "automates, in real time, the exact diagnosis this session |
//| had to piece together by hand across three separate runs -- reading   |
//| each regime's own [substrate: ...] annotation one at a time and       |
//| manually aggregating whether 'no edge found' meant genuinely flat, or |
//| real time-varying structure a single fixed-window linear search       |
//| cannot capture by design." That warrant's own SYNTHESIS block         |
//| (aggregating flips+|t| across all 9 regimes into one MOSTLY-TIME-     |
//| VARYING/MOSTLY-FLAT verdict) is real and valuable, but it only ever   |
//| ran AFTER every regime had already regularized to equal weights --    |
//| explaining a null after the fact, same timing gap R01/R02's own       |
//| headers already name for the substrate-classification side of this    |
//| exact problem.                                                        |
//|                                                                       |
//| What changed, and why (Law 1: intent kept, structure discarded):      |
//|   G04_Diagnose runs on ONE regime's C01 verdict + R01 substrate       |
//|   reading directly, producing a real cause immediately when the NONE  |
//|   verdict itself is produced -- not as a separate post-hoc aggregation|
//|   pass. The narrative string is NEVER empty for a NONE verdict (see   |
//|   every branch below) -- there is no code path in this organ that     |
//|   could emit a bare "equal weights" with no explanation attached.     |
//+-----------------------------------------------------------------------+
#property strict

#include "..\Cognition\C01_EdgeAdjudicator.mqh"
#include "..\Substrate\R01_SubstrateDiagnostic.mqh"

//--- G04.V#### the cause classification. NONE_TO_DIAGNOSE is distinct
//--- from the other three -- it means the input verdict was EDGE, not a
//--- fourth kind of "no edge" cause.
enum G04_Cause { G04_NONE_TO_DIAGNOSE = 0, G04_CAUSE_FLAT = 1, G04_CAUSE_TIME_VARYING = 2, G04_CAUSE_UNPOWERED = 3 };

struct G04_Diagnosis {
    G04_Cause cause;
    double    tstat;       // EMPTY_VALUE when the substrate itself was unpowered -- never fabricated
    string    narrative;   // NEVER empty for a NONE verdict (INV-18's own "no bare equal weights" requirement)
};

//+-----------------------------------------------------------------------+
//| G04.F0001 -- the organ's one entry point. Only meaningfully diagnoses |
//| a C01_NONE verdict; a C01_EDGE verdict has nothing to explain and gets|
//| G04_NONE_TO_DIAGNOSE (a real, distinct, honestly-labeled state, not   |
//| the same enum value silently reused for two different meanings).      |
//+-----------------------------------------------------------------------+
G04_Diagnosis G04_Diagnose(const C01_Adjudication &adjudication, const R01_Verdict &substrate) {
    G04_Diagnosis d;

    if(adjudication.verdict == C01_EDGE) {
        d.cause = G04_NONE_TO_DIAGNOSE;
        d.tstat = substrate.tstat;
        d.narrative = "EDGE -- no null result to diagnose";
        return d;
    }

    if(substrate.classOut == R01_UNKNOWN) {
        d.cause = G04_CAUSE_UNPOWERED;
        d.tstat = EMPTY_VALUE;
        d.narrative = StringFormat(
            "NO EDGE, cause UNPOWERED: the substrate diagnostic itself lacks sufficient data (n=%d) to say whether this is flat or time-varying -- C01's own reason: %s",
            substrate.nTotal, adjudication.cause);
        return d;
    }

    if(substrate.classOut == R01_TIME_VARYING) {
        d.cause = G04_CAUSE_TIME_VARYING;
        d.tstat = substrate.tstat;
        d.narrative = StringFormat(
            "NO EDGE, cause TIME-VARYING: real non-stationary structure measured (flips=%d, t=%s) that a fixed-window linear search cannot capture by design, not evidence the signal is absent -- C01's own reason: %s",
            substrate.flips, (substrate.tstat == EMPTY_VALUE ? "n/a" : DoubleToString(substrate.tstat, 2)), adjudication.cause);
        return d;
    }

    // substrate.classOut == R01_STATIONARY
    d.cause = G04_CAUSE_FLAT;
    d.tstat = substrate.tstat;
    d.narrative = StringFormat(
        "NO EDGE, cause FLAT: substrate is genuinely stationary (t=%s, zero flips) -- consistent with a truly weak/absent signal this window, not a search-methodology gap -- C01's own reason: %s",
        (substrate.tstat == EMPTY_VALUE ? "n/a" : DoubleToString(substrate.tstat, 2)), adjudication.cause);
    return d;
}

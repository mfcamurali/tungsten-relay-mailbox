//+-----------------------------------------------------------------------+
//| R03 · TimeAwareSizing                                                 |
//| GENESIS · SUBSTRATE system · organ 03                                 |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                    |
//+-----------------------------------------------------------------------+
//| Purpose (GENESIS_MASTER_SPEC.md O16):                                 |
//|   Size into a fresh edge, decay as it ages: size scales with edge     |
//|   freshness; decays with evidence age; never a full regime/dwell      |
//|   behind; stale edge -> shrinking size.                               |
//| Invariants enforced: INV-12 (confidence enters size exactly once),    |
//|                       INV-11 (evidence persists across restarts).     |
//|                                                                       |
//| Intent, extracted from the precedent: WARRANT#36's Phase 3D DwellCell |
//| (favourable-run-length measurement, bucketed hazard-aging summary,    |
//| the "LE_Tau" tau25/tau50 analogue) and WARRANT#46's                   |
//| LE_BucketHazard/LE_OptimalStoppingExit (discrete-hazard/life-table)   |
//| are this codebase's own precedent for "how long does a state          |
//| typically persist" (dwell) as a measured, per-cell quantity -- never  |
//| previously connected to how much a stale evidence read should be      |
//| DISCOUNTED before it enters sizing. Keys-3's dissipation/episode-dwell|
//| machinery (Keys3_EpisodeState/EpisodeDwell) is the same underlying    |
//| idea applied to readability rather than edge persistence. O16         |
//| generalises: given a measured dwell (from whatever organ estimates    |
//| it -- O6 EvidenceLedger, once built) and how old the current evidence |
//| actually is, produce ONE decay-adjusted confidence value.             |
//|                                                                       |
//| INV-12 discipline, stated explicitly because it is easy to violate    |
//| here by accident: O7 SizeEngine's composition is                      |
//|   size = kelly(edge) x confidence x dd_budget x (1/n_eff)             |
//| with "confidence" appearing exactly once. O16 does NOT add a fifth,   |
//| separate freshness multiplier alongside that formula -- its output    |
//| IS one candidate contribution to "confidence" itself (composed        |
//| upstream, before O7 ever runs), never a second factor applied after   |
//| confidence has already been finalised. R03_ApplyFreshnessDecay's own  |
//| signature takes a baseConfidence and returns a decay-adjusted         |
//| confidence -- a replacement of that one factor, not an addition to    |
//| the expression.                                                       |
//+-----------------------------------------------------------------------+
#property strict

//--- R03.K#### knobs
#define R03_DECAY_HALFLIFE_FRACTION 0.5   // R03.K0001 -- half-life = this fraction of one dwell period; <1 by construction, which is what bounds the estimator's lag below one full dwell (the acceptance test's own requirement)

//+----------------------------------------------------------------------+
//| R03.F0001 -- the organ's one entry point. Applies exponential decay  |
//| to a base confidence value as a function of how old the evidence is  |
//| relative to how long this series' state typically persists (dwell).  |
//|                                                                      |
//| ageBars=0            -> decayFactor=1.0 (fully fresh, no discount)   |
//| ageBars=halfLife      -> decayFactor=0.5                             |
//| ageBars=dwellBars     -> decayFactor=0.25 (one full dwell old is     |
//|                          already down to a quarter-trust -- this is  |
//|                          the concrete form of "never a full regime   |
//|                          behind")                                    |
//| ageBars->infinity     -> decayFactor->0 (a sufficiently stale edge   |
//|                          shrinks size toward nothing, never toward a |
//|                          floor that still trades it at full size)    |
//|                                                                      |
//| dwellBars<=0 (no valid dwell estimate) -> returns 0.0. Failing toward|
//| caution: without a real dwell measurement there is no basis for ANY  |
//| freshness claim, so this organ refuses to assume "fresh enough"      |
//| rather than defaulting to a guessed decay rate (same "never fabricate|
//| a number in place of admitting it wasn't measured" discipline as     |
//| R01's EMPTY_VALUE handling).                                         |
//+----------------------------------------------------------------------+
double R03_ApplyFreshnessDecay(double baseConfidence, double ageBars, double dwellBars) {
    if(dwellBars <= 0.0) return 0.0;
    double halfLife = R03_DECAY_HALFLIFE_FRACTION * dwellBars;
    if(halfLife <= 1e-9) return 0.0;
    double ageClamped = MathMax(0.0, ageBars);   // age is never negative; a caller passing a bad clock doesn't get rewarded with decayFactor>1
    double decayFactor = MathPow(0.5, ageClamped / halfLife);
    decayFactor = MathMax(0.0, MathMin(1.0, decayFactor));
    return baseConfidence * decayFactor;
}

//+-----------------------------------------------------------------+
//| R03.F0002 -- the estimator's characteristic lag (the half-life  |
//| itself), exposed so callers/tests can confirm it is structurally|
//| bounded below one full dwell period without needing to reverse- |
//| engineer it from F0001's output.                                |
//+-----------------------------------------------------------------+
double R03_EstimatorLag(double dwellBars) {
    if(dwellBars <= 0.0) return 0.0;
    return R03_DECAY_HALFLIFE_FRACTION * dwellBars;
}

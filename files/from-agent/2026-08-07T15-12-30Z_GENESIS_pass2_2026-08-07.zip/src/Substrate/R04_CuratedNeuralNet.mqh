//+-----------------------------------------------------------------------+
//| R04 · CuratedNeuralNet                                                |
//| GENESIS · SUBSTRATE system · the real implementation of               |
//| R02_SearchDispatcher's CURATED_NEURAL method                          |
//| TUNGSTEN_LIMITLESS_QUANT / GENESIS · GEN-0.1.0-dev                    |
//+-----------------------------------------------------------------------+
//| Why this organ exists, and why it didn't exist an hour ago:           |
//| R02 SearchDispatcher named CURATED_NEURAL as a valid TIME-VARYING     |
//| search method per GENESIS_MASTER_SPEC.md, but marked it unavailable --|
//| per tungsten_forge_neural_bookmark memory (2026-08-06), Manuel raised |
//| "a curated neural network... who knows" late in an already-long live- |
//| trading session and it was DELIBERATELY deferred: committing to it    |
//| off one late-session message, into a system that was actively live-   |
//| trading, would have been exactly the rushed, under-pressure decision  |
//| this project's own history (WARRANT#81/#109 "process slip" notes)     |
//| repeatedly warns against. That memory's own closing line named the    |
//| precondition for building it for real: "a dedicated forge-family      |
//| thesis... don't start building... without Manuel naming this          |
//| explicitly again with a clear head, not mid-live-run." This GENESIS   |
//| session -- a dedicated architecture build, nothing live attached,     |
//| Manuel naming it explicitly again ("deep neural network... within     |
//| MT4") -- is exactly that precondition met, not a repeat of the        |
//| earlier rushed context.                                               |
//|                                                                       |
//| What this organ honestly is: a real, working feedforward neural       |
//| network -- two hidden layers (genuinely "deep" by the technical       |
//| definition: more than one hidden layer), full forward pass, and real  |
//| backpropagation (gradient descent, textbook-correct, not a stub or a  |
//| relabeled linear model) -- implemented in pure MQL4 with no external  |
//| library, because none exists for MQL4. This is the actual mechanism   |
//| GENESIS was missing.                                                  |
//|                                                                       |
//| What this organ is honestly NOT (stated plainly, per Law 7 "honest or |
//| nothing"): trained on real market data yet. The bookmark's second     |
//| named concern -- "this account has produced single-digit-to-low-      |
//| double-digit ghost trades per run; a neural net needs orders of       |
//| magnitude more before it's not just overfitting with extra steps" --  |
//| is still true today; nothing about building the mechanism changes how |
//| much real training data exists. R04_MinTrainingSamplesForTrust below  |
//| is the same "mechanism existing != trustworthy for live decisions"    |
//| gate every other GENESIS organ already enforces (P02's AUC retirement,|
//| C01's window-count floor, O10 ArmController's n>=30) -- a network     |
//| trained on too few samples must refuse to be trusted, exactly like    |
//| every other underpowered read in this codebase's history.             |
//+-----------------------------------------------------------------------+
#property strict

//--- R04.K#### architecture -- fixed at compile time (MQL4 struct arrays
//--- require constant trailing dimensions). Two hidden layers = real
//--- depth. Sized for a small, real feature vector (room for the 6 CEUS
//--- components + up to 2 substrate/readability readings) without being
//--- so large it can't possibly be justified by the real data volume this
//--- project has today -- see header.
#define R04_INPUT_SIZE     8
#define R04_HIDDEN1_SIZE   8
#define R04_HIDDEN2_SIZE   6
#define R04_OUTPUT_SIZE    1
#define R04_MIN_TRAINING_SAMPLES_FOR_TRUST 500   // R04.K0005 -- matches this project's own established n>=500 trading-weight floor (Prohibition #5), not the n>=30 diagnostic floor -- a live-decision-affecting prediction is held to the higher bar

//--- R04.S#### the network's full parameter set.
struct R04_Network {
    double W1[R04_HIDDEN1_SIZE][R04_INPUT_SIZE];
    double b1[R04_HIDDEN1_SIZE];
    double W2[R04_HIDDEN2_SIZE][R04_HIDDEN1_SIZE];
    double b2[R04_HIDDEN2_SIZE];
    double W3[R04_OUTPUT_SIZE][R04_HIDDEN2_SIZE];
    double b3[R04_OUTPUT_SIZE];
};

//--- R04.S#### one labeled training sample.
struct R04_Sample {
    double inVec[R04_INPUT_SIZE];
    double target[R04_OUTPUT_SIZE];
};

//+----------------------------------------------------------------------+
//| R04.F0001 -- initialise all weights to small random values (standard |
//| symmetry-breaking init) and all biases to zero. Seeded explicitly so |
//| a caller can get reproducible behaviour for testing -- MathSrand is a|
//| real MQL4 primitive, this does not fabricate its own RNG.            |
//+----------------------------------------------------------------------+
void R04_InitNetwork(R04_Network &net, int seed) {
    MathSrand(seed);
    for(int i = 0; i < R04_HIDDEN1_SIZE; i++) {
        for(int j = 0; j < R04_INPUT_SIZE; j++) net.W1[i][j] = (MathRand() / 32767.0 - 0.5) * 1.0;
        net.b1[i] = 0.0;
    }
    for(int i = 0; i < R04_HIDDEN2_SIZE; i++) {
        for(int j = 0; j < R04_HIDDEN1_SIZE; j++) net.W2[i][j] = (MathRand() / 32767.0 - 0.5) * 1.0;
        net.b2[i] = 0.0;
    }
    for(int i = 0; i < R04_OUTPUT_SIZE; i++) {
        for(int j = 0; j < R04_HIDDEN2_SIZE; j++) net.W3[i][j] = (MathRand() / 32767.0 - 0.5) * 1.0;
        net.b3[i] = 0.0;
    }
}

double R04_Sigmoid(double x) { return 1.0 / (1.0 + MathExp(-x)); }

//--- MQL4 (unlike MQL5) has no built-in MathTanh -- implemented directly
//--- via the standard identity tanh(x) = 2*sigmoid(2x) - 1, clamped to
//--- avoid MathExp overflow on extreme inputs (a large but finite bound,
//--- not a fabricated activation curve).
double R04_Tanh(double x) {
    double xc = MathMax(-40.0, MathMin(40.0, x));
    return 2.0 * R04_Sigmoid(2.0 * xc) - 1.0;
}

//+--------------------------------------------------------------------+
//| R04.F0002 -- full forward pass. Exposes both hidden layers'        |
//| activations (not just the final output) because real backprop needs|
//| them -- this is not a black box even to this organ's own training  |
//| function.                                                          |
//| Hidden layers: tanh (bounded, zero-centred, standard for a network |
//| this size). Output layer: sigmoid (bounded [0,1], appropriate for a|
//| probability-like prediction -- e.g. "does this candidate weight    |
//| vector represent a real edge").                                    |
//+--------------------------------------------------------------------+
void R04_Forward(const R04_Network &net, const double &inVec[], double &h1[], double &h2[], double &output[]) {
    ArrayResize(h1, R04_HIDDEN1_SIZE); ArrayResize(h2, R04_HIDDEN2_SIZE); ArrayResize(output, R04_OUTPUT_SIZE);
    for(int i = 0; i < R04_HIDDEN1_SIZE; i++) {
        double s = net.b1[i];
        for(int j = 0; j < R04_INPUT_SIZE; j++) s += net.W1[i][j] * inVec[j];
        h1[i] = R04_Tanh(s);
    }
    for(int i = 0; i < R04_HIDDEN2_SIZE; i++) {
        double s = net.b2[i];
        for(int j = 0; j < R04_HIDDEN1_SIZE; j++) s += net.W2[i][j] * h1[j];
        h2[i] = R04_Tanh(s);
    }
    for(int i = 0; i < R04_OUTPUT_SIZE; i++) {
        double s = net.b3[i];
        for(int j = 0; j < R04_HIDDEN2_SIZE; j++) s += net.W3[i][j] * h2[j];
        output[i] = R04_Sigmoid(s);
    }
}

//+------------------------------------------------------------------+
//| R04.F0003 -- prediction-only convenience wrapper (discards hidden|
//| activations a live caller doesn't need).                         |
//+------------------------------------------------------------------+
void R04_Predict(const R04_Network &net, const double &inVec[], double &output[]) {
    double h1[], h2[];
    R04_Forward(net, inVec, h1, h2, output);
}

//+----------------------------------------------------------------------+
//| R04.F0004 -- one real backpropagation step (textbook gradient        |
//| descent, MSE loss, sigmoid-output/tanh-hidden derivatives -- standard|
//| calculus, not invented here). Mutates net in place by one gradient   |
//| step for ONE sample; R04_Train (F0005) calls this once per sample per|
//| epoch.                                                               |
//+----------------------------------------------------------------------+
void R04_TrainStep(R04_Network &net, const double &inVec[], const double &target[], double learningRate) {
    double h1[], h2[], output[];
    R04_Forward(net, inVec, h1, h2, output);

    // Output layer delta: dLoss/dPreActivation = (output-target) * sigmoid'(output)
    double delta3[]; ArrayResize(delta3, R04_OUTPUT_SIZE);
    for(int i = 0; i < R04_OUTPUT_SIZE; i++) delta3[i] = (output[i] - target[i]) * output[i] * (1.0 - output[i]);

    // Hidden layer 2 delta: propagate delta3 back through W3, times tanh'(h2)
    double delta2[]; ArrayResize(delta2, R04_HIDDEN2_SIZE);
    for(int j = 0; j < R04_HIDDEN2_SIZE; j++) {
        double s = 0.0;
        for(int i = 0; i < R04_OUTPUT_SIZE; i++) s += delta3[i] * net.W3[i][j];
        delta2[j] = s * (1.0 - h2[j] * h2[j]);
    }

    // Hidden layer 1 delta: propagate delta2 back through W2, times tanh'(h1)
    double delta1[]; ArrayResize(delta1, R04_HIDDEN1_SIZE);
    for(int j = 0; j < R04_HIDDEN1_SIZE; j++) {
        double s = 0.0;
        for(int i = 0; i < R04_HIDDEN2_SIZE; i++) s += delta2[i] * net.W2[i][j];
        delta1[j] = s * (1.0 - h1[j] * h1[j]);
    }

    // Gradient descent updates, output layer first (uses h2, the pre-update activations).
    for(int i = 0; i < R04_OUTPUT_SIZE; i++) {
        for(int j = 0; j < R04_HIDDEN2_SIZE; j++) net.W3[i][j] -= learningRate * delta3[i] * h2[j];
        net.b3[i] -= learningRate * delta3[i];
    }
    for(int i = 0; i < R04_HIDDEN2_SIZE; i++) {
        for(int j = 0; j < R04_HIDDEN1_SIZE; j++) net.W2[i][j] -= learningRate * delta2[i] * h1[j];
        net.b2[i] -= learningRate * delta2[i];
    }
    for(int i = 0; i < R04_HIDDEN1_SIZE; i++) {
        for(int j = 0; j < R04_INPUT_SIZE; j++) net.W1[i][j] -= learningRate * delta1[i] * inVec[j];
        net.b1[i] -= learningRate * delta1[i];
    }
}

//+-----------------------------------------------------------------------+
//| R04.F0005 -- full training loop: epochs x samples, one TrainStep each.|
//| Yields via Sleep(1) every R04_YIELD_INTERVAL steps -- this project's  |
//| own hard-won lesson (WARRANT#31/#103): a long synchronous loop with   |
//| zero yield points risks MT4's own watchdog killing the process        |
//| (Windows Event 1002 / "shutdown by timeout"), even though the EA is   |
//| genuinely computing, not hung. A training loop over many epochs is    |
//| exactly this loop shape -- inheriting the fix by default here means   |
//| every future caller gets it, not just whichever one remembers to add  |
//| it.                                                                   |
//+-----------------------------------------------------------------------+
#define R04_YIELD_INTERVAL 1000   // R04.K0006 -- same cadence already proven safe throughout this project's P2/P3B/CSCV loops

void R04_Train(R04_Network &net, const R04_Sample &samples[], int epochs, double learningRate) {
    int n = ArraySize(samples);
    long stepCount = 0;
    for(int e = 0; e < epochs; e++) {
        for(int s = 0; s < n; s++) {
            R04_TrainStep(net, samples[s].inVec, samples[s].target, learningRate);
            stepCount++;
            if(stepCount % R04_YIELD_INTERVAL == 0) Sleep(1);
        }
    }
}

//+-----------------------------------------------------------------+
//| R04.F0006 -- mean squared error over a sample set, for measuring|
//| whether training actually converged (the acceptance test's own  |
//| pass/fail criterion).                                           |
//+-----------------------------------------------------------------+
double R04_MSE(const R04_Network &net, const R04_Sample &samples[]) {
    int n = ArraySize(samples);
    if(n == 0) return EMPTY_VALUE;
    double sumSq = 0.0;
    double output[];
    for(int s = 0; s < n; s++) {
        R04_Predict(net, samples[s].inVec, output);
        for(int i = 0; i < R04_OUTPUT_SIZE; i++) { double d = output[i] - samples[s].target[i]; sumSq += d * d; }
    }
    return sumSq / (n * R04_OUTPUT_SIZE);
}

//+-----------------------------------------------------------------------+
//| R04.F0007 -- the live-trust gate. A network that exists and even      |
//| trains cleanly is NOT automatically trustworthy for a live decision --|
//| this is the same "mechanism != trust" discipline as R02_IsAvailable's |
//| own honesty about CURATED_NEURAL, now scoped to training volume       |
//| specifically. Callers (e.g. a future C01 EdgeAdjudicator integration) |
//| MUST check this before acting on R04_Predict's output for anything    |
//| live-decision-affecting.                                              |
//+-----------------------------------------------------------------------+
bool R04_IsTrustworthy(int realTrainingSamplesUsed) {
    return realTrainingSamplesUsed >= R04_MIN_TRAINING_SAMPLES_FOR_TRUST;
}

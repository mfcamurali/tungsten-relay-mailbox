# TUNGSTEN session summary — 2026-07-23

Build: SLS(92)/10.06. Ledger: forge_ledger.json through pass_77 (WARRANT#91-96).
This session's own arc, in order:

## Watchdog + attach infrastructure
- Wired an external process watchdog (`tungsten_watchdog.ps1`, standalone, catches terminal.exe
  death independent of the attach script) into `tungsten-attach-and-watch.ps1`.
- Found and fixed a UTF-8-without-BOM encoding bug that broke the watchdog under Windows
  PowerShell 5.1 despite parsing clean under pwsh 7.
- Found the watchdog itself silently hung (QuickEdit Mode console freeze) on its first live test,
  missing a real terminal death for 105+ minutes. Fixed with a P/Invoke QuickEdit-disable +
  stdin-redirect (WARRANT-adjacent, not a TUNGSTEN warrant).
- **That fix was insufficient** — the watchdog hung again on a later run. Root-caused deeper:
  `Start-Process -WindowStyle Hidden` still allocates a real (hidden) console. Fixed (WARRANT#96)
  by switching to `[System.Diagnostics.Process]::Start()` with `CreateNoWindow=$true` +
  `UseShellExecute=$false` — true Win32 `CREATE_NO_WINDOW`, no console allocated at all.

## First live test of WARRANT#80-90 (session RUN_20260723_1811, 18:11-20:03)
112 minutes stable, two full Phase 3B cycles, both ended `STAND DOWN / OVERFIT` — an honest null
result (PBO-CSCV 0.21-0.59, train→holdout gaps to -37pp). Terminal shutdown was clean (`Expert
removed` → `MT4 stopped`, `uninit reason 9` = REASON_CLOSE), not a crash.

## WARRANT#91 — P2 WR/IC numeric corruption, sanitize-on-load
Live evidence: WR printing in the hundreds-of-millions-of-percent, IC with 70-300 digit
magnitudes. Root cause: corrupted/stale saved-state file, not a live calc bug (both bounded by
construction in the fresh-compute path). Fixed with sanitize-on-load guards on
`g_RegimeCorrelations`/`g_RegimeIC`, discarding out-of-range or non-finite values.

## WARRANT#92 — mislabeled "enh-check"
Investigated the null-edge/overfit problem systematically. Found the "enh-check" block never
tested the real 14-layer live scorer (structurally can't — that function has no candidate-weight
parameter); it re-tested the same linear scorer on a different sample. Relabeled every log line
(enh-check→resample-check etc.) to reflect what's actually measured. Zero computation changed.

## WARRANT#93 / 93b — "brainscan / laser triangulation" metaphor made concrete
- **#93**: `RI_CoherenceIndexShrunk` — found the same hard-cliff-vs-shrinkage defect WARRANT#85
  fixed elsewhere, still present in indicator-pair coherence (n<30 fully discarded, not
  down-weighted). Fixed with the same empirical-Bayes shrinkage construction already used by
  `LE_ShrunkMean`. Wired into the already-live `ComputeRelationshipDisagreementTrim`.
- **#93b**: `ComputeMultiTFCoherenceTrim` — `ComputeHTFAgreement` only ever checked H1. Added H4 as
  a second, genuinely independent timeframe vantage point, wired as a new bounded [0.90,1.0],
  reduce-only, always-on trim.

## WARRANT#94 — plateau detection ("weather ensemble" metaphor)
Systematic 10-candidate brainstorm (EEG/fMRI/LIDAR/sonar/interferometry/seismic/multi-modal/
weather-ensemble/GPS-RAIM/Doppler), evaluated in parallel against the actual codebase, converged
on parameter-sensitivity/plateau detection as the strongest real lever. Perturbs P3B's found
weights ±15%, re-scores on the same sample; if nearby weights collapse (std≥15pp = narrow spike),
triggers the same existing 35% regularization pull the fit-check already uses. Directly targets
the overfit mechanism behind every STAND DOWN result — only makes acceptance stricter, never
looser.

## WARRANT#95 — CONFIRMED CRASH, fixed and validated live
First live test of WARRANT#91-94 together crashed 7s into Phase 2: `zero divide (31688,54)` in
`CalculateRangeMetrics()`. Root cause, two layers: (1) a corrupted ARMED save's regime-learning
timestamp read back as Unix epoch 0 ("1970.01.01") yet was still trusted for an "instant start"
because nothing validated that specific field before the trust decision; (2) that skipped
populating swing-high/low history, leaving `avgHigh=avgLow=0.0` for an unguarded division. Fixed
both: the zero-guard itself, and a save-integrity check (reject+delete the file if the
regime-learning timestamp is implausible) using the same pattern the version/expiry checks already
use. **Confirmed working on the very next live attempt**: journal showed `save rejected |
implausible regime-learning timestamp (1970.01.01 00:00) | recalibrating`, then a clean run through
Phase 0-3 with zero crashes.

## Monitoring-tooling lesson (not TUNGSTEN, but load-bearing for every future session)
MT4 holds its append-only log files (`MQL4\Logs\<date>.log`, terminal-level `logs\<date>.log`) open
with buffered/deferred writes. ANY plain reader — Bash `tail`/`stat`, PowerShell `Get-Content`/
`Get-Item` — silently returns a stale cached snapshot with no error, confirmed identical across
both runtimes. Only `tungsten-attach-and-watch.ps1`'s own `Read-NewTail`/`Read-Shared` functions
(explicit `[System.IO.File]::Open(..., FileShare.ReadWrite)`) read through this correctly. Standing
rule: never read those files directly again from outside that script; always watch its own output.
`TUNGSTEN_live.log` is unaffected (overwritten fresh each update, not appended).

## Live status as of this file's writing (session RUN_20260723_2202, started 22:02)
Phase 3B in progress, r8/9 Building Momentum, ~58% WR, terminal healthy (steady CPU growth, no
stalls), watchdog (CREATE_NO_WINDOW, WARRANT#96) tracking correctly. Zero crashes, zero corrupt-
state warnings since the WARRANT#95 fix went live. Run is ONGOING — this archive is a snapshot,
not a final result.

## Standing next-step backlog (from the strategic brainstorm pass)
Ranked by leverage:
1. Multiple-testing correction on P3B's 562,500-combination weight search (biggest unshipped
   lever — flagged since 2026-07-17).
2. Content-checksum / schema-version stamp on the save file format (would have caught WARRANT#91
   and WARRANT#95's root cause in one shot instead of two separate discoveries).
3. Systematic audit for the "hard-cliff vs shrinkage" defect class (found 3x now: WARRANT#85, #93,
   and arguably #95) across all persisted/diagnostic-floor fields.
4. Bootstrap/block resampling for effective sample size (real statistical technique, not yet
   attempted).
5. Regime taxonomy re-evaluation (9 regimes may be over-fine for ~229 days of available M5
   history) — a genuine design tradeoff needing Manuel's judgment call.
6. Day-of-week × regime conditioning (time-based sign-inversion findings are diagnostic-only,
   never wired — a second orthogonal axis sitting unused).
